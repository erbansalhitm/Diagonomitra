    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
	 <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    <h1>
    Store Details
    </h1>
    <ol class="breadcrumb">
    <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="#">Store Details</a></li>
    <li><a href="#">Store Details</a></li>
    </ol>
    </section>
    
    <!-- Main content -->
    <section class="content">
    <div class="row">
    <!-- left column -->
    <div class="col-md-12">
    <!-- general form elements -->
    <div class="box box-primary">
    <div class="box-header with-border">
	
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
		
		<img src="https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=<?php echo e(urldecode($url)); ?>&choe=UTF-8" title="<?php echo e(urldecode($url)); ?>" />
		
    </div>
    
    
    </div>
    
    </div>
    <!-- /.row -->
    </section>
    <!-- /.content -->
    </div>
    
   
    

    <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    
<?php /**PATH /home/primewe1/public_html/saromc.com/diagno/resources/views/admin/qrcode.blade.php ENDPATH**/ ?>