    
     <?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!-- ***** Include the above in your HEAD tag *** -->
<style>
@import  url('https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
/*================================================*/
@import  url('https://fonts.googleapis.com/css?family=Roboto');
.carousel-item > div {
float: left;
}
.carousel-by-item [class*="cloneditem-"] {
display: none;
}
.top-service img{
    width:100%;
    height:150px;
        object-fit: cover;
}
.top-service .card-body{
        background-image: linear-gradient(90deg, #b03e92 0%, #4b5daf 100%);
    color: #fff;
}
.top-service .card-text {
    color: #fff;
}
.carousel-control-next-icon {
    /*background: #020202;*/
    border:2px solid #fff;
        background-image: url(data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 8 8'%3E%3Cpath d='M2.75 0l-1.5 1.5 2.5 2.5-2.5 2.5 1.5 1.5 4-4-4-4z'/%3E%3C/svg%3E);
}
.carousel-control-prev-icon {
    /*background: #020202;*/
    border:2px solid #fff;
        background-image: url(data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 8 8'%3E%3Cpath d='M2.75 0l-1.5 1.5 2.5 2.5-2.5 2.5 1.5 1.5 4-4-4-4z'/%3E%3C/svg%3E);
}




@media  only screen and (max-width: 767px){
    .labtestnew img{
     width: 100%;
    height: 196px !important;
}
.epharmnew img{
     width: 100%;
    height: 196px !important;
}
.healthstr img{
     width: 100%;
    height: 196px !important;
}


}

</style>
     

        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner">
            <?php if($slideractive): ?>  
                <div class="carousel-item active">
                  <img class="d-block w-100" src="<?php echo e(asset('public/front/slider').'/'.$slideractive->sliderImage); ?>" alt="First slide">
                </div>
            <?php endif; ?>
            
            <?php if($sliders): ?>
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item">
                  <img class="d-block w-100" src="<?php echo e(asset('public/front/slider').'/'.$slider->sliderImage); ?>" alt="Second slide">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
     
     
  
  <div class="container">
    <div id="video-multi-item" class="video_card" data-ride="carousel" data-interval="false">
      <div class="row mt-5">
        <div class="heading_section mb-4">
          <div class="col-md-12"><h6><b>Top Services</b></h6></div>
          
        </div>
      </div>
        <div class="top-service">
            <div class="row">
                 <div class="scroll-x">
            
                <div class="col-10 col-sm-10 col-md-3 col-lg-3 col-xl-3">
                  <div class="card mb-2">
                       <a href="#">
                    <img src="<?php echo e(asset('public/front/service/doctor.png')); ?>">
                    </a>
                    <div class="card-body">
                                          
                        <div class="row">
                          <div class="col-12">
                          <small class="card-text ">Doctor Consultation</small>
                          <a type="button" href="<?php echo e(route('doctors')); ?>" class="float-right blue_color_border btn-group-sm">Consult Now</a>
                        </div>
                      </div>                 
                    </div>
                  </div>
                </div>
				
				<div class="col-10 col-sm-10 col-md-3 col-lg-3 col-xl-3">
                  <div class="card mb-2">
                       <a href="#">
                    <img src="<?php echo e(asset('public/front/service/lab.png')); ?>">
                    </a>
                    <div class="card-body">
                                          
                        <div class="row">
                          <div class="col-12">
                          <small class="card-text">Lab Test</small>
                          <a type="button" href="<?php echo e(route('labtest')); ?>" class="float-right blue_color_border btn-group-sm">Consult Now</a>
                        </div>
                      </div>                 
                    </div>
                  </div>
                </div>
				
				<div class="col-10 col-sm-10 col-md-3 col-lg-3 col-xl-3">
                  <div class="card mb-2">
                      <a href="#">
                    <img src="<?php echo e(asset('public/front/service/epharmecy.png')); ?>">
                    </a>
                    <div class="card-body">
                                          
                        <div class="row">
                          <div class="col-12">
                          <small class="card-text">E-Pharmacy</small>
                          <a type="button" href="<?php echo e(route('epharmacy')); ?>" class="float-right blue_color_border btn-group-sm">Shop Now</a>
                        </div>
                      </div>                 
                    </div>
                  </div>
                </div>
				
				<div class="col-10 col-sm-10 col-md-3 col-lg-3 col-xl-3">
                  <div class="card mb-2">
                      <a href="#">
                          <img src="<?php echo e(asset('public/front/service/healthstore.png')); ?>">
                      </a>
                    
                    <div class="card-body">
                                          
                        <div class="row">
                          <div class="col-12">
                          <small class="card-text ">Health Store</small>
                          <a type="button" href="<?php echo e(route('health_store')); ?>" class="float-right blue_color_border btn-group-sm">Shop Now</a>
                        </div>
                      </div>                 
                    </div>
                  </div>
                </div>
				
                </div>
            </div>
        </div>
    </div>
  </div>
  

  <div class="container my-4">

    <!--Carousel Wrapper-->
    <div id="product-item" class="carousel slide carousel-multi-item" data-ride="carousel" data-interval="false">

      <!--Controls-->
      <div class="controls-top">
        <a class="btn-floating left" href="#product-item" data-slide="prev"><i class="fa fa-chevron-left"></i></a>
        <a class="btn-floating right" href="#product-item" data-slide="next"><i class="fa fa-chevron-right"></i></a>
      </div>
      <!--/.Controls-->
      <div class="row mt-5">
        <div class="heading_section mb-4">
          <div class="col-md-9"><h6><b>Consult top verified doctors with all specialists </b></h6></div>
          <div class="col-md-3"><a href="<?php echo e(route('spesilities')); ?>" class="float-right blue_color_border">View All</a></div>
        </div>
      </div>

      <!--Slides-->
      <?php if($specialists): ?>
      <div class="carousel-inner popular" role="listbox">
        

        <!--First slide-->
        <div class="carousel-item active">

          <div class="row">
            <?php $__currentLoopData = $specialists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-6 col-xl-3 col-lg-3 clearfix d-md-block">
              <div class="mb-2">
                  <a href="#">
                <img class="card-img-popular" src="<?php echo e(asset('public/front/specialists/').'/'.$specialist->image); ?>"
                  alt="Card image cap">
                  </a>
                <div class="product_text">
                  
                  <div class="bold_text"><?php echo e($specialist->name); ?></div>
                  <div class="line_height_1 grey_text"><small><?php echo e($specialist->details); ?></small></div>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

        </div>
        <!--/.First slide-->
        <!--First slide-->

        <div class="carousel-item">

          <div class="row">
            <?php $__currentLoopData = $specialists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-6 col-xl-3 col-lg-3 clearfix  d-md-block">
              <div class="mb-2">
                  <a href="#">
                <img class="card-img-popular" src="<?php echo e(asset('public/front/specialists/').'/'.$specialist->image); ?>"
                  alt="Card image cap">
                  </a>
                <div class="product_text">
                  
                  <div class="bold_text"><?php echo e($specialist->name); ?></div>
                  <div class="line_height_1 grey_text"><small><?php echo e($specialist->details); ?></small></div>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

        </div>
        
      </div>
      <?php endif; ?>
      <!--/.Slides-->

    </div>
    <!--/.Carousel Wrapper-->
  </div>



    <!--My Slider Here-->
    <style type="text/css" id="slider-css"></style>
    <div class="spe-cor topDoc">
        <div class="container">
            <div class="row mt-5">
                <div class="heading_section mb-4">
                  <div class="col-md-9"><h6><b>Top Doctors in your city</b></h6></div>
                  <div class="col-md-3"><a href="<?php echo e(route('doctors')); ?>" class="float-right blue_color_border" >View All</a></div>
                </div>
              </div>
            <!--<h2>New Slider</h2>-->
            <div class="row">
                <div id="slider-1" class="carousel carousel-by-item slide" data-ride="carousel">
                    <div class="carousel-inner" role="listbox">
                        <?php if($doctor): ?>
                        <div class="carousel-item active">
                            <div class="col-lg-2 col-md-3 col-sm-4 col-4">
                                <a href="<?php echo e(route('doctor-profile',$doctor->slug)); ?>">
                                <img class="d-block img-fluid" src="<?php echo e(asset('public/front/doctors/').'/'.$doctor->image); ?>" alt="First slide">
                                </a>
                                <div class="product_text">
                                  <div class="bold_text"><?php echo e($doctor->name); ?></div>
                                  <div><small><?php echo e($doctor->specialists); ?></small></div>
                                  <a type="button" href="<?php echo e(route('doctor-profile',$doctor->slug)); ?>" class="mt-2 blue_color_border">Consult Now</a>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if($doctors): ?>
                            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item">
                                <div class="col-lg-2 col-md-3 col-sm-4 col-4">
                                    <a href="<?php echo e(route('doctor-profile',$doctor->slug)); ?>">
                                    <img class="d-block img-fluid" src="<?php echo e(asset('public/front/doctors/').'/'.$doctor->image); ?>" alt="First slide">
                                    </a>
                                    <div class="product_text">
                                      <div class="bold_text"><?php echo e($doctor->name); ?></div>
                                      <div><small><?php echo e($doctor->specialists); ?></small></div>
                                      <a type="button" href="<?php echo e(route('doctor-profile',$doctor->slug)); ?>" class="mt-2 blue_color_border">Consult Now</a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                       
                    </div>
                    <a class="carousel-control-prev" href="#slider-1" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#slider-1" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

<!--My Slider Ends Here-->
    

	<?php if(count($labtests)): ?>
		<div class="spe-cor topDoc epharmnew">
			<div class="container-fluid">
				<div class="row mt-5">
					<div class="heading_section mb-4">
					  <div class="col-md-9"><h6><b>Lab Test</b></h6></div>
					  <div class="col-md-3"><a href="<?php echo e(route('labtest')); ?>" class="float-right blue_color_border" >View All</a></div>
					</div>
				  </div>
				
				<div class="">
					<div id="slider-5" class="carousel carousel-by-item slide" data-ride="carousel">
						<div class="carousel-inner" role="listbox">
						
							<div class="carousel-item active">
									<div class="col-lg-2 col-md-3 col-sm-4 col-12">
										<a href="<?php echo e(route('labtest-details',$labtest->slug)); ?>">
										<img class="d-block img-fluid" src="<?php echo e(asset('public/front/labtest').'/'.$labtest->image); ?>" alt="<?php echo e($labtest->name); ?>">
										</a>
										<div class="product_text  text-center">
										  <div class="bold_text"><?php echo e($labtest->name); ?></div>
										  <div><small> <s>₹ <?php echo e($labtest->oldprice); ?></s> </small> <b class="f-14"><?php echo e($labtest->newprice); ?></b></div>
										  <button style="width: 100%;" type="button" value="<?php echo e($labtest->id); ?>"  class="mt-2 blue_color_border add-to-cart-lab" >Add to Cart</button>
										  
										</div>
									</div>
							</div>
							<?php $__currentLoopData = $labtests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labtest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 					  
								<div class="carousel-item">
									<div class="col-lg-2 col-md-3 col-sm-4 col-12">
										<a href="<?php echo e(route('labtest-details',$labtest->slug)); ?>">
										<img class="d-block img-fluid" src="<?php echo e(asset('public/front/labtest').'/'.$labtest->image); ?>" alt="<?php echo e($labtest->name); ?>">
										</a>
										<div class="product_text  text-center">
										  <div class="bold_text"><?php echo e($labtest->name); ?></div>
										  <div><small> <s>₹ <?php echo e($labtest->oldprice); ?></s> </small> <b class="f-14"><?php echo e($labtest->newprice); ?></b></div>
										  <button style="width: 100%;" type="button" value="<?php echo e($labtest->id); ?>"  class="mt-2 blue_color_border add-to-cart-lab" >Add to Cart</button>
										  
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								 
						</div>
						<a class="carousel-control-prev" href="#slider-5" role="button" data-slide="prev">
							<span class="carousel-control-prev-icon" aria-hidden="true"></span>
							<span class="sr-only">Previous</span>
						</a>
						<a class="carousel-control-next" href="#slider-5" role="button" data-slide="next">
							<span class="carousel-control-next-icon" aria-hidden="true"></span>
							<span class="sr-only">Next</span>
						</a>
					</div>
				</div>
			</div>
		</div>
	<?php endif; ?>	

	<?php if(count($pharmacys)): ?>
		<div class="spe-cor topDoc epharmnew">
			<div class="container-fluid">
				<div class="row mt-5">
					<div class="heading_section mb-4">
					  <div class="col-md-9"><h6><b>E-Pharmacy</b></h6></div>
					  <div class="col-md-3"><a href="<?php echo e(route('epharmacy')); ?>" class="float-right blue_color_border" >View All</a></div>
					</div>
				  </div>
				
				<div class="">
					<div id="slider-5" class="carousel carousel-by-item slide" data-ride="carousel">
						<div class="carousel-inner" role="listbox">
						
							<div class="carousel-item active">
								<div class="col-lg-2 col-md-3 col-sm-4 col-12">
									<a href="<?php echo e(route('details',$pharmacy->slug)); ?>">
									<img class="d-block img-fluid" src="<?php echo e(asset('public/front/pharmacy').'/'.$pharmacy->image); ?>" alt="<?php echo e($pharmacy->name); ?>">
									</a>
									<div class="product_text  text-center">
									  <div class="bold_text"><?php echo e($pharmacy->name); ?></div>
									  <div><small> <s>₹ <?php echo e($pharmacy->oldprice); ?></s> </small> <b class="f-14"><?php echo e($pharmacy->newprice); ?></b></div>
									  <button style="width: 100%;" type="button" value="<?php echo e($pharmacy->id); ?>"  class="mt-2 blue_color_border add-to-cart" >Add to Cart</button>
									  
									</div>
								</div>
							</div>
							<?php $__currentLoopData = $pharmacys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pharmacy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 					  
								<div class="carousel-item">
									<div class="col-lg-2 col-md-3 col-sm-4 col-12">
										<a href="<?php echo e(route('details',$pharmacy->slug)); ?>">
										<img class="d-block img-fluid" src="<?php echo e(asset('public/front/pharmacy').'/'.$pharmacy->image); ?>" alt="<?php echo e($pharmacy->name); ?>">
										</a>
										<div class="product_text  text-center">
										  <div class="bold_text"><?php echo e($pharmacy->name); ?></div>
										  <div><small> <s>₹ <?php echo e($pharmacy->oldprice); ?></s> </small> <b class="f-14"><?php echo e($pharmacy->newprice); ?></b></div>
										  <button style="width: 100%;" type="button" value="<?php echo e($pharmacy->id); ?>"  class="mt-2 blue_color_border add-to-cart" >Add to Cart</button>
										  
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								 
						</div>
						<a class="carousel-control-prev" href="#slider-5" role="button" data-slide="prev">
							<span class="carousel-control-prev-icon" aria-hidden="true"></span>
							<span class="sr-only">Previous</span>
						</a>
						<a class="carousel-control-next" href="#slider-5" role="button" data-slide="next">
							<span class="carousel-control-next-icon" aria-hidden="true"></span>
							<span class="sr-only">Next</span>
						</a>
					</div>
				</div>
			</div>
		</div>
	<?php endif; ?>
	
	

	<?php if(count($healthstores)): ?>
		<div class="spe-cor topDoc epharmnew">
			<div class="container-fluid">
				<div class="row mt-5">
					<div class="heading_section mb-4">
					  <div class="col-md-9"><h6><b>Health Store</b></h6></div>
					  <div class="col-md-3"><a href="<?php echo e(route('health_store')); ?>" class="float-right blue_color_border" >View All</a></div>
					</div>
				  </div>
				
				<div class="">
					<div id="slider-5" class="carousel carousel-by-item slide" data-ride="carousel">
						<div class="carousel-inner" role="listbox">
						
							<div class="carousel-item active">
									<div class="col-lg-2 col-md-3 col-sm-4 col-12">
										<a href="<?php echo e(route('details',$healthstore->slug)); ?>">
										<img class="d-block img-fluid" src="<?php echo e(asset('public/front/pharmacy').'/'.$healthstore->image); ?>" alt="<?php echo e($healthstore->name); ?>">
										</a>
										<div class="product_text  text-center">
										  <div class="bold_text"><?php echo e($healthstore->name); ?></div>
										  <div><small> <s>₹ <?php echo e($healthstore->oldprice); ?></s> </small> <b class="f-14"><?php echo e($healthstore->newprice); ?></b></div>
										  <button style="width: 100%;" type="button" value="<?php echo e($healthstore->id); ?>"  class="mt-2 blue_color_border add-to-cart" >Add to Cart</button>
										  
										</div>
									</div>
								</div>
							<?php $__currentLoopData = $healthstores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $healthstore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 					  
								<div class="carousel-item">
									<div class="col-lg-2 col-md-3 col-sm-4 col-12">
										<a href="<?php echo e(route('details',$healthstore->slug)); ?>">
										<img class="d-block img-fluid" src="<?php echo e(asset('public/front/pharmacy').'/'.$healthstore->image); ?>" alt="<?php echo e($healthstore->name); ?>">
										</a>
										<div class="product_text  text-center">
										  <div class="bold_text"><?php echo e($healthstore->name); ?></div>
										  <div><small> <s>₹ <?php echo e($healthstore->oldprice); ?></s> </small> <b class="f-14"><?php echo e($healthstore->newprice); ?></b></div>
										  <button style="width: 100%;" type="button" value="<?php echo e($healthstore->id); ?>"  class="mt-2 blue_color_border add-to-cart" >Add to Cart</button>
										  
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								 
						</div>
						<a class="carousel-control-prev" href="#slider-5" role="button" data-slide="prev">
							<span class="carousel-control-prev-icon" aria-hidden="true"></span>
							<span class="sr-only">Previous</span>
						</a>
						<a class="carousel-control-next" href="#slider-5" role="button" data-slide="next">
							<span class="carousel-control-next-icon" aria-hidden="true"></span>
							<span class="sr-only">Next</span>
						</a>
					</div>
				</div>
			</div>
		</div>
	<?php endif; ?>	

<div class="container my-4">
  <div class="row ">

    <!--Carousel Wrapper-->
    <div id="customers" class="carousel slide carousel-multi-item m-auto" data-ride="carousel" data-interval="false">

      <!--Controls-->
      <div class="controls-top">
        <a class="btn-floating left" href="#customers" data-slide="prev"><i class="fa fa-chevron-left"></i></a>
        <a class="btn-floating right" href="#customers" data-slide="next"><i class="fa fa-chevron-right"></i></a>
      </div>
      <!--/.Controls-->
      <div class="container">
      <div class="row mt-5">
        <div class="heading_section mb-4">
          <div class="col-md-12"><h4 class="align-center mb-5"><b>What Our Customers Say?</b></h4></div>
        </div>
      </div>
        </div>
      <!--Slides-->
      <div class="carousel-inner popular testi" role="listbox">
        

        <!--First slide-->
        <div class="carousel-item active ">

          <div class="row">
            
            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
            <div class="col-md-4 col-4 col-xl-4 col-lg-4">
              <div class="mb-2 align-center">
                  
                  <img class="customer_profile" src="<?php echo e(asset('public/front/testimonials').'/'.$testimonial->image); ?>">
                  
            </div>
              <div class="mb-2 align-center">
                
                <div class="">
                  
                  <div class="rating">
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star"></span>
                    <span class="fa fa-star"></span>
                  </div>
                <div class="product_text">
                  <div><small><?php echo e($testimonial->content); ?></small></div>
                  <h6 class="mt-3"><b><?php echo e($testimonial->name); ?></b></h6>
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </div>

        </div>
        
        <!--First slide-->
        <div class="carousel-item">

          <div class="row">
            
            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
            <div class="col-md-4 col-4 col-xl-4 col-lg-4">
              <div class="mb-2 align-center"><img class="customer_profile" src="<?php echo e(asset('public/front/testimonials').'/'.$testimonial->image); ?>"></div>
              <div class="mb-2 align-center">
                
                <div class="">
                  
                  <div class="rating">
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star"></span>
                    <span class="fa fa-star"></span>
                  </div>
                <div class="product_text">
                  <div><small><?php echo e($testimonial->content); ?></small></div>
                  <h6 class="mt-3"><b><?php echo e($testimonial->name); ?></b></h6>
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </div>

        </div>




      </div>
      <!--/.Slides-->

    </div>
    <!--/.Carousel Wrapper-->
  </div>

</div>

<!---->
<script>
  function GetUnique(e) {
    var l = [],
        s = temp_c = [],
        t = ["col-md-1", "col-md-2", "col-md-3", "col-md-4", "col-md-6", "col-md-12", "col-sm-1", "col-sm-2", "col-sm-3", "col-sm-4", "col-sm-6", "col-sm-12", "col-lg-1", "col-lg-2", "col-lg-3", "col-lg-4", "col-lg-6", "col-lg-12", "col-xs-1", "col-xs-2", "col-xs-3", "col-xs-4", "col-xs-6", "col-xs-12", "col-xl-1", "col-xl-2", "col-xl-3", "col-xl-4", "col-xl-6", "col-xl-12"];
    $(e).each(function() {
        for (var l = $(e + " > div").attr("class").split(/\s+/), t = 0; t < l.length; t++) s.push(l[t])
    });
    for (var c = 0; c < s.length; c++) temp_c = s[c].split("-"), 2 == temp_c.length && (temp_c.push(""), temp_c[2] = temp_c[1], temp_c[1] = "xs", s[c] = temp_c.join("-")), -1 == $.inArray(s[c], l) && $.inArray(s[c], t) && l.push(s[c]);
    return l
}

function setcss(e, l, s) {
    for (var t = ["", "", "", "", "", ""], c = d = f = g = 0, r = [1200, 992, 768, 567, 0], o = [], a = 0; a < e.length; a++) {
        var i = e[a].split("-");
        if (3 == i.length) {
            switch (i[1]) {
                case "xl":
                    d = 0;
                    break;
                case "lg":
                    d = 1;
                    break;
                case "md":
                    d = 2;
                    break;
                case "sm":
                    d = 3;
                    break;
                case "xs":
                    d = 4
            }
            t[d] = i[2]
        }
    }
    for (var n = 0; n < t.length; n++)
        if ("" !== t[n]) {
            if (0 === c && (c = 12 / t[n]), f = 12 / t[n], g = 100 / f, a = s + " > .carousel-item.active.carousel-item-right," + s + " > .carousel-item.carousel-item-next {-webkit-transform: translate3d(" + g + "%, 0, 0);transform: translate3d(" + g + ", 0, 0);left: 0;}" + s + " > .carousel-item.active.carousel-item-left," + s + " > .carousel-item.carousel-item-prev {-webkit-transform: translate3d(-" + g + "%, 0, 0);transform: translate3d(-" + g + "%, 0, 0);left: 0;}" + s + " > .carousel-item.carousel-item-left, " + s + " > .carousel-item.carousel-item-prev.carousel-item-right, " + s + " > .carousel-item.active {-webkit-transform: translate3d(0, 0, 0);transform: translate3d(0, 0, 0);left: 0;}", f > 1) {
                for (k = 0; k < f - 1; k++) o.push(l + " .cloneditem-" + k);
                o.length && (a = a + o.join(",") + "{display: block;}"), o = []
            }
            0 !== r[n] && (a = "@media  all and (min-width: " + r[n] + "px) {" + a + "}"), $("#slider-css").prepend(a)
        } $(l).each(function() {
        for (var e = $(this), l = 0; l < c - 1; l++)(e = e.next()).length || (e = $(this).siblings(":first")), e.children(":first-child").clone().addClass("cloneditem-" + l).appendTo($(this))
    })
}

//Use Different Slider IDs for multiple slider
$(document).ready(function() {
    var item = '#slider-1 .carousel-item';
    var item_inner = "#slider-1 .carousel-inner";
    classes = GetUnique(item);
    setcss(classes, item, item_inner);


    var item_1 = '#slider-2 .carousel-item';
    var item_inner_1 = "#slider-2 .carousel-inner";
    classes = GetUnique(item_1);
    setcss(classes, item_1, item_inner_1);
});
</script>

<!--SLIDER 3-->
 <script>
  function GetUnique(e) {
    var l = [],
        s = temp_c = [],
        t = ["col-md-1", "col-md-2", "col-md-3", "col-md-4", "col-md-6", "col-md-12", "col-sm-1", "col-sm-2", "col-sm-3", "col-sm-4", "col-sm-6", "col-sm-12", "col-lg-1", "col-lg-2", "col-lg-3", "col-lg-4", "col-lg-6", "col-lg-12", "col-xs-1", "col-xs-2", "col-xs-3", "col-xs-4", "col-xs-6", "col-xs-12", "col-xl-1", "col-xl-2", "col-xl-3", "col-xl-4", "col-xl-6", "col-xl-12"];
    $(e).each(function() {
        for (var l = $(e + " > div").attr("class").split(/\s+/), t = 0; t < l.length; t++) s.push(l[t])
    });
    for (var c = 0; c < s.length; c++) temp_c = s[c].split("-"), 2 == temp_c.length && (temp_c.push(""), temp_c[2] = temp_c[1], temp_c[1] = "xs", s[c] = temp_c.join("-")), -1 == $.inArray(s[c], l) && $.inArray(s[c], t) && l.push(s[c]);
    return l
}

function setcss(e, l, s) {
    for (var t = ["", "", "", "", "", ""], c = d = f = g = 0, r = [1200, 992, 768, 567, 0], o = [], a = 0; a < e.length; a++) {
        var i = e[a].split("-");
        if (3 == i.length) {
            switch (i[1]) {
                case "xl":
                    d = 0;
                    break;
                case "lg":
                    d = 1;
                    break;
                case "md":
                    d = 2;
                    break;
                case "sm":
                    d = 3;
                    break;
                case "xs":
                    d = 4
            }
            t[d] = i[2]
        }
    }
    for (var n = 0; n < t.length; n++)
        if ("" !== t[n]) {
            if (0 === c && (c = 12 / t[n]), f = 12 / t[n], g = 100 / f, a = s + " > .carousel-item.active.carousel-item-right," + s + " > .carousel-item.carousel-item-next {-webkit-transform: translate3d(" + g + "%, 0, 0);transform: translate3d(" + g + ", 0, 0);left: 0;}" + s + " > .carousel-item.active.carousel-item-left," + s + " > .carousel-item.carousel-item-prev {-webkit-transform: translate3d(-" + g + "%, 0, 0);transform: translate3d(-" + g + "%, 0, 0);left: 0;}" + s + " > .carousel-item.carousel-item-left, " + s + " > .carousel-item.carousel-item-prev.carousel-item-right, " + s + " > .carousel-item.active {-webkit-transform: translate3d(0, 0, 0);transform: translate3d(0, 0, 0);left: 0;}", f > 1) {
                for (k = 0; k < f - 1; k++) o.push(l + " .cloneditem-" + k);
                o.length && (a = a + o.join(",") + "{display: block;}"), o = []
            }
            0 !== r[n] && (a = "@media  all and (min-width: " + r[n] + "px) {" + a + "}"), $("#slider-css").prepend(a)
        } $(l).each(function() {
        for (var e = $(this), l = 0; l < c - 1; l++)(e = e.next()).length || (e = $(this).siblings(":first")), e.children(":first-child").clone().addClass("cloneditem-" + l).appendTo($(this))
    })
}

//Use Different Slider IDs for multiple slider
$(document).ready(function() {
    var item = '#slider-3 .carousel-item';
    var item_inner = "#slider-3 .carousel-inner";
    classes = GetUnique(item);
    setcss(classes, item, item_inner);


    // var item_1 = '#slider-3 .carousel-item';
    // var item_inner_1 = "#slider-3 .carousel-inner";
    // classes = GetUnique(item_1);
    // setcss(classes, item_1, item_inner_1);
});
</script>



<!--SLIDER 4-->
 <script>
  function GetUnique(e) {
    var l = [],
        s = temp_c = [],
        t = ["col-md-1", "col-md-2", "col-md-3", "col-md-4", "col-md-6", "col-md-12", "col-sm-1", "col-sm-2", "col-sm-3", "col-sm-4", "col-sm-6", "col-sm-12", "col-lg-1", "col-lg-2", "col-lg-3", "col-lg-4", "col-lg-6", "col-lg-12", "col-xs-1", "col-xs-2", "col-xs-3", "col-xs-4", "col-xs-6", "col-xs-12", "col-xl-1", "col-xl-2", "col-xl-3", "col-xl-4", "col-xl-6", "col-xl-12"];
    $(e).each(function() {
        for (var l = $(e + " > div").attr("class").split(/\s+/), t = 0; t < l.length; t++) s.push(l[t])
    });
    for (var c = 0; c < s.length; c++) temp_c = s[c].split("-"), 2 == temp_c.length && (temp_c.push(""), temp_c[2] = temp_c[1], temp_c[1] = "xs", s[c] = temp_c.join("-")), -1 == $.inArray(s[c], l) && $.inArray(s[c], t) && l.push(s[c]);
    return l
}

function setcss(e, l, s) {
    for (var t = ["", "", "", "", "", ""], c = d = f = g = 0, r = [1200, 992, 768, 567, 0], o = [], a = 0; a < e.length; a++) {
        var i = e[a].split("-");
        if (3 == i.length) {
            switch (i[1]) {
                case "xl":
                    d = 0;
                    break;
                case "lg":
                    d = 1;
                    break;
                case "md":
                    d = 2;
                    break;
                case "sm":
                    d = 3;
                    break;
                case "xs":
                    d = 4
            }
            t[d] = i[2]
        }
    }
    for (var n = 0; n < t.length; n++)
        if ("" !== t[n]) {
            if (0 === c && (c = 12 / t[n]), f = 12 / t[n], g = 100 / f, a = s + " > .carousel-item.active.carousel-item-right," + s + " > .carousel-item.carousel-item-next {-webkit-transform: translate3d(" + g + "%, 0, 0);transform: translate3d(" + g + ", 0, 0);left: 0;}" + s + " > .carousel-item.active.carousel-item-left," + s + " > .carousel-item.carousel-item-prev {-webkit-transform: translate3d(-" + g + "%, 0, 0);transform: translate3d(-" + g + "%, 0, 0);left: 0;}" + s + " > .carousel-item.carousel-item-left, " + s + " > .carousel-item.carousel-item-prev.carousel-item-right, " + s + " > .carousel-item.active {-webkit-transform: translate3d(0, 0, 0);transform: translate3d(0, 0, 0);left: 0;}", f > 1) {
                for (k = 0; k < f - 1; k++) o.push(l + " .cloneditem-" + k);
                o.length && (a = a + o.join(",") + "{display: block;}"), o = []
            }
            0 !== r[n] && (a = "@media  all and (min-width: " + r[n] + "px) {" + a + "}"), $("#slider-css").prepend(a)
        } $(l).each(function() {
        for (var e = $(this), l = 0; l < c - 1; l++)(e = e.next()).length || (e = $(this).siblings(":first")), e.children(":first-child").clone().addClass("cloneditem-" + l).appendTo($(this))
    })
}

//Use Different Slider IDs for multiple slider
$(document).ready(function() {
    var item = '#slider-4 .carousel-item';
    var item_inner = "#slider-4 .carousel-inner";
    classes = GetUnique(item);
    setcss(classes, item, item_inner);


    // var item_1 = '#slider-3 .carousel-item';
    // var item_inner_1 = "#slider-3 .carousel-inner";
    // classes = GetUnique(item_1);
    // setcss(classes, item_1, item_inner_1);
});
</script>



<!--SLIDER 5-->
 <script>
  function GetUnique(e) {
    var l = [],
        s = temp_c = [],
        t = ["col-md-1", "col-md-2", "col-md-3", "col-md-4", "col-md-6", "col-md-12", "col-sm-1", "col-sm-2", "col-sm-3", "col-sm-4", "col-sm-6", "col-sm-12", "col-lg-1", "col-lg-2", "col-lg-3", "col-lg-4", "col-lg-6", "col-lg-12", "col-xs-1", "col-xs-2", "col-xs-3", "col-xs-4", "col-xs-6", "col-xs-12", "col-xl-1", "col-xl-2", "col-xl-3", "col-xl-4", "col-xl-6", "col-xl-12"];
    $(e).each(function() {
        for (var l = $(e + " > div").attr("class").split(/\s+/), t = 0; t < l.length; t++) s.push(l[t])
    });
    for (var c = 0; c < s.length; c++) temp_c = s[c].split("-"), 2 == temp_c.length && (temp_c.push(""), temp_c[2] = temp_c[1], temp_c[1] = "xs", s[c] = temp_c.join("-")), -1 == $.inArray(s[c], l) && $.inArray(s[c], t) && l.push(s[c]);
    return l
}

function setcss(e, l, s) {
    for (var t = ["", "", "", "", "", ""], c = d = f = g = 0, r = [1200, 992, 768, 567, 0], o = [], a = 0; a < e.length; a++) {
        var i = e[a].split("-");
        if (3 == i.length) {
            switch (i[1]) {
                case "xl":
                    d = 0;
                    break;
                case "lg":
                    d = 1;
                    break;
                case "md":
                    d = 2;
                    break;
                case "sm":
                    d = 3;
                    break;
                case "xs":
                    d = 4
            }
            t[d] = i[2]
        }
    }
    for (var n = 0; n < t.length; n++)
        if ("" !== t[n]) {
            if (0 === c && (c = 12 / t[n]), f = 12 / t[n], g = 100 / f, a = s + " > .carousel-item.active.carousel-item-right," + s + " > .carousel-item.carousel-item-next {-webkit-transform: translate3d(" + g + "%, 0, 0);transform: translate3d(" + g + ", 0, 0);left: 0;}" + s + " > .carousel-item.active.carousel-item-left," + s + " > .carousel-item.carousel-item-prev {-webkit-transform: translate3d(-" + g + "%, 0, 0);transform: translate3d(-" + g + "%, 0, 0);left: 0;}" + s + " > .carousel-item.carousel-item-left, " + s + " > .carousel-item.carousel-item-prev.carousel-item-right, " + s + " > .carousel-item.active {-webkit-transform: translate3d(0, 0, 0);transform: translate3d(0, 0, 0);left: 0;}", f > 1) {
                for (k = 0; k < f - 1; k++) o.push(l + " .cloneditem-" + k);
                o.length && (a = a + o.join(",") + "{display: block;}"), o = []
            }
            0 !== r[n] && (a = "@media  all and (min-width: " + r[n] + "px) {" + a + "}"), $("#slider-css").prepend(a)
        } $(l).each(function() {
        for (var e = $(this), l = 0; l < c - 1; l++)(e = e.next()).length || (e = $(this).siblings(":first")), e.children(":first-child").clone().addClass("cloneditem-" + l).appendTo($(this))
    })
}

//Use Different Slider IDs for multiple slider
$(document).ready(function() {
    var item = '#slider-5 .carousel-item';
    var item_inner = "#slider-5 .carousel-inner";
    classes = GetUnique(item);
    setcss(classes, item, item_inner);


    // var item_1 = '#slider-3 .carousel-item';
    // var item_inner_1 = "#slider-3 .carousel-inner";
    // classes = GetUnique(item_1);
    // setcss(classes, item_1, item_inner_1);
});
</script>

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  
    <script type="text/javascript">
		
		$(document).ready(function() {
          $('.add-to-cart').on('click',function () {
            
            var productId = $(this).val();
            var qty = 1;
			
			$.ajax({
				type: 'GET',
				url: "<?php echo e(route('addtocart')); ?>",
				data: {productId: productId,qty: qty},
				success:function(res){
					location.reload(true);
				}
			})
			return false;			

          });
          
          /********* Lab Test Start **************/
          
          $('.add-to-cart-lab').on('click',function () {
            
            var labId = $(this).val();

            var qty = 1;
			
			$.ajax({
				type: 'GET',
				url: "<?php echo e(route('addtocart-lab')); ?>",
				data: {labId: labId,qty: qty},
				success:function(res){
					location.reload(true);
				}
			})
			return false;			

          });
          
          /********* Lab Test End **************/
          
        
        });
		
		
    </script>
<?php /**PATH /home/u769120014/domains/diagnomitra.com/public_html/resources/views/front/index.blade.php ENDPATH**/ ?>