<!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <h3><img src="<?php echo e(asset('public/front/')); ?>/assets/img/Socidom.png" width="200px"></h3>
      <div class="">
        <a href="<?php echo e(route('work')); ?>" style="color:#fff">What we do? | </a>
        <a href="<?php echo e(route('media')); ?>" style="color:#fff">Why Social Media? | </a>
        <a href="<?php echo e(route('pricing')); ?>" style="color:#fff">Pricing | </a>
        <a href="#" style="color:#fff">Our Team | </a>
        <a href="<?php echo e(route('contact')); ?>" style="color:#fff">Contact</a>
      </div></br>
      <div class="">
        <a href="<?php echo e(route('about')); ?>" style="color:#fff">About | </a>
        <a href="<?php echo e(route('career')); ?>" style="color:#fff">Career | </a>
        <a href="<?php echo e(route('client')); ?>" style="color:#fff">Our Client | </a>
        <a href="<?php echo e(route('blog')); ?>" style="color:#fff">Blog | </a>
        <a href="#" style="color:#fff">Privacy</a>
      </div></br>
      <div class="social-links">
        <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
      <div class="copyright">
        &copy; Copyright <strong><span>Socidom </span></strong>. All Rights Reserved
      </div>
      
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo e(asset('public/front/')); ?>/assets/vendor/jquery/jquery.min.js"></script>
  <script src="<?php echo e(asset('public/front/')); ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo e(asset('public/front/')); ?>/assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="<?php echo e(asset('public/front/')); ?>/assets/vendor/php-email-form/validate.js"></script>
  <script src="<?php echo e(asset('public/front/')); ?>/assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="<?php echo e(asset('public/front/')); ?>/assets/vendor/venobox/venobox.min.js"></script>
  <script src="<?php echo e(asset('public/front/')); ?>/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo e(asset('public/front/')); ?>/assets/js/main.js"></script>

</body>

</html><?php /**PATH C:\xampp\htdocs\socid\resources\views/front/footer.blade.php ENDPATH**/ ?>