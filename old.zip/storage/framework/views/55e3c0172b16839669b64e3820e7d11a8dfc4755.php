<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->s

<head>
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css">
</head>
<style>
h3, h4{
    margin: 0 0 14px !important;
}
/*******************************
* Does not work properly if "in" is added after "collapse".
* Get free snippets on bootpen.com
*******************************/
.panel {
    margin-bottom:0px !important;
    background-color:none !important; 
    border:none !important;
     border-radius:none
    -webkit-box-shadow: 0 0px 0px rgba(0,0,0,0); 
    /*border-bottom: 1px solid grey !important;*/
    box-shadow: 0 0px 0px rgba(0,0,0,0) !important; */
}
    .panel-group .panel {
        border-radius: 0;
        box-shadow: none;
        border-color: #EEEEEE;
    }

    .panel-default > .panel-heading {
        /*padding: 0;*/
        /*border-radius: 0;*/
        /*color: #212121;*/
        /*background-color: #FAFAFA;*/
        /*border-color: #EEEEEE;*/
    }

    .panel-title {
        font-size: 14px;
    }

    .panel-title > a {
        display: block;
        padding: 15px;
        text-decoration: none;
    }

    .more-less {
        float: right;
        color: #212121;
    }

    .panel-default > .panel-heading + .panel-collapse > .panel-body {
        border-top-color: #EEEEEE;
        background: #f6f6f6;
    }


/* ----- v CAN BE DELETED v ----- */
body {
    /*background-color: #26a69a;*/
}

.demo {
    padding-top:43px;
    padding-bottom: 20px;
}


.quote {
    color: rgba(0,0,0,.1);
    text-align: center;
    margin-bottom: 30px;
}

/*-------------------------------*/
/*    Carousel Fade Transition   */
/*-------------------------------*/

#fade-quote-carousel.carousel {
  padding-bottom: 60px;
}
#fade-quote-carousel.carousel .carousel-inner .item {
  opacity: 0;
  -webkit-transition-property: opacity;
      -ms-transition-property: opacity;
          transition-property: opacity;
}
#fade-quote-carousel.carousel .carousel-inner .active {
  opacity: 1;
  -webkit-transition-property: opacity;
      -ms-transition-property: opacity;
          transition-property: opacity;
}
#fade-quote-carousel.carousel .carousel-indicators {
  bottom: 10px;
}
#fade-quote-carousel.carousel .carousel-indicators > li {
  background-color: #e84a64;
  border: none;
}
#fade-quote-carousel blockquote {
    text-align: center;
    border: none;
}
#fade-quote-carousel .profile-circle {
    width: 100px;
    height: 100px;
    margin: 0 auto;
    border-radius: 100px;
}


    .fgp{
        display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex: 1 1 50%;
    -ms-flex: 1 1 50%;
    flex: 1 1 50%;
    margin: 6px;
    padding: 24px;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    background-color: #faece9;
}
    .fgp2{
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex: 1 1 50%;
    -ms-flex: 1 1 50%;
    flex: 1 1 50%;
    margin: 6px;
    padding: 24px;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    background-color: #f8f4eb;
}
 .bhj{
    width: 254px;
    height: 88px;
    background-color: #ffffff;
    padding: 20px;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    margin-top: 30px;
    position: relative;
}
  .1ygdp2w a {
    font-family: 'MuliSemiBold','Helvetica Neue',Helvetica,Arial,sans-serif;
    font-size: 1.8rem;
    color: #8863fb;
  }
  .css-6yxsag {
    margin: 0;
    padding: 0;
    display: block;
    -webkit-text-decoration: none;
    text-decoration: none;
    outline: 0;
    cursor: pointer;
    font-family: muliregular;
    color: inherit;
    font-size: inherit;
}
</style>
<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="">
    <img src="<?php echo e(asset('public/front/images/try.jpg')); ?>" style="width:100%;height:420px;">
</div>
<div class="container-fluid" >
    <div class="row" style="padding: 30px 32px; margin: 0px -27px;">
        <div class="col-md-6" >
            <div  class="fgp">
                <div><img src="<?php echo e(asset('public/front/images/tq.png')); ?>" >
            </div>
            <div>
            <h4>Give Her the Gift of Choice!</h4><p>Book a surprise Try at Home and let her pick from 5 stunning designs.</p>
            </div>
            </div>
        </div>
         <div class="col-md-6">
             <div class="fgp2">
                 <div><img src="<?php echo e(asset('public/front/images/tah.png')); ?>" ></div>
                 <div> <h4 style="padding: 20px;">Ensure the Perfect Fit..</h4>
                 </div>
                 </div>
                 </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-6">
        <div style="text-align:center;"> <h1>It Doesn't Get Easier than This!</h1>
        <p>It’s free and there’s no obligation to buy!</p> </div>
        </div>
       <div class="col-sm-3"></div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-sm-4">
            <div style="text-align:center;"><img src="<?php echo e(asset('public/front/images/silver-number-1.jpg')); ?>" style="width:30%;height:135px"> </div>
            <div><h4>Pick Your 5 Favourite Designs!</h4></div>
            <div><p>Choose the designs that you want to try. Try up to 5 designs in the comfort of your home :)</p></div>
        </div>
         <div class="col-sm-4">
             <div style="text-align:center;"><img src="<?php echo e(asset('public/front/images/kiw.jpg')); ?>" style="width:30%;height:135px"> </div>
            <div><h4>Book a Free Try@Home Appointment</h4></div>
            <div><p>Our Try@Home consultants will get you your chosen designs - at home or at work!</p></div>
         </div>
          <div class="col-sm-4">
              <div style="text-align:center;"><img src="<?php echo e(asset('public/front/images/g1.jpg')); ?>" style="width:30%;height:135px"> </div>
            <div><h4>Buy Only if You Like</h4></div>
            <div><p>Love the designs? Buy on the spot ;) And if you don't like it, there's no obligation to buy!</p></div>
          </div>
    </div>
</div>

<br/><br/>
<div class="container">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
        <h2 style="text-align:center">Hear it from Our Customers</h3>
        
        </div>
        <div class="col-md-3"></div>
        </div>
        </div>
        
<section id="carousel">    				
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
                <div class=""><i class="fa fa-quote-left fa-4x"></i></div>
				<div class="carousel slide" id="fade-quote-carousel" data-ride="carousel" data-interval="3000">
				  <!-- Carousel indicators -->
                  <ol class="carousel-indicators">
				    <li data-target="#fade-quote-carousel" data-slide-to="0" class="active"></li>
				    <li data-target="#fade-quote-carousel" data-slide-to="1"></li>
				    <li data-target="#fade-quote-carousel" data-slide-to="2"></li>
				  </ol>
				  <!-- Carousel items -->
				  <div class="carousel-inner">
				    <div class="active item">
				    	<blockquote>
				    		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem, veritatis nulla eum laudantium totam tempore optio doloremque laboriosam quas, quos eaque molestias odio aut eius animi. Impedit temporibus nisi accusamus.</p>
				    	</blockquote>
				    	<div class="profile-circle" style="background-color: rgba(0,0,0,.2);"></div>
				    </div>
				    <div class="item">
				    	<blockquote>
				    		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem, veritatis nulla eum laudantium totam tempore optio doloremque laboriosam quas, quos eaque molestias odio aut eius animi. Impedit temporibus nisi accusamus.</p>
				    	</blockquote>
				    	<div class="profile-circle" style="background-color: rgba(77,5,51,.2);"></div>
				    </div>
				    <div class="item">
				    	<blockquote>
				    		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem, veritatis nulla eum laudantium totam tempore optio doloremque laboriosam quas, quos eaque molestias odio aut eius animi. Impedit temporibus nisi accusamus.</p>
				    	</blockquote>
				    	<div class="profile-circle" style="background-color: rgba(145,169,216,.2);"></div>
				    </div>
				  </div>
				</div>
			</div>							
		</div>
	</div>
</section>
<section style="width: 100%;padding: 24px;background-color: #f6f6f6;">
    <div class="container">
        <div class="row">
            <div class=" col-sm-4">
                <h3>Have Some Questions?</h3>
                <div class="row" style="background: white; width: 100%; padding: 6px;">
                    <div class="col-md-4">
                        <div>
                        <img src="<?php echo e(asset('public/front/images/stq.png')); ?>" style="width: 100%;min-width: 75%;">
                    </div>
                     </div>
                     <div class="col-md-8">
                         <div style="padding: 15px;">
                        <p>Just give us a call at</p>
                    <a href="tel:1800-102-0103" >1800-102-0103</a>
                    </div>
                    </div>
                </div>
                </div>
           

            <div class="col-sm-8">
                <div class="container demo">
     <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
<div class="panel panel-default">
            <div class="panel-heading" role="tab" id="headingOne">
                <h4 class="panel-title">
                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        <i class="more-less glyphicon glyphicon-plus"></i>
                       Q.What is Try at Home?
                    </a>
                </h4>
            </div>
            <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                <div class="panel-body">
                      Try at Home is a service that you can avail to try our designs in the comfort of your home.
                      It is a free service, with absolutely no obligation to buy.
                      All you have to do is pick your favourite designs, and 
                      schedule an appointment as per your convenience.
                </div>
            </div>
        </div>

        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="headingTwo">
                <h4 class="panel-title">
                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                        <i class="more-less glyphicon glyphicon-plus"></i>
                        Q.Is Try at Home available outside India?
                    </a>
                </h4>
            </div>
            <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                <div class="panel-body">
                    No, Try at Home is available only within India.
                </div>
            </div>
        </div>

        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="headingThree">
                <h4 class="panel-title">
                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                        <i class="more-less glyphicon glyphicon-plus"></i>
                        Q.Which are the cities in which this service is available?.
                    </a>
                </h4>
            </div>
            <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                <div class="panel-body">
                   Try at Home service is currently available in Bengaluru, Chennai, Delhi-NCR, Hyderabad, Kolkata &amp; Pune.
                </div>
            </div>
        </div>
        
        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="headingThree">
                <h4 class="panel-title">
                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree1" aria-expanded="false" aria-controls="collapseThree">
                        <i class="more-less glyphicon glyphicon-plus"></i>
                        Q.Is the Try at Home service free?
                    </a>
                </h4>
            </div>
            <div id="collapseThree1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                <div class="panel-body">
                    Yes, there are absolutely no charges for Try at Home.
                </div>
            </div>
        </div>
        
        
        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="headingThree">
                <h4 class="panel-title">
                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree2" aria-expanded="false" aria-controls="collapseThree">
                        <i class="more-less glyphicon glyphicon-plus"></i>
                        Q.Which products can I try?
                    </a>
                </h4>
            </div>
            <div id="collapseThree2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                <div class="panel-body">
                   The products available for you are based on your location. 
                   Once you enter your pincode on the Try at Home page, you can select any of those designs.
                </div>
            </div>
        </div>
        
        
        
        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="headingThree">
                <h4 class="panel-title">
                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree3" aria-expanded="false" aria-controls="collapseThree">
                        <i class="more-less glyphicon glyphicon-plus"></i>
                       Q.How many products can I try?
                    </a>
                </h4>
            </div>
            <div id="collapseThree3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                <div class="panel-body">
                    You can select up to 5 products for Try at Home.
                    If you would like to select a few more designs
                    to try, please contact us on 1800-102-0103 (Toll Free), and we will help you with it.
                </div>
            </div>
        </div>
        
        
        
        
        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="headingThree">
                <h4 class="panel-title">
                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree4" aria-expanded="false" aria-controls="collapseThree">
                        <i class="more-less glyphicon glyphicon-plus"></i>
                        Q.How will you send me the products for trial?
                    </a>
                </h4>
            </div>
            <div id="collapseThree4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                <div class="panel-body">
                    Our Try at Home consultant will visit your location to show you the designs, at a time and place that is convenient to you. 
                </div>
            </div>
        </div>
        
        
        
        
        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="headingThree">
                <h4 class="panel-title">
                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree5" aria-expanded="false" aria-controls="collapseThree">
                        <i class="more-less glyphicon glyphicon-plus"></i>
                       Q.Can I request for a Try at Home at my office?
                    </a>
                </h4>
            </div>
            <div id="collapseThree5" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                <div class="panel-body">
                   Absolutely! You can request for the appointment to take place at your office, or any other indoor location.
                </div>
            </div>
        </div>
        
        
        
        
        
        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="headingThree">
                <h4 class="panel-title">
                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree6" aria-expanded="false" aria-controls="collapseThree">
                        <i class="more-less glyphicon glyphicon-plus"></i>
                        Q.What if the date or time slot convenient to me is not available?
                    </a>
                </h4>
            </div>
            <div id="collapseThree6" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                <div class="panel-body">
                   In such cases, we request you to contact us on 1800-102-0103 (Toll Free), and we will try to arrange the appointment as per your convenience.
                </div>
            </div>
        </div>
        
        
        
        
        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="headingThree">
                <h4 class="panel-title">
                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree7" aria-expanded="false" aria-controls="collapseThree">
                        <i class="more-less glyphicon glyphicon-plus"></i>
                        Q.After trying on the products at home, can I place the order immediately?
                    </a>
                </h4>
            </div>
            <div id="collapseThree7" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                <div class="panel-body">
                    Yes, if you would like to purchase any of the designs you tried, you can place an order on the spot with our Try at Home consultant.
                </div>
            </div>
        </div>
        
        
        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="headingThree">
                <h4 class="panel-title">
                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree8" aria-expanded="false" aria-controls="collapseThree">
                        <i class="more-less glyphicon glyphicon-plus"></i>
                        Q.Are all the jewellery sent for the Try at Home appointment made of real gold?
                    </a>
                </h4>
            </div>
            <div id="collapseThree8" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                <div class="panel-body">
                    Yes, the jewellery we send to your home for trial is crafted with real gold and diamonds. 
                    If you place an order after the trial, you will receive the certificate of authenticity too.
                </div>
            </div>
        </div>
        

        
        
        
        

    </div><!-- panel-group -->
    
    
</div><!-- container -->
                
            </div>
        </div>
    </div>
</section>
<script>
    function toggleIcon(e) {
    $(e.target)
        .prev('.panel-heading')
        .find(".more-less")
        .toggleClass('glyphicon-plus glyphicon-minus');
}
$('.panel-group').on('hidden.bs.collapse', toggleIcon);
$('.panel-group').on('shown.bs.collapse', toggleIcon);
</script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script> 
                $(document).ready(function(){
                  $("#flip").click(function(){
                    $("#panel").toggle("slow");
                  });
                  
                
                });
            </script>
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/gold/resources/views/front/tryathome.blade.php ENDPATH**/ ?>