<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .rem input{
        width:3%;
    }
    .signup-form form{
        box-shadow: 0 2px 20px 0 rgba(0,0,0,.1);
        padding: 30px 25px;
    background: #fff;
    }
</style>
    <!-- Breadcrumb Section Begin -->
    
    
    <!-- Breadcrumb Section End -->
    
    <div class="py-4">
        <div class="container">
           
            <div class="signup-form">
                <h3 class="text-center pb-3">SignUp Form</h3>

                <form action="<?php echo e(route('postregister')); ?>" method="post" name="register" >
					<?php if(session('success')): ?>
						<div class="alert alert-success">
						<?php echo e(session('success')); ?>

						</div>
					<?php elseif(session('error')): ?>
						<div class="alert alert-danger">
						<?php echo e(session('error')); ?>

						</div>
					<?php endif; ?>

					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="alert alert-danger">
						<?php echo e($error); ?>

						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
                    <div class="row">
					
						<?php echo e(csrf_field()); ?>

                        <div class="col-lg-6 col-md-6">
                            <label for="fname"><b>First Name</b></label>
                            <input type="text" placeholder="First Name" name="first_name" required>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <label for="lname"><b>Last Name</b></label>
                            <input type="text" placeholder="Last Name" name="last_name" required>
                        </div>
                        <div class="col-lg-12 col-md-12">
                            <label for="uname"><b>Email</b></label>
                            <input type="email" placeholder="Enter Email Id" name="email" required>
                        </div>
                        <div class="col-lg-12 col-md-12">
                            <label for="add"><b>Address</b></label>
                            <input type="text" placeholder="Address" name="address" required>
                        </div>
                        <div class="col-lg-12 col-md-12">
                            <label for="psw"><b>Password</b></label>
                              <input type="password" placeholder="Enter Password" name="password" required>
                        </div>
                        
                        <div class="col-lg-12 col-md-12 pb-3">
                            <label for="psw"><b>Confirm Password</b></label>
                              <input type="password" placeholder="Confirm Password" name="c_password" required>
                        </div>
                        
                        
                        
                    </div>
                    
                        <div class="subButton ">
                            <input type="submit" name="submit" value="Submit" >
                            
                        </div>
                        <div class="py-3">
                            
                            <p class="message text-center">Already have an account?  <a href="<?php echo e(route('login')); ?>">Sign in.</a></p>
                        </div>
                        
                      
                </form>
            </div>        
            
        </div>
    </div>

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\socid\resources\views/front/register.blade.php ENDPATH**/ ?>