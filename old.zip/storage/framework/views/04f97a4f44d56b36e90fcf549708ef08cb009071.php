<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <div class="site-wrap">
   

    <div class="bg-light py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-12 mb-0"><a href="index.html">Home</a> <span class="mx-2 mb-0">/</span> <a href="cart.html">Cart</a> <span class="mx-2 mb-0">/</span> <strong class="text-black">Checkout</strong></div>
        </div>
      </div>
    </div>

    <div class="site-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-12">
            <?php if(!session('user')): ?>  
            <div class="border p-4 mt-3 rounded alert alert-danger" role="alert" >
              Returning customer? <a href="javascript:void(0)" data-toggle="modal" data-target="#join_popup" >Click here</a> to login
            </div>
            <?php endif; ?>
			
			<?php if($errors->all()): ?>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="alert alert-danger"><?php echo e($error); ?></div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>	
			
          </div>
        </div>
		<form name="checkout" method="post" action="<?php echo e(route('payment')); ?>" >
			<div class="row">
			  <div class="col-md-6 mb-5 mb-md-0">
				<h2 class="h3 mb-3 text-black">Billing Details</h2>
				<div class="p-3 p-lg-5 border">
				<?php echo e(@csrf_field()); ?>

				  <div class="form-group row">
					<div class="col-md-12">
					  <label for="c_fname" class="text-black">Full Name <span class="text-danger">*</span></label>
					  <input type="text" class="form-control" id="name" name="name" value="<?php if(isset($user->name)): ?><?php echo e($user->name); ?><?php endif; ?>">
					</div>
				  </div>
				  
				  <div class="form-group row">
					<div class="col-md-12">
					  <label for="c_fname" class="text-black">Email <span class="text-danger">*</span></label>
					  <input type="email" class="form-control" id="email" name="email" value="<?php if(isset($user->email)): ?><?php echo e($user->email); ?><?php endif; ?>">
					</div>
				  </div>
				  
				  <div class="form-group row">
					<div class="col-md-12">
					  <label for="c_fname" class="text-black">Mobile <span class="text-danger">*</span></label>
					  <input type="text" class="form-control" id="mobile" name="mobile" value="<?php if(isset($user->mobile)): ?><?php echo e($user->mobile); ?><?php endif; ?>">
					</div>
				  </div>

				  <div class="form-group row">
					<div class="col-md-12">
					  <label for="c_address" class="text-black">Address <span class="text-danger">*</span></label>
					  <input type="text" class="form-control" id="address" name="address" placeholder="Address" value="<?php if(isset($user->address)): ?><?php echo e($user->address); ?><?php endif; ?>">
					</div>
				  </div>

				  <div class="form-group">
					<input type="text" class="form-control" placeholder="Apartment, suite, unit etc. (optional)" address="address2">
				  </div>

				  <div class="form-group row">
					<div class="col-md-6">
					  <label for="c_state_country" class="text-black">City <span class="text-danger">*</span></label>
					  <input type="text" class="form-control" id="city" name="city" value="<?php if(isset($user->city)): ?><?php echo e($user->city); ?><?php endif; ?>" >
					</div>
					<div class="col-md-6">
					  <label for="c_postal_zip" class="text-black">State<span class="text-danger">*</span></label>
					  <input type="text" class="form-control" id="state" name="state" value="<?php if(isset($user->state)): ?><?php echo e($user->state); ?><?php endif; ?>">
					</div>
				  </div>
				  
				  <div class="form-group row">
					<div class="col-md-6">
					  <label for="c_state_country" class="text-black">Pincode <span class="text-danger">*</span></label>
					  <input type="text" class="form-control" id="pincode" name="pincode" value="<?php if(isset($user->pincode)): ?><?php echo e($user->pincode); ?><?php endif; ?>" >
					</div>
					<div class="col-md-6">
					  <label for="c_postal_zip" class="text-black">Country<span class="text-danger">*</span></label>
					  <input type="text" class="form-control" id="country" name="country" value="<?php if(isset($user->country)): ?><?php echo e($user->country); ?><?php endif; ?>">
					</div>
				  </div>

				  <div class="form-group">
					<label for="c_ship_different_address" class="text-black" data-toggle="collapse" href="#ship_different_address" role="button" aria-expanded="false" aria-controls="ship_different_address"><input type="checkbox" value="1" name="different_address" id="c_ship_different_address"> Ship To A Different Address?</label>
					<div class="collapse" id="ship_different_address">
					  <div class="py-2">

						  <div class="form-group row">
							<div class="col-md-12">
							  <label for="c_fname" class="text-black">Full Name <span class="text-danger">*</span></label>
							  <input type="text" class="form-control" id="shipping_name" name="shipping_name" value="<?php if(isset($user->shipping_name)): ?><?php echo e($user->shipping_name); ?><?php endif; ?>" >
							</div>
						  </div>
						  
						  <div class="form-group row">
							<div class="col-md-12">
							  <label for="c_fname" class="text-black">Email <span class="text-danger">*</span></label>
							  <input type="email" class="form-control" id="shipping_email" name="shipping_email" value="<?php if(isset($user->shipping_email)): ?><?php echo e($user->shipping_email); ?><?php endif; ?>">
							</div>
						  </div>
						  
						  <div class="form-group row">
							<div class="col-md-12">
							  <label for="c_fname" class="text-black">Mobile <span class="text-danger">*</span></label>
							  <input type="text" class="form-control" id="shipping_mobile" name="shipping_mobile" value="<?php if(isset($user->shipping_mobile)): ?><?php echo e($user->shipping_mobile); ?><?php endif; ?>">
							</div>
						  </div>
			
						  <div class="form-group row">
							<div class="col-md-12">
							  <label for="c_address" class="text-black">Address <span class="text-danger">*</span></label>
							  <input type="text" class="form-control" id="shipping_address" name="shipping_address" placeholder="Address" value="<?php if(isset($user->shipping_address)): ?><?php echo e($user->shipping_address); ?><?php endif; ?>">
							</div>
						  </div>
			
						  <div class="form-group">
							<input type="text" class="form-control" placeholder="Apartment, suite, unit etc. (optional)" address="shipping_address2">
						  </div>
			
						  <div class="form-group row">
							<div class="col-md-6">
							  <label for="c_state_country" class="text-black">City <span class="text-danger">*</span></label>
							  <input type="text" class="form-control" id="shipping_city" name="shipping_city" value="<?php if(isset($user->shipping_city)): ?><?php echo e($user->shipping_city); ?><?php endif; ?>" >
							</div>
							<div class="col-md-6">
							  <label for="c_postal_zip" class="text-black">State<span class="text-danger">*</span></label>
							  <input type="text" class="form-control" id="shipping_state" name="shipping_state" value="<?php if(isset($user->shipping_state)): ?><?php echo e($user->shipping_state); ?><?php endif; ?>">
							</div>
						  </div>
						  
						  <div class="form-group row">
							<div class="col-md-6">
							  <label for="c_state_country" class="text-black">Pincode <span class="text-danger">*</span></label>
							  <input type="text" class="form-control" id="shipping_pincode" name="shipping_pincode" value="<?php if(isset($user->shipping_pincode)): ?><?php echo e($user->shipping_pincode); ?><?php endif; ?>" >
							</div>
							<div class="col-md-6">
							  <label for="c_postal_zip" class="text-black">Country<span class="text-danger">*</span></label>
							  <input type="text" class="form-control" id="shipping_country" name="shipping_country" value="<?php if(isset($user->shipping_country)): ?><?php echo e($user->shipping_country); ?><?php endif; ?>">
							</div>
						  </div>

					  </div>

					</div>
				  </div>

				  <div class="form-group">
					<label for="c_order_notes" class="text-black">Order Notes</label>
					<textarea name="order_notes" id="c_order_notes" cols="30" rows="5" class="form-control" placeholder="Write your notes here..."></textarea>
				  </div>

				</div>
			  </div>
			  <div class="col-md-6">

				<div class="row mb-5">
				  <div class="col-md-12">
					<h2 class="h3 mb-3 text-black">Coupon Code</h2>
					<div class="p-3 p-lg-5 border">
					  
					  <label for="c_code" class="text-black mb-3">Enter your coupon code if you have one</label>
					  <div for="c_code" class="text-black mb-3 coupon-code-msg"></div>
					  <div class="input-group w-75">
					    <form name="coupon"> 
						<input type="text" class="form-control coupon-code" id="c_code" placeholder="Coupon Code" aria-label="Coupon Code" aria-describedby="button-addon2">
						<div class="input-group-append">
						  <button class="btn btn-primary btn-sm" type="button" id="apply-coupon">Apply</button>
						  
						</div>
						</form>
					  </div>

					</div>
				  </div>
				</div>
				
				<div class="row mb-5">
				  <div class="col-md-12">
					<h2 class="h3 mb-3 text-black">Your Order</h2>
					<div class="p-3 p-lg-5 border">
					  <table class="table site-block-order-table mb-5">
						<thead>
						<tr>
						  <th>Product</th>
						  <th>Price</th>
						  <th>Total</th>
						</tr>  
						</thead>
						<tbody>
						<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($cart->name); ?></td>
							<td><?php echo e($cart->price); ?> <strong class="mx-2">x</strong> <?php echo e($cart->quantity); ?></td>
							<td><?php echo e($cart->price*$cart->quantity); ?></td>
						  </tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
						  
						  <tr>
							<td class="text-black font-weight-bold"><strong>Order Total</strong></td>
							<td class="text-black font-weight-bold"></td>
							<td class="text-black font-weight-bold"><strong> <?php echo e($total); ?></strong></td>
						  </tr>
						  <tr>
							<td class="text-black font-weight-bold"><strong>Total Discount</strong></td>
							<td class="text-black font-weight-bold"></td>
							<td class="text-black font-weight-bold"><strong class="discount-amount">0</strong></td>
						  </tr>
						</tbody>
					  </table>

					  <div class="border p-3 mb-3">
						<h3 class="h6 mb-0"><a class="d-block" data-toggle="collapse" href="#collapsebank" role="button" aria-expanded="false" aria-controls="collapsebank">Direct Bank Transfer</a></h3>

						<div class="collapse" id="collapsebank">
						  <div class="py-2">
							<p class="mb-0">Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won’t be shipped until the funds have cleared in our account.</p>
						  </div>
						</div>
					  </div>

					  <div class="border p-3 mb-3">
						<h3 class="h6 mb-0"><a class="d-block" data-toggle="collapse" href="#collapsecheque" role="button" aria-expanded="false" aria-controls="collapsecheque">Cheque Payment</a></h3>

						<div class="collapse" id="collapsecheque">
						  <div class="py-2">
							<p class="mb-0">Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won’t be shipped until the funds have cleared in our account.</p>
						  </div>
						</div>
					  </div>

					  <div class="border p-3 mb-5">
						<h3 class="h6 mb-0"><a class="d-block" data-toggle="collapse" href="#collapsepaypal" role="button" aria-expanded="false" aria-controls="collapsepaypal">Paypal</a></h3>

						<div class="collapse" id="collapsepaypal">
						  <div class="py-2">
							<p class="mb-0">Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won’t be shipped until the funds have cleared in our account.</p>
						  </div>
						</div>
						<input type="hidden" class="discount-amount-value" value="0" name="discount_amount">
					  </div>
					<?php if(session('user')): ?>
					<div class="form-group">
						<button class="btn btn-primary btn-lg py-2 btn-block" >Place Order</button>
					</div>
					<?php else: ?>
					<div class="border p-4 mt-3 rounded alert alert-danger" role="alert" >
					<a href="javascript:void(0)" data-toggle="modal" data-target="#join_popup" >Click here</a> to login
					</div>
					<?php endif; ?>

					</div>
				  </div>
				</div>

			  </div>
			</div>
        </form>
      </div>
    </div>

    
  </div>
  
	<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  
    <script type="text/javascript">

		$(document).ready(function() {
          $('#apply-coupon').on('click',function () {

            var coupon = $('.coupon-code').val();

			$.ajax({
				type: 'GET',
				url: "<?php echo e(route('apply-coupon')); ?>",
				data: {coupon: coupon},
				success:function(res){
				    if(res.status == 1)
				    {
				        $('.discount-amount').text(res.amount);
				        $('.discount-amount-value').val(res.amount);
				        $('.coupon-code-msg').html(res.msg);
				    }else
				    {
				     	$('.discount-amount').text(res.amount);
				     	$('.discount-amount-value').val(res.amount);
				        $('.coupon-code-msg').html(res.msg);   
				    }
				    
				}
			})
			return false;			

          });
        
        });
		
		
    </script>  

 <?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diagno\resources\views/front/checkout.blade.php ENDPATH**/ ?>