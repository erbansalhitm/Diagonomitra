<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
    /* Change background color of buttons on hover */
.tablinks:hover {
  /*background-color: #ddd;*/
  color: #8eb359;;
}
.tablinks{
    cursor: pointer;
}
/* Create an active/current tablink class */
.tab .tablinks.active {
  color: #2874ef;
  border-bottom: 2px solid #2874ef;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  
  border-top: none;
}
.jk{
    height:325px;
}
.card {
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.3s;
  width: 80%;
  height:350px;
}

.card:hover {
  box-shadow: 5px 18px 20px 0 rgba(0,0,0,0.2);
}

.card .container {
  padding: 2px 16px;
}
 option{
    font-size:13px;
}
input[type="text"],input[type="email"]{
    font-size:15px;
}
</style>
<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="" style="border-radius: 5px;
    min-width: 106%;
    border: none;
    margin-top: 2%;
    margin-left: -4%;
    margin-bottom: 20px;
    padding: 5px;
    background: #f1f1f163;
    padding: 5px 15px;"><a href="">Product Details/ Yellow Regular Fit Shirt</a></div></div>

<div class="container-fliud">
    <div class="row">
        <div class="col-sm-5" style="padding: 40px 30px;">
<div class="container"> 
<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <div class="carousel-indicators" style="z-index:1;bottom: -150px !important;">
      <img src="<?php echo e(asset('public/front/images/cl.jpg')); ?>" data-target="#myCarousel" data-slide-to="0" class="active" alt="Los Angeles" style="width:30%; height:100px; margin: 0px 15px; border: 2px solid silver;">
        <img src="<?php echo e(asset('public/front/images/ki.jpg')); ?>" data-target="#myCarousel" data-slide-to="1" class="active" alt="Los Angeles" style="width:30%; height:100px; margin: 0px 15px; border: 2px solid silver;">
            <img src="<?php echo e(asset('public/front/images/jk.jpg')); ?>" data-target="#myCarousel" data-slide-to="2" class="active" alt="Los Angeles" style="width:30%; height:100px; margin: 0px 15px; border: 2px solid silver;">
    </div>
     <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="<?php echo e(asset('public/front/images/cl.jpg')); ?>" alt="Los Angeles" style="width:100%; height:325px;">
      </div>

      <div class="item">
        <img src="<?php echo e(asset('public/front/images/ki.jpg')); ?>" alt="Chicago" style="width:100%;height:325px;">
      </div>
    
      <div class="item">
        <img src="<?php echo e(asset('public/front/images/jk.jpg')); ?>" alt="New york" style="width:100%; height:325px;">
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" style="background: #ffffff6e;" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" style="background: #ffffff6e;" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
         
    </div>     
 </div>   
       
        <div class="col-sm-7" style="padding: 40px 30px;">
        <h3 style="font-weight:700">YELLOW REGULAR FIT SHIRT</h3>
        <del>Rs. 1,499 </del><span>Rs.749</span>
        <h4>Short Details</h4> 
        <p>Fyster Men's Yellow Color Regular Fit Shirt.</p>
        <p>Cotton Fabric, Full Sleeves Shirt.</p>
        <P>Available Sizes- S, M, L, XL.</P>
        <div style="display:flex;"><h3 style="font-weight:600">Availability : </h3><h3>In Stock</h3></div>
        <div class="row">
            <div class="col-md-6">
                <h4 style="margin:0px 0px -2px">Available Colors:</h4>
                <select class="form-control" style="width: 80%;font-size: 15px;"><option style="font-size:14px"> Select Color</option></select>
                </div>
                <div class="col-md-6">
                <h4 style="margin:0px 0px -2px">Sizes</h4>
                <select class="form-control" style="width: 80%;font-size: 15px;">
                    <option style="font-size:14px"> Size </option>
                    <option> S</option>
                    <option> M</option>
                    <option> L</option>
                    <option> XL</option>
                </select>
                </div>
                </div>
                <br/><br/><br/>
                <div class="row">
                    <div class="col-md-4" style="display: flex; ">
                        <button style="border: none;border-radius:1px;background: black;color: white;font-size: 26px;">-</button>
                        <input type="number" placeholder="1" style="width: 53%;padding: 7px 32px;width:65%;;border-radius:0px;">
                        <button style="border: none;border-radius:0px;background: black;color: white;font-size: 26px;">+</button></div>
                     <div class="col-md-4 " style="">
                        <a  href=""> <button type="button" class="btn btn-primary" style="padding: 7px 32px;width: 71%;border: none;border-radius: 13px;font-size:18px;">Add to card</button> </a></div>
                      <div class="col-md-4" style="">
                          <a href=""> <button type="button" class="btn btn-primary" style="padding: 7px 32px;width: 71%;border: none;border-radius: 13px; font-size:18px;">Try at Home</button></a></div>
                </div>
                
        </div>
</div>
</div>


<div class="container" >
<div >
      <div class=" tab" style="display: flex;margin: 0px -6px: padding: 1px;"><h4 style="margin:5px" class="tablinks" onclick="openCity(event, 'London')" id="defaultOpen">Description</h4>
      <h4 style="margin:5px" class="tablinks" onclick="openCity(event, 'Paris')"> Specification</h4></div>
        <hr style="  margin-top: 0rem !important;  margin-bottom: 20px; text-align: left; border-bottom: 1px solid #e5e5e5; margin-left: 0; padding-left: 0;">
        <div id="London" class="tabcontent">
            
  <h5>pulse container</h5>
   <h5>rice container</h5>
    <h5>cookies container </h5>
     <h5>toffee container </h5>
      <h5>spices container</h5>
  </div>
  <div id="Paris" class="tabcontent">
  <h3>Brand: <a>Others<a/></h3>
  </div>
</div>
</div>

<div class="container" style="background: rgba(0, 0, 0, 0.06);" >
    <div class="">
        <h3 style="margin: 0 0 -3px;">Your Review</h3>
    <h4 style="margin: 0 0 -1px;">Rating</h4>
    <span><i class="fa fa-star" aria-hidden="true"></i></span>
           <span><i class="fa fa-star" aria-hidden="true"></i></span>
           <span><i class="fa fa-star" aria-hidden="true"></i></span>
           <span><i class="fa fa-star" aria-hidden="true"></i></span>
           <span><i class="fa fa-star" aria-hidden="true"></i></span>
    <input type="text" class="form-control" name="" id="" placeholder="Name*"><br/>
     <input  type="email" class="form-control" name="" id="" placeholder="Email*"><br/>
     <textarea class="form-control" name="" id="" ></textarea>
     <div class="text-center"><button type="submit" name="submit" value="Submit" class=" btn btn-success" style="font-size:15px;"> Submit</button></div>
    </div>
    </div>

<div class="container-fluid" style="background: rgba(0, 0, 0, 0.06);padding: 36px; margin: 0px; z-index:99">
    <div class="col-sm-12"> 
    <h3 style="font-weight:600;text-align:center">Related Products</h3>
    <div class="row" style="margin-left: 21px;">
        
        <div class="col-sm-3">
    <div class="card">
  <img src="<?php echo e(asset('public/front/images/cw.jpg')); ?>" alt="Avatar" style="width:100%" class="jk" >
  <div class="container" style="text-align:center">
    <h4>Girls Kid Floor Length Anarkali Dress</h4> 
    <p>Rs.749</p> 
  </div>
</div>
</div>
     <div class="col-sm-3">
    <div class="card">
  <img src="<?php echo e(asset('public/front/images/ki.jpg')); ?>" alt="Avatar" style="width:100%" class="jk">
  <div class="container" style="text-align:center">
    <h4>Girls Kid Floor Length Anarkali Dress</h4> 
    <p>Rs.749</p> 
  </div>
</div>
</div>
     <div class="col-sm-3">
    <div class="card">
  <img src="<?php echo e(asset('public/front/images/ki.jpg')); ?>" alt="Avatar" style="width:100%" class="jk">
  <div class="container" style="text-align:center">
    <h4>Girls Kid Floor Length Anarkali Dress</h4> 
    <p>Rs.749</p> 
  </div>
</div>
</div>
     <div class="col-sm-3">
    <div class="card">
  <img src="<?php echo e(asset('public/front/images/ki.jpg')); ?>" alt="Avatar" style="width:100%" class="jk">
  <div class="container" style="text-align:center">
    <h4>Girls Kid Floor Length Anarkali Dress</h4> 
    <p>Rs.749</p> 
  </div>
</div>
</div>
</div>
    </div>
    
</div>


 <script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
document.getElementById("defaultOpen").click();
</script>   
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/gold/resources/views/front/addcord.blade.php ENDPATH**/ ?>