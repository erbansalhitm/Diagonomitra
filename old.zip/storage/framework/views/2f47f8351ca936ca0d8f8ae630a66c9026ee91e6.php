
<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-3">
  <div class="row">
    <?php echo $__env->make('user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-sm-9">
      <div class="card px-3 py-3">
      <div class="tab-content" id="v-pills-tabContent">
        <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
          <div class="row">
            <div class="col-sm-6"><h5><b>Personal Information</b></h5></div>
                <div class="col-sm-12 col-md-12 col-xl-12 col-lg-12">
                <?php if(session('msg')): ?>
                    <?php echo session('msg'); ?>

                <?php endif; ?>
                </div>
            </div>
            <form name="edit-profile" method="POST" action="<?php echo e(route('user.edit-profile')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-row mt-2">
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                    <label for="inputEmail4">Full Name</label>
                    <input type="text" class="form-control" id="inputEmail4" placeholder="Enter Full Name" name="name" value="<?php echo e($user->name); ?>" >
                </div>
                  
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Email Id</label>
                  <input type="email" class="form-control" id="inputAddress" placeholder="Enter Email Id" name="email" value="<?php echo e($user->email); ?>">
                </div>
                
                <div class="col-sm-12 col-md-12 col-xl-6 col-lg-6">
                <div><label class="mr-3 mb-0 f-18">Gender : </label></div>
                <div class="form-check-inline mt-2">
                  <label class="form-check-label">
                    <input type="radio" class="form-check-input" name="gender" value="Male" <?php if($user->gender == 'Male'): ?><?php echo e('checked'); ?><?php endif; ?> >Male
                  </label>
                </div>
                <div class="form-check-inline">
                  <label class="form-check-label">
                    <input type="radio" class="form-check-input" name="gender" value="Female" <?php if($user->gender == 'Female'): ?><?php echo e('checked'); ?><?php endif; ?> >Female
                  </label>
                </div>
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">City</label>
                  <input type="text" class="form-control" id="inputAddress" placeholder="Enter City" name="city" value="<?php echo e($user->city); ?>">
                </div>

                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">State</label>
                  <input type="text" class="form-control" id="inputAddress" placeholder="Enter State" name="state" value="<?php echo e($user->state); ?>">
                </div>

                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Country</label>
                  <input type="text" class="form-control" id="inputAddress" placeholder="Enter Country" name="country" value="<?php echo e($user->country); ?>">
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Pincode</label>
                  <input type="tex" class="form-control" id="inputAddress" placeholder="Enter Pincode" name="pincode" value="<?php echo e($user->pincode); ?>">
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-12 col-lg-12">
                  <label for="inputAddress">Address</label>
                  <input type="text" class="form-control" id="inputAddress" placeholder="Enter Address" name="address" value="<?php echo e($user->address); ?>">
                </div>
                
                <div class="col-sm-12"><h5><b>Shipping Information</b></h5></div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                    <label for="inputEmail4">Full Name</label>
                    <input type="text" class="form-control" id="inputEmail4" placeholder="Enter Full Name" name="shipping_name" value="<?php echo e($user->shipping_name); ?>" >
                </div>
                  
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Email Id</label>
                  <input type="email" class="form-control" id="inputAddress" placeholder="Enter Email Id" name="shipping_email" value="<?php echo e($user->shipping_email); ?>">
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Mobile</label>
                  <input type="text" class="form-control" id="inputAddress"  placeholder="Enter mobile" name="shipping_mobile" value="<?php echo e($user->shipping_mobile); ?>">
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Country</label>
                  <input type="text" class="form-control" id="inputAddress" placeholder="Enter Country" name="shipping_country" value="<?php echo e($user->shipping_country); ?>">
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">City</label>
                  <input type="text" class="form-control" id="inputAddress" placeholder="Enter City" name="shipping_city" value="<?php echo e($user->shipping_city); ?>">
                </div>

                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">State</label>
                  <input type="text" class="form-control" id="inputAddress" placeholder="Enter State" name="shipping_state" value="<?php echo e($user->shipping_state); ?>">
                </div>

                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Pincode</label>
                  <input type="tex" class="form-control" id="inputAddress" placeholder="Enter Pincode" name="shipping_pincode" value="<?php echo e($user->shipping_pincode); ?>">
                </div>

                <div class="form-group col-sm-12 col-md-12 col-xl-12 col-lg-12">
                  <label for="inputAddress">Address</label>
                  <input type="text" class="form-control" id="inputAddress" placeholder="Enter Address" name="shipping_address" value="<?php echo e($user->shipping_address); ?>">
                </div>
                
                <div class="col-sm-12 col-md-12 col-xl-12 col-lg-12">
                <input type="submit" name="submit" value="Submit"class="btn blue_color_bg" >
                </div>
                </div> 
            </form>
        </div>
        
        </div>
        </div>
      </div>
    </div>
  </div>

  <?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH C:\xampp\htdocs\diagno\resources\views/user/edit-profile.blade.php ENDPATH**/ ?>