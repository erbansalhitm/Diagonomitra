<style>

.lib-panel {
    margin-bottom: 20Px;
}
.lib-panel img {
    width: 100%;
    background-color: transparent;
}

.lib-panel .row,
.lib-panel .col-md-6 {
    padding: 0;
    background-color: #FFFFFF;
}


.lib-panel .lib-row {
    padding: 0 20px 0 20px;
}

.lib-panel .lib-row.lib-header {
    background-color: #FFFFFF;
    font-size: 20px;
    padding: 10px 20px 0 20px;
}

.lib-panel .lib-row.lib-header .lib-header-seperator {
    height: 2px;
    width: 26px;
    background-color: #ffc300;
    margin: 7px 0 7px 0;
}

.lib-panel .lib-row.lib-desc {
    position: relative;
    
    display: block;
    font-size: 13px;
}
.lib-panel .lib-row.lib-desc a{
    position: absolute;
    width: 100%;
    bottom: 10px;
    left: 20px;
}

.row-margin-bottom {
    margin-bottom: 20px;
}

.box-shadow {
    -webkit-box-shadow: 0 0 10px 0 rgba(0,0,0,.10);
    box-shadow: 0 0 10px 0 rgba(0,0,0,.10);
}

.no-padding {
    padding: 0;
}

</style>

<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!--  HOME SLIDER BLOCK  -->

  <div class="slider-wrap" >
    <div id="slider_1" class="owl-carousel" data-nav="true" data-dots="true" data-autoplay="true"
      data-autoplaytimeout="7000" data-bg_effect="true" >
	  
	  <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  
      <div class="slider_item_container" data-bg_img="<?php echo e(asset('public/front/slider/').'/'.$slider->sliderImage); ?>" data-bg_color="#111111"
        data-bg_opacity="0.20">
        <div class="item">
          <div class="slider-content">
            <div class="container text-left">
              <div class="row">
                <div class="slider-bg">
                  <div class="col-sm-12 wow fadeInLeft" data-wow-duration="1s">
                    <h2 class="margin-bottom-12" data-animation-in="slideInDown"
                      data-animation-out="animate-out zoomInDown">
                      <?php echo e($slider->title); ?>

                    </h2>
                    <h3 class="margin-bottom-24" data-animation-in="slideInUp"
                      data-animation-out="animate-out zoomInDown">
                      <?php echo e($slider->content); ?>

                    </h3>
                    <!--<a href="appointment.html" class="btn btn-theme btn-square" data-animation-in="zoomIn"
                      data-animation-out="animate-out fadeOutDown">GET STARTED NOW</a>-->
                  </div>
                </div>
                <!-- end .col-sm-12  -->
              </div>
              <!-- end .row  -->
            </div>
            <!-- end .container -->
          </div>
          <!--  end .slider-content -->
        </div>
        <!-- end .item  -->
      </div>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <!-- end .slider_item_container  -->

    </div>
    <!-- end .slider_1  -->
  </div>
  <!-- end .slider-wrap.  -->

  <!--  ABOUT US -->

  <section class="section-content-block" >
    <div class="container">
      <div class="row">
        
        <div class="col-md-12 col-sm-12 col-xs-12 " >
          <div class=" theme-custom-box-shadow" style="padding:30px;border-top:8px solid #ffc300">
		 <h2>
            FEATURED PRODUCT CATEGORIES</h2>
             <div style="text-align:right">
     <a href="allCategory.php" class="btn btn-theme btn-square wow zoomIn ">View More</a>
 </div>
            </br>
           <div class="row">

        <div class="logo-layout-1 logo-items owl-carousel" >
		
		  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">

            <div class="client-logo"   style="display: inline-block; width: 100%;  background: #fff; padding: 10px 0; 
             border-radius: 5px; box-shadow: 0 3px 6px rgba(0,0,0,.16);">

              <img src="<?php echo e(asset('public/front/product/').'/'.$product->image); ?>" alt="" >
			   <p class="text-center"><?php echo e($product->name); ?></p>

            </div>
           
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </div> <!-- end .logo-items  -->

      </div> 
			

           
          </div>
        </div>
        <!-- end .col-sm-12  -->
      </div>
    </div>
    <!--  end .container  -->
  </section>
  
   <section class="section-content-block">
    <div class="container">
      <div class="row">
       <div class="col-md-6 col-sm-12 col-xs-12 " >
          <div class=" theme-custom-box-shadow" style="padding:30px;border-top:8px solid #ffc300">
            <p class="our-experience">
			<?php echo e($aboutus->title); ?>

              
            </p>

            <?php echo e(strip_tags($aboutus->content)); ?>

			

            <p class="margin-top-24">
              <a href="<?php echo e(route('aboutus')); ?>" class="btn btn-theme btn-square wow zoomIn">Learn More</a>
            </p>
          </div>
        </div>

        <div class="col-md-6 col-sm-12 col-xs-12 " >
          <div class=" theme-custom-box-shadow" style="padding:30px;border-top:8px solid #ffc300">
          <div class=" light-layout  clearfix theme-custom-no-box-shadow">
            <div class="col-md-12 col-sm-12">
              <div class="appointment-form-heading text-left">
			  
                <h2 class="form-title text-capitalize margin-top-24">
                  GET A Query
                </h2>

                <p>
                  Please fill out the query form and very soon we will
                  contact with you to schedule .
                </p>
              </div>
            </div>

            <div class="col-md-12 col-sm-12">
              <form class="appoinment-form ">
                <div class="form-group col-md-4">
                  <input id="your_name" class="form-control" placeholder="Name" type="text" required=""
                    data-msg="This field is required." />
                </div>
                <div class="form-group col-md-4">
                  <input id="your_email" class="form-control" placeholder="Email" type="email" required=""
                    data-msg="This field is required." />
                </div>
                <div class="form-group col-md-4">
                  <input id="your_phone" class="form-control" placeholder="Phone" type="text" required=""
                    data-msg="This field is required." />
                </div>

                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                  <textarea id="textarea_message" class="form-control" rows="3" placeholder="Your Message..."
                    required="" data-msg="This field is required."></textarea>
                </div>

                <div class="form-group col-md-12 col-sm-12 col-xs-12 text-left">
                  <button id="btn_submit" class="btn btn-theme btn-square wow zoomIn" type="submit">
                   Send
                  </button>
                </div>
              </form>
            </div>
          </div>
          </div>
        </div>
        <!-- end .col-sm-12  -->
      </div>
    </div>
    <!--  end .container  -->
  </section>
  <!--  end .section-content-block -->

  <!--  SECTION SERVICE 03 -->
 <section class="section-content-block">

    <div class="container">

      <div class="row section-heading-wrapper">

        <div class="col-md-8 col-md-offset-2 col-sm-12 col-sm-offset-0 text-center">
          <h2>our Clients</h2>
          <span class="heading-separator heading-separator-horizontal"></span>
          
        </div> <!-- end .col-sm-12  -->

      </div>

      <div class="row">

        <div class="logo-layout-1 logo-items owl-carousel " style="text-align: -webkit-center;">
			
		<?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
          <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 " >

            <div class="client-logo ">

              <img src="<?php echo e(asset('public/front/client/').'/'.$client->image); ?>" alt="" style="width: 50%;">

            </div>

          </div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div> <!-- end .logo-items  -->

      </div> <!-- end row  -->

    </div> <!-- end .container  -->

  </section> <!--  end .section-client-logo -->
 
  <!--  end .section-content-block -->
      
      <!--  end .row  -->

      

  <!-- PROCESS SECTION 02-->

  
  <!--  end .section-content-block -->
  <!-- SECTION TESTIMONIAL  04 -->

  <section class="section-content-block section-custom-bg" data-bg_color="#111111" data-bg_opacity="0.75">
    <div class="container">
      <div class="row section-heading-wrapper section-heading-wrapper-alt">
        <div class="col-md-12 col-sm-12 text-center">
          <h4 class="heading-alt-style text-capitalize">Testimonial</h4>
           <span class="heading-separator heading-separator-horizontal"></span>
         <!--  <h2 class="subheading-alt-style">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit curabitur
            eu ante non ex lobortis posuere
          </h2>  -->
        </div>
        <!-- end .col-sm-12  -->
      </div>
    </div>

    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
          <div class="testimonial-container owl-carousel text-center" data-items="1">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="testimony-layout-1 transparent-bg">
                <p class="testimony-text text-light-color">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit curabitur
            eu ante non ex lobortis posuere
                </p>

                <div class="testimony-info">
                  <img class="img-responsive" src="<?php echo e(asset('public/front/')); ?>/images/user_2.jpg" alt="Client Image" />
                  <h4>Ajay Kumar</h4>
                  <h6>CTO,  Design</h6>
                </div>
              </div>
              <!-- end .testimony-layout-1  -->
            </div>

            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="testimony-layout-1 transparent-bg">
                <p class="testimony-text text-light-color">
                 Lorem ipsum dolor sit amet, consectetur adipiscing elit curabitur
            eu ante non ex lobortis posuere
                </p>
                <img class="img-responsive" src="<?php echo e(asset('public/front/')); ?>/images/user_3.jpg" alt="Client Image" />
                <div class="testimony-info">
                  <h4>Ayush Malhotra</h4>
                  <h6 class="bq-author-info">CEO, Developer</h6>
                </div>
              </div>
              <!-- end .testimony-layout-1  -->
            </div>

            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="testimony-layout-1 transparent-bg">
                <p class="testimony-text text-light-color">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit curabitur
            eu ante non ex lobortis posuere
                </p>
                <img class="img-responsive" src="<?php echo e(asset('public/front/')); ?>/images/user_1.jpg" alt="Client Image" />
                <div class="testimony-info">
                  <h4>Nitesh Sharma</h4>
                  <h6 class="bq-author-info">CEO, Tester</h6>
                </div>
              </div>
              <!-- end .testimony-layout-1  -->
            </div>
          </div>
          <!-- end .testimonial-container  -->
        </div>
      </div>
    </div>
    <!-- end .container  -->
  </section>

  <!-- TEAM SECTION 01 -->

  <section class="section-content-block">
    <div class="container">
      <div class="row section-heading-wrapper">
        <div class="col-md-12 col-sm-12 text-center">
          <h4 class="heading-alt-style text-capitalize ">
           Blogs
          </h4>
          <span class="heading-separator heading-separator-horizontal"></span>
          <!--<h2 class="subheading-alt-style">
            Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante non
            lobortis posuere
          </h2>-->
        </div>
        <!-- end .col-sm-12  -->
      </div>

      <div class="row wow fadeInLeft">
        <div class="col-md-3 col-sm-6 col-xs-10 col-xs-offset-1 col-sm-offset-0 col-md-offset-0">
          <div class="team-layout-1 text-center">
            <figure class="team-member">
              <a href="#" title="MELISSA MUNOZ">
                <img src="<?php echo e(asset('public/front/')); ?>/images/blog_1.jpg" alt="MELISSA MUNOZ" />
              </a>
            </figure>
            <!-- end. team-member  -->

            <article class="team-info">
              <h3><a href="#">Manoj Kumar</a></h3>
			   <h4>Technical Manager</h4>
              <p class="subheading-alt-style">
            Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante non
            lobortis posuere
          </p>

              <!--<div class="top-bar-social "> 
                <a href="#"  >
                  <i class="fa fa-facebook" style="color:#000"></i>
                </a>
                <a href="#">
                  <i class="fa fa-twitter" style="color:#000"></i>
                </a>
                <a href="#">
                  <i class="fa fa-google-plus" style="color:#000"></i>
                </a>
                <a href="#">
                  <i class="fa fa-instagram" style="color:#000"></i>
                </a>
                <a href="#">
                  <i class="fa fa-youtube" style="color:#000"></i>
                </a>
              
            </div>
              end .author-social-box  -->
            </article>
          </div>
          <!--  end team layout-1 -->
        </div>
        <!--  end .col-lg-3 col-md-3 col-sm-6 col-xs-12 -->

        <div class="col-md-3 col-sm-6 col-xs-10 col-xs-offset-1 col-sm-offset-0 col-md-offset-0">
          <div class="team-layout-1 text-center">
            <figure class="team-member">
              <a href="#" title="ALEXANDER GARY">
                <img src="<?php echo e(asset('public/front/')); ?>/images/blog_2.png" alt="ALEXANDER GARY" />
              </a>
            </figure>
            <!-- end. team-member  -->

            <article class="team-info">
              <h3><a href="#">Ankit Kumar</a></h3>
              <h4>Chief Engineer</h4>
			   <p class="subheading-alt-style">
            Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante non
            lobortis posuere
          </p>

               <!-- <div class="top-bar-social "> 
                <a href="#"  >
                  <i class="fa fa-facebook" style="color:#000"></i>
                </a>
                <a href="#">
                  <i class="fa fa-twitter" style="color:#000"></i>
                </a>
                <a href="#">
                  <i class="fa fa-google-plus" style="color:#000"></i>
                </a>
                <a href="#">
                  <i class="fa fa-instagram" style="color:#000"></i>
                </a>
                <a href="#">
                  <i class="fa fa-youtube" style="color:#000"></i>
                </a>
              
            </div>
               <!--end .author-social-box  -->
            </article>
          </div>
          <!--  end team-layout-1 -->
        </div>
        <!--  end .col-lg-3 col-md-3 col-sm-6 col-xs-12  -->

        <div class="col-md-3 col-sm-6 col-xs-10 col-xs-offset-1 col-sm-offset-0 col-md-offset-0">
          <div class="team-layout-1 text-center">
            <figure class="team-member">
              <a href="#" title="JOHN ABRAHAM">
                <img src="<?php echo e(asset('public/front/')); ?>/images/blog_3.jpg" alt="JOHN ABRAHAM" />
              </a>
            </figure>
            <!-- end. team-member  -->

            <article class="team-info">
              <h3><a href="#">Arpita jeswal</a></h3>
              <h4>Office Manager</h4>
			   <p class="subheading-alt-style">
            Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante non
            lobortis posuere
          </p>
               <!-- <div class="top-bar-social "> 
                <a href="#"  >
                  <i class="fa fa-facebook" style="color:#000"></i>
                </a>
                <a href="#">
                  <i class="fa fa-twitter" style="color:#000"></i>
                </a>
                <a href="#">
                  <i class="fa fa-google-plus" style="color:#000"></i>
                </a>
                <a href="#">
                  <i class="fa fa-instagram" style="color:#000"></i>
                </a>
                <a href="#">
                  <i class="fa fa-youtube" style="color:#000"></i>
                </a>
              
            </div>
              <!-- end .author-social-box  -->
            </article>
          </div>
          <!--  end team-layout-1 -->
        </div>
        <!--  end .col-lg-3 col-md-3 col-sm-6 col-xs-12  -->

        <div class="col-md-3 col-sm-6 col-xs-10 col-xs-offset-1 col-sm-offset-0 col-md-offset-0">
          <div class="team-layout-1 text-center">
            <figure class="team-member">
              <a href="#" title="Anjali Gupta">
                <img src="<?php echo e(asset('public/front/')); ?>/images/blog_4.jpg" alt="Anjali Gupta" >
              </a>
            </figure>

            <article class="team-info">
              <h3><a href="#">Anjali Gupta</a></h3>
              <h4>Technical Manager</h4>
			  
			   <p class="subheading-alt-style">
            Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante non
            lobortis posuere
          </p>
              
            
			   <!--<div class="top-bar-social "> 
                <a href="#"  >
                  <i class="fa fa-facebook" style="color:#000"></i>
                </a>
                <a href="#">
                  <i class="fa fa-twitter" style="color:#000"></i>
                </a>
                <a href="#">
                  <i class="fa fa-google-plus" style="color:#000"></i>
                </a>
                <a href="#">
                  <i class="fa fa-instagram" style="color:#000"></i>
                </a>
                <a href="#">
                  <i class="fa fa-youtube" style="color:#000"></i>
                </a>
              
            </div>-->
              <!-- end .author-social-box  -->
            </article>
			
          </div>
          <!--  end team-layout-1 -->
        </div>
        <!--  end .col-lg-3 col-md-3 col-sm-6 col-xs-12  -->
      </div>
      <!-- end .row  -->
    </div>
    <!-- end .container  -->
  </section>
  <!--  end .section-our-team -->




 
  <!--  SECTION APPOINTMENT   06-->

 <!--  <section class="section-content-block section-secondary-bg">
     <div class="container">
     <div class="row wow fadeInUp">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="appointment-form-wrapper light-layout margin-bottom-24 clearfix theme-custom-no-box-shadow">
            <div class="col-md-4 col-sm-12">
              <div class="appointment-form-heading text-left">
			  
                <h2 class="form-title text-capitalize margin-top-24">
                  GET A Query
                </h2>

                <p>
                  Please fill out the query form and very soon we will
                  contact with you to schedule .
                </p>
              </div>
            </div>

            <div class="col-md-8 col-sm-12">
              <form class="appoinment-form margin-top-42">
                <div class="form-group col-md-4">
                  <input id="your_name" class="form-control" placeholder="Name" type="text" required=""
                    data-msg="This field is required." />
                </div>
                <div class="form-group col-md-4">
                  <input id="your_email" class="form-control" placeholder="Email" type="email" required=""
                    data-msg="This field is required." />
                </div>
                <div class="form-group col-md-4">
                  <input id="your_phone" class="form-control" placeholder="Phone" type="text" required=""
                    data-msg="This field is required." />
                </div>

                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                  <textarea id="textarea_message" class="form-control" rows="3" placeholder="Your Message..."
                    required="" data-msg="This field is required."></textarea>
                </div>

                <div class="form-group col-md-12 col-sm-12 col-xs-12 text-left">
                  <button id="btn_submit" class="btn btn-theme btn-square wow zoomIn" type="submit">
                   Send
                  </button>
                </div>
              </form>
            </div>
          </div>
          <!-- end .appointment-form-wrapper  -->
        <!--</div>  -->
        <!--  end .col-lg-6 -->
      </div>
       <!--end .row  -->
    </div> 
    <!--  end .container -->
  </section>
  <!--  end .appointment-section  -->
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\dm\resources\views/front/index.blade.php ENDPATH**/ ?>