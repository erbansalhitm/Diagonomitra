   
<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <style> 
             #panel, #flip {
                  padding: 0px;
                  text-align: center;
                  }
                #panel {
                  padding: 0px;
                  display: none;
                }
               #content {
    position: relative;
    overflow: hidden;
    background-color: #fbfafa05;
}
#footer{
    border-top:none;
}
.oc-item{

   border:1px solid gray;
    background: none;
    text-align: center;
    padding:10px;
}
.p1{
    height: 26px;
     padding: 0px 0px 10px 0px;
     background:none !important;
    
}
 </style>
<!-- Slider 1 -->
<div class="slider" id="slider1">
    <!-- Slides -->
    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div style="background-image:url(<?php echo e(asset('public/front/slider').'/'.$slider->sliderImage); ?>)"></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- The Arrows -->
    <i class="left" class="arrows" style="z-index:2; position:absolute;"><svg viewBox="0 0 100 100"><path d="M 10,50 L 60,100 L 70,90 L 30,50  L 70,10 L 60,0 Z"></path></svg></i>
    <i class="right" class="arrows" style="z-index:2; position:absolute;"><svg viewBox="0 0 100 100"><path d="M 10,50 L 60,100 L 70,90 L 30,50  L 70,10 L 60,0 Z" transform="translate(100, 100) rotate(180) "></path></svg></i>
    <!-- Title Bar -->
    </div>
<section id="content">
		<div class="container-fluid mr">
			<div class="row" style="margin-top:30px;">
				<div class="col-md-4">
					<a href="#"><img src="<?php echo e(asset('public/front/images/gold4.png')); ?>" class="imgbd" alt=""></a>
				</div>
				<div class="col-md-4">
					<img src="<?php echo e(asset('public/front/images/gold5.png')); ?>" class="imgbd" alt="">
				</div>
				<div class="col-md-4">
					<img src="<?php echo e(asset('public/front/images/gold6.png')); ?>" class="imgbd" alt="">
				</div>
			</div>
		
                
                <div id="panel">
                    <div class="row" style="margin-top:30px;">
                		<div class="col-md-4">
                			<a href="#"><img src="<?php echo e(asset('public/front/images/gold9.png')); ?>" class="imgbd" alt=""></a>
                		</div>
                		<div class="col-md-4">
                			<img src="<?php echo e(asset('public/front/images/gold7.png')); ?>" class="imgbd" alt="">
                		</div>
                		<div class="col-md-4">
                			<img src="<?php echo e(asset('public/front/images/gold8.png')); ?>" class="imgbd" alt="">
                		</div>
                	</div>
                </div>
			<div id="flip">
                    <button class="css-5erg081 elpz4pe6">See All</button>
                </div>
		</div>
	</section>
	
	
	<div id="oc-clients-full" class="owl-carousel owl-carousel-full image-carousel bottommargin-sm carousel-widget" data-margin="30" data-loop="false" data-nav="false" data-autoplay="5000" data-pagi="false" data-items-xs="2" data-items-sm="3" data-items-md="4" data-items-lg="5" data-items-xl="6">
										
					<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
					<div class="oc-item">
						<a href="<?php echo e(url('product-detail').'/'.$product->slug); ?>">
						<img src="<?php echo e(asset('public/front/product').'/'.$product->image); ?>" alt="Clients">
						<p class="p1">₹<?php echo e($product->price); ?>,<span><del><?php echo e($product->oldprice); ?></del></span><br><?php echo e($product->name); ?> </p>
						<button class=" btn btn-primary" type="button">Try at Home </button>
					    </a>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	

					</div>
					

		
	<section id="content" style="background: url(<?php echo e(asset('public/front/images/gol4.png')); ?>) center center / cover no-repeat; height: 362px;"></section>

	<section id="content">
		<div class="content-wrap">
			
				<div class="container">
					<div class="row" style="margin-top:30px;">
						<div class="col-md-6">
							<img src="<?php echo e(asset('public/front/images/gold3.png')); ?>" alt="">
						</div>
						<div class="col-md-6" style="padding:35px;">
							<h2>Gifts That Show Them You Care</h2>
							<div class="underline__container css-1mxcjm6 evgra8b2"><span class="css-ak8f16 evgra8b3"></span><span class="css-i6ykbt evgra8b3"></span></div>
							<ul class="css-kn28h9 elpz4pe5"><li>-  Pick something from our thoughtful gift curation, or surprise them with a Try@Home appointment<br></li><li>-  Fast delivery that’s right on time for your special occasion<br></li><li>-  Guaranteed 15 Day Money Back</li></ul>
							<button class="css-5erg08 elpz4pe6">Gift Something Special</button>
						</div>
						
					</div>
				</div>
				</div>
			</section>
			
			
			
			
				
			<div class="clear"></div>
			<div class="section footer-stick notopmargin" style="background-color:#fb8b2a9c;">
			
				<div class="fslider testimonial testimonial-full" data-animation="fade" data-arrows="false">
					<div class="flexslider">
						<div class="slider-wrap">
							<?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="slide">
								<div class="testi-image">
								<a href="#"><img src="<?php echo e(asset('public/front//testimonial').'/'.$testimonial->image); ?>" alt="Customer Testimonails"></a>
								</div>
								<div class="testi-content">
									<p style="color: white;font-family:'MuliRegular','Helvetica Neue',Helvetica,Arial,sans-serif;"><?php echo strip_tags($testimonial->content); ?></p>
										<div class="testi-meta" style="color: white;">
											<?php echo e($testimonial->name); ?>

											<span style="color: white;"><?php echo e($testimonial->designation); ?>.</span>
										</div>
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						</div>
					</div>
				</div>
		</div>	
		</div>
		
		
		
		</div>
		
	</section>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
			<script> 
                $(document).ready(function(){
                  $("#flip").click(function(){
                    $("#panel").toggle("slow");
                  });
                  
                
                });
            </script>

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /opt/lampp/htdocs/gold/resources/views/front/index.blade.php ENDPATH**/ ?>