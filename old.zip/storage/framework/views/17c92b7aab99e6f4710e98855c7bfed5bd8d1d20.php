<style>
    footer{
        background: #2562b6;
        /*background: #ba378f;*/
    }
    .footer_link ul li a{
        color:#fff;
    }
   .footer_link h4 {
         color:#fff;
    }
    .copy_right small{
         color:#fff;
    }
    .footer_sm_links ul li a{
            background: #fff;
    padding: 7px 9px;
    border-radius: 3px;
    }
    footer hr{
            background: #fff;
    }
    .footer_link {
    width: unset;
   
    }
    @media (max-width: 767.98px){
        footer ul {
            padding: 10px 0;
        }
        .footer_link ul li a {
            color: #fff;
            font-size: 10px !important;
        }
        .footer_sm_links ul li {
            padding: 10px 3px  !important;
        }
        .footer_link h4{
                padding: 0px 0  !important;
                margin-bottom: 0;
        }
        footer ul {
    padding: 0 0;
    margin-bottom: 0;
}
.footer_link ul li {
    line-height: 2;
}
footer ul li {
    padding: 0px 0  !important;
}        
        
        
    }
</style>  
  
  <footer class="mt-4  d-sm-none d-md-block">
    <div class="container">
      <div class="row footer_link">
        
        <div class="col-lg-3 col-md-3 col-6">
          <h4>SPECIALISATIONS</h4>
          <ul>
            <li><a href="#">Orthopedician</a></li>
            <li><a href="#">Dermatologist</a></li>
            <li><a href="#">Pediatrician</a></li>
            <li><a href="#">General Physician</a></li>
            <li><a href="#">General Surgeon</a></li>
            <li><a href="#">Cardiologist</a></li>
            <li><a href="">Dietitian</a></li>
            <li><a href="">Pulmonologist</a></li>
            <li><a href="">Gynecologist</a></li>
            <li><a href="">View All ></a></li>
          </ul>
        </div>
        <div class="col-lg-3 col-md-3 col-6col-lg-3 col-md-3 col-6">
          <h4>ABOUT</h4>
          <ul>
            <li><a href="<?php echo e(route('about-us')); ?>"> About Us</a></li>
            <li><a href="#"> Press & News</a></li>
            <li><a href="<?php echo e(route('privacy')); ?>"> Privacy Policy</a></li>
            <li><a href="<?php echo e(route('term-conditions')); ?>"> Term & Conditions</a></li>            
             <li><a href="<?php echo e(route('blog')); ?>"> Blog</a></li>
            <li><a href="#"> Forum</a></li>
            <li><a href="#"> Community Standards</a></li>
            <li><a href="#"> Invite a Friend</a></li>
            <li><a href="<?php echo e(route('seller-registration')); ?>"> Become a Seller</a></li>
          </ul>
        </div>
        <div class="col-lg-3 col-md-3 col-6">
          <h4>SUPPORT</h4>
          <ul>
            <li><a href="<?php echo e(route('faq')); ?>"> FAQ</a></li>
            <li><a href="#"> Support</a></li>
            <li><a href="#"> Help & Support</a></li>
            <li><a href="#"> Trust & Safety</a></li>
          </ul>
        </div>
        <div class="col-lg-3 col-md-3 col-6">
                    
          <h4>Contact Us</h4>
          <ul>
           
            <li><a href="#"> <strong>Branch Office: 15 Satbari Chattarpur, New Delhi- 110074 </strong></a></li>
            <li><a href="mailto: support@diagnomitra.com"><strong> Email Address: support@diagnomitra.com </strong></a></li>
            <li><a href="https://diagnomitra.com/"><strong> Website: www.diagnomitra.com </strong></a></li>
            <li><a href="tel:7532075184"> <strong>Contact Number: +91 75320 75184 </strong></a></li>
            
          </ul>
        </div>
       
      </div>

      <hr class="mt-4">
      <div class="row">
        <div class="footer_logo col-12 col-sm-6">
          <div class="col col-sm-4 nopadding">
            <img src="<?php echo e(asset('public/front/')); ?>/images/logo_grey.png">                        
          </div>
          <div class="copy_right col col-sm-8  mt-3">
            <small>© Diagonomitra Ltd. 2020</small>
          </div>
        </div>
        <div class="col-12 col-sm-6">
          <div class="footer_sm_links float-right">
            <ul>
              <li><a href="#"><img src="<?php echo e(asset('public/front/')); ?>/images/tiktok.png"></a></li>
              <li><a href="#"><img src="<?php echo e(asset('public/front/')); ?>/images/youtube.png"></a></li>
              <li><a href="#"><img src="<?php echo e(asset('public/front/')); ?>/images/twitter.png"></a></li>
              <li><a href="#"><img src="<?php echo e(asset('public/front/')); ?>/images/fb.png"></a></li>
              <li><a href="#"><img src="<?php echo e(asset('public/front/')); ?>/images/insta.png"></a></li>
              <li><a href="#"><img src="<?php echo e(asset('public/front/')); ?>/images/linkedin.png"></a></li>
            </ul>
          
          </div>
        </div>

      </div>
    </div>
  </footer>

  
</body>
</html>
<script type="text/javascript">
  $('#product-item').carousel({
  interval: 3000,
  cycle: true
}); 
  $('#doctors').carousel({
  interval: 4000,
  cycle: true
}); 
  $('#Lab_test').carousel({
  interval: 5000,
  cycle: true
});
  $('#E-Pharmacy').carousel({
  interval: 3500,
  cycle: true
});
  $('#health_store').carousel({
  interval: 3600,
  cycle: true
});
  $('#customers').carousel({
  interval: 2500,
  cycle: true
});
  
                
</script><?php /**PATH /home/u769120014/domains/diagnomitra.com/public_html/resources/views/front/footer.blade.php ENDPATH**/ ?>