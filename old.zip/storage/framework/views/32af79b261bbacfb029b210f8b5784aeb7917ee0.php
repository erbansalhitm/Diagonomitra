<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .rem input{
        width:3%;
    }
    .signup-form form{
        box-shadow: 0 2px 20px 0 rgba(0,0,0,.1);
        padding: 30px 25px;
    background: #fff;
    }
</style>
    <!-- Breadcrumb Section Begin -->
    
    
    <!-- Breadcrumb Section End -->
    
    <div class="py-4">
        <div class="container">
           
            <div class="signup-form">
                <h3 class="text-center">Login Form</h3>
                <form action="">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <label for="uname"><b>Username</b></label>
                            <input type="text" placeholder="Enter Username" name="uname" required>
                        </div>
                        <div class="col-lg-12 col-md-12">
                            <label for="psw"><b>Password</b></label>
                              <input type="password" placeholder="Enter Password" name="psw" required>
                        </div>
                        
                        <div class="col-lg-12 col-md-12 rem">
                              <label>
                                <input type="checkbox" checked="checked" name="remember"> Remember me
                              </label>
                        </div>
                    </div>
                    
                        <div class="subButton ">
                            <a href="#">Submit</a>
                            
                        </div>
                        <div class="py-3">
                            <p class=" text-center">Forgot <a href="#">password?</a></p>
                            
                            <p class="message text-center">Not registered? <a href="#">Create an account</a></p>
                        </div>
                        
                      
                </form>
            </div>        
            
        </div>
    </div>

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\socid\resources\views/front/login.blade.php ENDPATH**/ ?>