<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="author" content="Rahul Gauniyal">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Redwingsolutions | It solutions for all your needs. </title>

    <!-- Favicons -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('public/front/')); ?>/img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('public/front/')); ?>/img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('public/front/')); ?>/img/favicon/favicon-16x16.png">
    <link rel="manifest" href="<?php echo e(asset('public/front/')); ?>/img/favicon/site.webmanifest">
    <link rel="mask-icon" href="<?php echo e(asset('public/front/')); ?>/img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=PT+Sans:ital,wght@0,400;0,700;1,400;1,700&display=swap"
        rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/slick.css">
    <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/normalize.css">
    <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/aos.css">
    <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/flexboxgrid.css">

    <!-- Main CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/style.css">

</head>

<!-- Body Tag Starts -->

<body id="prdctpg-tag" class="custom-prdctpg-tag">

    <!-- Header Starts -->
    <header id="header-tag" class="custom-header-tag">
        <div class="custom-header">
            <div class="custom-top-header">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                            <div class="custom-header-info">
                                <ul>
                                    <li><i class="fas fa-phone-volume"></i>
                                        <a href="tel:+91-9866028012">+91-9866028012</a></li>
                                    <li><i class="fas fa-envelope-open-text"></i>
                                        <a href="ktrao@redsol.in">ktrao@redsol.in</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                            <div class="custom-header-sociallinks">
                                <ul>
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                    <li> <a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-bottom-header">
                <div class="container">
                    <div class="row">
                        <!-- Header Logo -->
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <div class="custom-header-logo">
                                <a href="<?php echo e(route('/')); ?>"><img src="<?php echo e(asset('public/front/')); ?>/img/logo.png "
                                        alt="Redwingsolutions Logo"></a>
                            </div>
                        </div>
                        <div class="mobileicon"><i class="fas fa-bars"></i></div>
                        <!-- Header Menu -->
                        <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                            <nav class="custom-header-menu">
                                <ul>
									<li><a href="<?php echo e(route('/')); ?>">Home</a></li>
									<li><a href="<?php echo e(route('service')); ?>">Services</a></li>
									<li><a href="<?php echo e(route('about')); ?>">About</a></li>
									<li><a href="<?php echo e(route('products')); ?>">Products</a></li>
									<li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Ends -->

    <!-- Banner Starts -->
    <section id="banner-tag prdctpg-bnnrtag" class="custom-banner-tag page-section">
        <div class="custom-banner prdctpg-bnnr">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 center-align">
                        <div class="custom-banner-content prdctpg-bnnrcntn" data-aos="fade-up">
                            <h1>Our Products</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Banner End -->


    <!-- Main Section Content -->
    <main id="cntnsctns" class="csmt-cntnsctns">
<section id="service-section" class="cstm-service sctnblck page-section" style="padding: 4rem 0;">
			<div class="custom-srvccntn">
				<div class="container">
					<div class="sctntle srvctitle">
						<p>We at Cache Peripherals offer customers a wide diversity of HP products with automated savings and a flexible architecture designed for growth.
						With our Pre-integrated, 
						validated products will ensure a simpler and cost-effective way to run your IT</p>
						<h2>Our Product</h2>
					</div>
					<div class="row">
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
							<div class="srvccntnblck" data-aos="fade-up" style="padding-bottom:0px !important">
								<span class="srvcbox">
									<div class=""><img src="<?php echo e(asset('public/front/product/').'/'.$product->image); ?>" alt=""></div>
									<a href="" class="button" style="width:100%;padding: 0.9em;" data-toggle="modal" data-target="#myModal"><?php echo e($product->name); ?></a>
								</span>
								
							</div>
							<div class="modal" id="myModal">
		<div class="modal-dialog" style="max-width: 700px;">
		<div class="modal-content">

		<!-- Modal Header -->
		<div class="modal-header " >
		<h4 class="modal-title text-center"  style="text-align:center !important">Our product</h4>

		</div>

		<!-- Modal body -->
		<div class="modal-body">
		<form action="#" method="Post" id="pgeform" class="cstm-form">
		<div class="row" >
		<div class="col-md-5">

		<img src="<?php echo e(asset('public/front/product/').'/'.$product->image); ?>">

		</div>
		<div class="col-md-7">
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div class="form-group in_name">
		<input type="text" name="name" id="name" class="form-fname-input" placeholder="Enter Your Name" required="" style="padding: 10px;">
		</div>
		</div>
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div class="form-group in_email">
		<input type="email" name="email" id="email" class="form-email-input" placeholder="Enter Your Email" title="Correct e-mail format e.g. abc@gmail.com" style="padding: 10px;">
		</div>
		</div>
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div class="form-group in_email">
		<input type="tel" minlength="10" maxlength="10" id="phone" name="phone" class="form-phone-input" placeholder="Enter Your Number" title="Put 10 digit mobile number" required="" style="padding: 10px;">
		</div>
		</div>
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div class="form-group in_email">
		<select name="cars" id="cars" form="carform" style="padding: 10px;">
		<option value="volvo">HP Desktop</option>
		<option value="saab">HP Moniter</option>
		<option value="opel">HP Notebook</option>
		<option value="audi">HP Tablet</option>
		<option value="opel">HP Accessories</option>
		<option value="audi">HP Remote Access</option>
		</select>
		</div>
		</div>

		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div class="form-group in_message">
		<textarea name="message" id="message" class="form-message-input"
		cols="10" rows="2" pattern="[A-Za-z]" placeholder="Your Message"
		required style="padding: 10px;"></textarea>
		</div>
		</div>
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

		<div class="center-align">
		<input type="submit" value="submit" id="submit" class="btn" title="Submit Your Message!">
		</div>
		</div>
		</div>
		</div>
		</form>
		</div>

		<!-- Modal footer -->
		<div class="modal-footer">
		<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		</div>

		</div>
		</div>
		</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>

		</section>
        <!-- About Section Starts -->
        <!-- About Section Ends -->

		
    </main>

    <!-- Footer Starts -->
    <footer id="ftrbtmtag" class="custom-ftrbtmtag">
        <div class="custom-footerbtm">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                        <div class="cstmcpyrght">
                            <p>&copy;<script>
                                    document.write(new Date().getFullYear());
                                </script> All rights reserved Made by <a href="https://digioodles.com"
                                    target="_blank">Digioodles.</a></p>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                        <div class="ftr-sociallinks">
                            <ul>
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                <li> <a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer><!-- Footer Ends -->

    <!-- Backto-top -->
    <a href="javascript:void();" id="back-to-top"><i class="fas fa-level-up-alt"></i></a>


    <!-- Vendor JS Files -->
    <script src="<?php echo e(asset('public/front/')); ?>/js/jquery-3.5.1.min.js"></script>
    <script src="<?php echo e(asset('public/front/')); ?>/js/easing.js"></script>
    <script src="<?php echo e(asset('public/front/')); ?>/js/jquery-migrate-3.3.0.min.js"></script>
    <script src="<?php echo e(asset('public/front/')); ?>/js/slick.min.js"></script>
    <script src="<?php echo e(asset('public/front/')); ?>/js/aos.js"></script>
    <script src="<?php echo e(asset('public/front/')); ?>/js/owl.carousel.min.js"></script>

    <!-- Template Main JS File -->
    <script src="<?php echo e(asset('public/front/')); ?>/js/custom.js"></script>

</body>

</html><?php /**PATH C:\xampp\htdocs\hp\resources\views/front/product.blade.php ENDPATH**/ ?>