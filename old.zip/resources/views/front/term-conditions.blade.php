@include('front.header')

<style>
   
    
</style>


 <div class="bg-light py-3 mb-4">
      <div class="container">
        <div class="row">
          <div class="col-md-12 mb-0"><a href="index.html">Home</a> <span class="mx-2 mb-0">/</span> <a href="privacy.php">Terms & Conditions</a></div>
        </div>
      </div>
    </div>

<!--About content-->
  <div class="container my-4">
      <div class="row">
          <div class="col-lg-12 col-md-12 pt-2">
              <div>
                  <h2>Terms & Conditions</h2>
                  
              </div>
          </div>
          
      </div>
  </div>




@include('front.footer')