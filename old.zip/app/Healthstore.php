<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Healthstore extends Model
{
    //
    
    
}
