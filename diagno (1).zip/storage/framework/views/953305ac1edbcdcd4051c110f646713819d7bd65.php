
<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-3">
  <div class="row">
    <?php echo $__env->make('store.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-sm-9">
      <div class="card px-3 py-3">
      <div class="tab-content" id="v-pills-tabContent">
        <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
          <div class="row">
            <div class="col-sm-6"><h5><b>Enquiry Details</b></h5></div>     
            </div>
            <form>

                <div class="form-row mt-2">                  
                
                <table class="table">
            <tr>

                <th>Customer Name</th>
                <th>Customer Email</th>
                <th>Customer Contact</th>
            </tr>
            <tr>
                <td><?php echo e($enquiry->name); ?></td>
                <td><?php echo e($enquiry->email); ?></td>
                <td><?php echo e($enquiry->contact); ?></td>
                
            </tr>
			
			<tr>

                <th>Alternate Contact</th>
                <th>Customer Address</th>
                <th>Date</th>
            </tr>
            <tr>
                <td><?php echo e($enquiry->alternate_contact); ?></td>
                <td><?php echo e($enquiry->address); ?></td>
                <td><?php echo e($enquiry->created_at); ?></td>
                
            </tr>
			
			
            
        </table>
            <br/>
			<?php if($enquiry->prescription): ?>
				<b>Prescription</b>
				<a href="<?php echo e(asset('public/front/prescription').'/'.$enquiry->prescription); ?>" target="_blank" class="alert text-danger">View Now</a>
		   <?php endif; ?>
                
                </div> 
            </form>
        </div>
        
        </div>
        </div>
      </div>
    </div>
  </div>

  <?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH /home/u769120014/domains/diagnomitra.com/public_html/resources/views/store/enquiry-details.blade.php ENDPATH**/ ?>