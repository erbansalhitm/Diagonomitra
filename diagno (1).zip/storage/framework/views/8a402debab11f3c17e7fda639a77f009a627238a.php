<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/contact-banner.jpg);">
        <div class="auto-container">
            <h1>Contact Us</h1>
            <div class="bread-crumb-outer">
                <ul class="bread-crumb clearfix">
                    <li><a href="index.php">Home</a></li>
                    <li class="active">Contact Us</li>
                </ul>
            </div>
        </div>
    </section>
    
    
    <!--Contact Section-->
    <section class="contact-section">
    	<div class="auto-container">
        	<div class="row clearfix">
                
                <!--Form Column -->
            	<div class="column form-column pull-right col-lg-6 col-md-6 col-sm-12 col-xs-12">
                	<div class="default-title"><h3>SEND US A MESSAGE</h3><div class="separator"></div></div>
                	<!--form-box-->
                    <div class="form-box default-form">
                        <div class="contact-form default-form">
                            <form method="post" action="http://world5.commonsupport.com/html2/preview-human-welfare/sendemail.php" id="contact-form">
                                <div class="row clearfix">
                                
                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                    	<div class="field-label">Name <span class="req">*</span></div>
                                        <input type="text" name="username" value="" required>
                                    </div>
        
                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                    	<div class="field-label">Email <span class="req">*</span></div>
                                        <input type="email" name="email" value="" required>
                                    </div>
                                     <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                    	<div class="field-label">Phone <span class="req">*</span></div>
                                        <input type="text" name="username" value="" required>
                                    </div>
        
                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                    	<div class="field-label">Subject <span class="req">*</span></div>
                                        <input type="email" name="email" value="" required>
                                    </div>
                                    
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                    	<div class="field-label">Message <span class="req">*</span></div>
                                        <textarea name="message"></textarea>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <button type="submit" class="theme-btn btn-style-three">SUBMIT </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!--Column-->
                <div class="column info-column pull-left col-lg-6 col-md-6 col-sm-12 col-xs-12">
                	<div class="default-title"><h3>GET IN TOUCH</h3><div class="separator"></div></div>
                    <div class="info">
                        <div class="row clearfix">
                        	<!--Info Column-->
                            <div class="info-column col-md-6 col-sm-6 col-xs-12">
                            	<div class="info-box">
                                    <div class="inner">
                                        <div class="icon"><span class="flaticon-placeholder"></span></div>
                                        <h4>ADDRESS</h4>
                                        <div class="text">Sec-31 Faridabad, Haryana 121008</div>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Info Column-->
                            <div class="info-column col-md-6 col-sm-6 col-xs-12">
                            	<div class="info-box">
                                    <div class="inner">
                                        <div class="icon"><span class="flaticon-envelope"></span></div>
                                        <h4>EMAIL</h4>
                                        <div class="text">info@punjabiwelfare.in</div>
                                    </div>
                                </div>
                                
                                <div class="info-box">
                                    <div class="inner">
                                        <div class="icon"><span class="flaticon-technology"></span></div>
                                        <h4>PHONE NO</h4>
                                        <div class="text">+91-701-184-1369<br>+91-981-119-9998</div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    
                </div>
                
            </div>    
       	</div>
   	</section>
    
    
    <!--Map Section-->
    <!--<section class="map-section">
    	<div class="map-outer">

            <!--Map Canvas--
            <div class="map-canvas"
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d28018.564939691983!2d77.34283503833664!3d28.620151425034333!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce5456ef36d9f%3A0x3b7191b1286136c8!2sSector%2062%2C%20Noida%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1593853275447!5m2!1sen!2sin" width="800" height="600" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>

        </div>
    </section>-->
	
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/primewe1/public_html/saromc.com/welfares/resources/views/front/contact.blade.php ENDPATH**/ ?>