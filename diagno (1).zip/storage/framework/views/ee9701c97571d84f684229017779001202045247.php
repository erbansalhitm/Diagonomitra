
<style>
  /*********************************************
					TAB
*********************************************/
    
 .tab {
  overflow: hidden;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current "tab button" class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
}

    


.gold{
	color: #FFBF00;
}

/*********************************************
					PRODUCTS
*********************************************/

.product{
	border: 1px solid #dddddd;
	padding:10px;
	
}

.product>img{
max-width: 245px;
}

.product-rating{
	font-size: 20px;
	margin-bottom: 25px;
}

.product-title{
	font-size: 20px;
}

.product-desc{
	font-size: 14px;
}

.product-price{
	font-size: 22px;
}

.product-stock{
	color: #74DF00;
	font-size: 20px;
	margin-top: 10px;
}

.product-info{
		margin-top: 50px;
}

/*********************************************
					VIEW
*********************************************/

.content-wrapper {
	max-width: 1140px;
	background: #fff;
	margin: 0 auto;
	margin-top: 25px;
	margin-bottom: 10px;
	border: 0px;
	border-radius: 0px;
}



.view-wrapper {
	float: right;
	max-width: 70%;
	margin-top: 25px;
}



/*********************************************
				ITEM 
*********************************************/

.service1-items {
	padding: 0px 0 0px 0;
	
	position: relative;
	overflow: hidden;
	max-width: 100%;
	height: 321px;
	width: 130px;
}

.service1-item {
    height: 107px;
    width: 120px;
    display: table-cell;
    position: relative;
    border: 1px solid #ddd;
    padding: 5px;
}

.service1-item > img {
	max-height: 110px;
	max-width: 110px;
	opacity: 0.6;
	transition: all .2s ease-in;
	-o-transition: all .2s ease-in;
	-moz-transition: all .2s ease-in;
	-webkit-transition: all .2s ease-in;
}

.service1-item img:hover {
	cursor: pointer;
	opacity: 1;
}

.service-image-left {
	padding-right: 50px;
}

.service-image-right {
	padding-left: 50px;
}

.service-image-left > center > img,.service-image-right > center > img{
	max-height: 155px;
}

   
</style>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.1/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <section class="footer-widget-area footer-widget-area-bg section-custom-bg" style="background:linear-gradient( rgba(17,17,17,0.9),  rgba(17,17,17,0.9) ), url(&quot;<?php echo e(asset('public/front/')); ?>/images/section_custom_bg.jpg&quot;); background-position: center center;  
	 background-repeat: no-repeat;  background-attachment: inherit; background-size: cover;  overflow: hidden; ">
    <div class="container" >
	<div class="row" style="margin-top:50px;margin-bottom:50px">
	<h1 class="text-center" style="color:#fff" >Products</h1>
	</div>
</div>
     </section>
   
 

  <!--  ABOUT US -->

  <section class="section-content-block">
      <div class="container-fluid">
    <div class="content-wrapper">	
		<div class="item-container">	
			<div class="container">	
				<div class="col-md-12">
					<div class="product col-md-6 text-center">
                    
					
						    <img  src="<?php echo e(asset('public/front/')); ?>/images/features1.webp" style="width:100%;height:300px">
							
				<div class="logo-layout-1 logo-items owl-carousel" >
					
							<a id="item-1" class="service1-item">
							<img src="<?php echo e(asset('public/front/')); ?>/images/features1.webp">
							</a>
							<a id="item-2" class="service1-item">
							<img src="<?php echo e(asset('public/front/')); ?>/images/features1.webp">
							</a>
							<a id="item-3" class="service1-item">
								<img src="<?php echo e(asset('public/front/')); ?>/images/features1.webp">
							</a>
				<a id="item-4" class="service1-item">
								<img src="<?php echo e(asset('public/front/')); ?>/images/features1.webp">
							</a>
							</div>
					</div>
					
					
				
					
				<div class="col-md-6">
					<div class="product-title">Corsair GS600 600 Watt PSU</div>
					<div class="product-desc">The Corsair Gaming Series GS600 is the ideal price/performance choice for mid-spec gaming PC</div>
					<div class="product-rating"><i class="fa fa-star gold"></i> <i class="fa fa-star gold"></i> <i class="fa fa-star gold"></i> <i class="fa fa-star gold"></i> <i class="fa fa-star-o"></i> </div>
					<hr>
					<div class="product-price">$ 1234.00</div>
					<div class="product-stock">In Stock</div>
					<hr>
					<div class="btn-group cart">
						<button type="button" class="btn btn-success">
							Get A quote
						</button>
					</div>
					<div class="btn-group wishlist">
						<!--<button type="button" class="btn btn-danger">
							Add to wishlist -->
						</button>
					</div>
				</div>
			</div> 
		</div>
	


<!--TAB-->
   
    <!--  end .container  -->
  </section>
  <!--  end .section-content-block -->
  <section>
      <div class="container">
          <div class=" theme-custom-box-shadow" style="padding:30px;border-top:8px solid #ffc300">
          <div class="row">
              
<div class="tab">
  <button class="tablinks" onclick="openCity(event, 'description')" id="defaultOpen">Description</button>
  <button class="tablinks" onclick="openCity(event, 'information')">Information</button>
  <button class="tablinks" onclick="openCity(event, 'review')">Review</button>
</div>

<div id="description" class="tabcontent ">
  <h3>Description</h3>
   <p>Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui.
                                        Pellentesque in ipsum id orci porta dapibus. Proin eget tortor risus. Vivamus
                                        suscipit tortor eget felis porttitor volutpat. Vestibulum ac diam sit amet quam
                                        vehicula elementum sed sit amet dui. Donec rutrum congue leo eget malesuada.
                                        Vivamus suscipit tortor eget felis porttitor volutpat. Curabitur arcu erat,
                                        accumsan id imperdiet et, porttitor at sem. Praesent sapien massa, convallis a
                                        pellentesque nec, egestas non nisi. Vestibulum ac diam sit amet quam vehicula
                                        elementum sed sit amet dui. Vestibulum ante ipsum primis in faucibus orci luctus
                                        et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam
                                        vel, ullamcorper sit amet ligula. Proin eget tortor risus.</p>
                                        <p>Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Lorem
                                        ipsum dolor sit amet, consectetur adipiscing elit. Mauris blandit aliquet
                                        elit, eget tincidunt nibh pulvinar a. Cras ultricies ligula sed magna dictum
                                        porta. Cras ultricies ligula sed magna dictum porta. Sed porttitor lectus
                                        nibh. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a.
                                        Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Sed
                                        porttitor lectus nibh. Vestibulum ac diam sit amet quam vehicula elementum
                                        sed sit amet dui. Proin eget tortor risus.</p>
</div>

<div id="information" class="tabcontent">
  <h3>Information</h3>
   <p>Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui.
                                        Pellentesque in ipsum id orci porta dapibus. Proin eget tortor risus. Vivamus
                                        suscipit tortor eget felis porttitor volutpat. Vestibulum ac diam sit amet quam
                                        vehicula elementum sed sit amet dui. Donec rutrum congue leo eget malesuada.
                                        Vivamus suscipit tortor eget felis porttitor volutpat. Curabitur arcu erat,
                                        accumsan id imperdiet et, porttitor at sem. Praesent sapien massa, convallis a
                                        pellentesque nec, egestas non nisi. Vestibulum ac diam sit amet quam vehicula
                                        elementum sed sit amet dui. Vestibulum ante ipsum primis in faucibus orci luctus
                                        et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam
                                        vel, ullamcorper sit amet ligula. Proin eget tortor risus.</p>
                                        <p>Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Lorem
                                        ipsum dolor sit amet, consectetur adipiscing elit. Mauris blandit aliquet
                                        elit, eget tincidunt nibh pulvinar a. Cras ultricies ligula sed magna dictum
                                        porta. Cras ultricies ligula sed magna dictum porta. Sed porttitor lectus
                                        nibh. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a.
                                        Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Sed
                                        porttitor lectus nibh. Vestibulum ac diam sit amet quam vehicula elementum
                                        sed sit amet dui. Proin eget tortor risus.</p>
</div>

<div id="review" class="tabcontent">
  <h3>Review</h3>
   <p>Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui.
                                        Pellentesque in ipsum id orci porta dapibus. Proin eget tortor risus. Vivamus
                                        suscipit tortor eget felis porttitor volutpat. Vestibulum ac diam sit amet quam
                                        vehicula elementum sed sit amet dui. Donec rutrum congue leo eget malesuada.
                                        Vivamus suscipit tortor eget felis porttitor volutpat. Curabitur arcu erat,
                                        accumsan id imperdiet et, porttitor at sem. Praesent sapien massa, convallis a
                                        pellentesque nec, egestas non nisi. Vestibulum ac diam sit amet quam vehicula
                                        elementum sed sit amet dui. Vestibulum ante ipsum primis in faucibus orci luctus
                                        et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam
                                        vel, ullamcorper sit amet ligula. Proin eget tortor risus.</p>
                                        <p>Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Lorem
                                        ipsum dolor sit amet, consectetur adipiscing elit. Mauris blandit aliquet
                                        elit, eget tincidunt nibh pulvinar a. Cras ultricies ligula sed magna dictum
                                        porta. Cras ultricies ligula sed magna dictum porta. Sed porttitor lectus
                                        nibh. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a.
                                        Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Sed
                                        porttitor lectus nibh. Vestibulum ac diam sit amet quam vehicula elementum
                                        sed sit amet dui. Proin eget tortor risus.</p>
</div>
	</div>
</div>
              
          </div>
          </div>
          
      </div>
      
      
  </section>

 
      <section class="section-content-block" >
    <div class="container">
      <div class="row">
        
        <div class="col-md-12 col-sm-12 col-xs-12 " >
          <div class=" theme-custom-box-shadow" style="padding:30px;border-top:8px solid #ffc300">
		 <h2>
            Related Product
            </h2></br>
           <div class="row">

        <div class="logo-layout-1 logo-items owl-carousel" >

          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="">

            <div class="client-logo"   >

              <img src="<?php echo e(asset('public/front/')); ?>/images/product1.jpg" alt=""  >
			  

            </div>
            <p class="text-center">PRODUCT</p>
          </div>

          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">

            <div class="client-logo">

              <img src="<?php echo e(asset('public/front/')); ?>/images/product2.jpg" alt="" />
			 
            </div>
            <p class="text-center">PRODUCT</p>

          </div>

          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">

            <div class="client-logo">

              <img src="<?php echo e(asset('public/front/')); ?>/images/product3.jpg" alt="" />
              </div>
            <p class="text-center">PRODUCT</p>

          </div>

          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">

            <div class="client-logo">

              <img src="<?php echo e(asset('public/front/')); ?>/images/product4.jpg" alt="" />

            </div>
            <p class="text-center">PRODUCT</p>

          </div>

          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">

            <div class="client-logo">

              <img src="<?php echo e(asset('public/front/')); ?>/images/product5.jpg" alt="" />

            </div>
<p class="text-center">PRODUCT</p>
          </div>

          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">

            <div class="client-logo">

              <img src="<?php echo e(asset('public/front/')); ?>/images/product6.jpg" alt="" />

            </div>
<p class="text-center">PRODUCT</p>
          </div>

          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">

            <div class="client-logo">

              <img src="<?php echo e(asset('public/front/')); ?>/images/product7.jpg" alt="" />

            </div>
<p class="text-center">PRODUCT</p>
          </div>

          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">

            <div class="client-logo">
              <img src="<?php echo e(asset('public/front/')); ?>/images/product8.jpg" alt="" />
			  
            </div>
            <p class="text-center">PRODUCT</p>
          </div>
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">

            <div class="client-logo">
              <img src="<?php echo e(asset('public/front/')); ?>/images/product9.jpg" alt="" />
			  
            </div>
            <p class="text-center">PRODUCT</p>
          </div>
          
          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">

            <div class="client-logo">
              <img src="<?php echo e(asset('public/front/')); ?>/images/product10.jpg" alt="" />
			  
            </div>
            <p class="text-center">PRODUCT</p>
          </div>
          
          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">

            <div class="client-logo">
              <img src="<?php echo e(asset('public/front/')); ?>/images/product1.jpg" alt="" />
			  
            </div>
            <p class="text-center">PRODUCT</p>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">

            <div class="client-logo">
              <img src="<?php echo e(asset('public/front/')); ?>/images/product2.jpg" alt="" />
			 
            </div>
            
             <p class="text-center">PRODUCT</p>
          </div>
          
          
        </div> <!-- end .logo-items  -->

      </div> 
			

           
          </div>
        </div>
        <!-- end .col-sm-12  -->
      </div>
    </div>
    <!--  end .container  -->
  </section>
      
    

       

      <!--Section: Block Content-->
   

  

  <section class="section-content-block section-secondary-bg">
    <div class="container">
      <div class="row wow fadeInUp">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="appointment-form-wrapper light-layout margin-bottom-24 clearfix theme-custom-no-box-shadow">
            <div class="col-md-4 col-sm-12">
              <div class="appointment-form-heading text-left">
			  
                <h2 class="form-title text-capitalize margin-top-24">
                  GET A Query
                </h2>

                <p>
                  Please fill out the query form and very soon we will
                  contact with you to schedule .
                </p>
              </div>
            </div>

            <div class="col-md-8 col-sm-12">
              <form class="appoinment-form margin-top-42">
                <div class="form-group col-md-4">
                  <input id="your_name" class="form-control" placeholder="Name" type="text" required=""
                    data-msg="This field is required." />
                </div>
                <div class="form-group col-md-4">
                  <input id="your_email" class="form-control" placeholder="Email" type="email" required=""
                    data-msg="This field is required." />
                </div>
                <div class="form-group col-md-4">
                  <input id="your_phone" class="form-control" placeholder="Phone" type="text" required=""
                    data-msg="This field is required." />
                </div>

                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                  <textarea id="textarea_message" class="form-control" rows="3" placeholder="Your Message..."
                    required="" data-msg="This field is required."></textarea>
                </div>

                <div class="form-group col-md-12 col-sm-12 col-xs-12 text-left">
                  <button id="btn_submit" class="btn btn-theme btn-square wow zoomIn" type="submit">
                   Send
                  </button>
                </div>
              </form>
            </div>
          </div>
          <!-- end .appointment-form-wrapper  -->
        </div>
        <!--  end .col-lg-6 -->
      </div>
      <!--  end .row  -->
    </div>
    <!--  end .container -->
  </section>
  <!--  end .appointment-section  -->
 <script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
  
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH C:\xampp\htdocs\dm\resources\views/front/product.blade.php ENDPATH**/ ?>