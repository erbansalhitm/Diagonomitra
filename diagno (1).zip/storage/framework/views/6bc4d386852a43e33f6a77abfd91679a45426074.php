<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--Page Title-->
    <section class="page-title" style="background-image:url(<?php echo e(asset('public/front/')); ?>/images/background/bg-page-title-1.jpg);">
        <div class="auto-container">
            <h1>Our Blogs</h1>
            <div class="bread-crumb-outer">
                <ul class="bread-crumb clearfix">
                    <li><a href="index.php">Home</a></li>
                    <li class="active">Our Blogs</li>
                </ul>
            </div>
        </div>
    </section>
    
    
     <!--News Section-->
    <section class="news-section">
    	<div class="auto-container">
        	<!--Section Title-->
            <div class="sec-title centered">
            	<h2>OUR BLOG</h2>
                <div class="separator"></div>
                
            </div>
            
        	<div class="">
				<div class="container">
					
					<div class="row">
						<div class="col-md-12">
							<div id="news-slider2" class="owl-carousel">
								<div class="post-slide2">
									<div class="post-img">
										<a href="#"><img src="<?php echo e(asset('public/front/')); ?>/images/blog/blog1.jpg" alt=""></a>
									</div>
									<div class="post-content">
										<h3 class="post-title"><a href="#">Latest News Post</a></h3>
										<p class="post-description">
											Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec elementum mauris. Praesent vehicula gravida dolor, ac efficitur sem sagittis.
										</p>
										
										<a href="blog-detail.php" class="theme-btn btn-style-three">read more</a>
									</div>
								</div>
			 
								<div class="post-slide2">
									<div class="post-img">
										<a href="#"><img src="<?php echo e(asset('public/front/')); ?>/images/blog/blog2.jpg" alt=""></a>
									</div>
									<div class="post-content">
										<h3 class="post-title"><a href="#">Latest News Post</a></h3>
										<p class="post-description">
											Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec elementum mauris. Praesent vehicula gravida dolor, ac efficitur sem sagittis.
										</p>
										
										<a href="blog-detail.php" class="theme-btn btn-style-three">read more</a>
									</div>
								</div>
								
								<div class="post-slide2">
									<div class="post-img">
										<a href="#"><img src="<?php echo e(asset('public/front/')); ?>/images/blog/blog3.jpg" alt=""></a>
									</div>
									<div class="post-content">
										<h3 class="post-title"><a href="#">Latest News Post</a></h3>
										<p class="post-description">
											Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec elementum mauris. Praesent vehicula gravida dolor, ac efficitur sem sagittis.
										</p>
										
										<a href="blog-detail.php" class="theme-btn btn-style-three">read more</a>
									</div>
								</div>
								
								<div class="post-slide2">
									<div class="post-img">
										<a href="#"><img src="<?php echo e(asset('public/front/')); ?>/images/blog/blog5.jpg" alt=""></a>
									</div>
									<div class="post-content">
										<h3 class="post-title"><a href="#">Latest News Post</a></h3>
										<p class="post-description">
											Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec elementum mauris. Praesent vehicula gravida dolor, ac efficitur sem sagittis.
										</p>
									
										<a href="blog-detail.php" class="theme-btn btn-style-three">read more</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
        </div>
    </section>
	
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/welfare/resources/views/front/blogs.blade.php ENDPATH**/ ?>