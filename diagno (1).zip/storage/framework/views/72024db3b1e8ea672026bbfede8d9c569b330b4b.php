<!--Main Footer-->
    <footer class="main-footer">
    	<div class="auto-container">
        
            <!--Widgets Section-->
            <div class="widgets-section">
            	<div class="row clearfix">
                	<!--Big Column-->
                	<div class="col-md-8">
                    	<div class="row clearfix">
                            
                            <!--Footer Column-->
                        	<div class="footer-column col-md-6 col-sm-6 col-xs-12">
                            	<div class="footer-widget about-widget">
                                	<h2>About Us</h2>
                                    <div class="widget-content">
                                    	<div class="text">
                                        	<p>We are a Nonpolitical, Community Service Association which has come into existence with the support of approximately 250+ families residing in Sector-31 Faridabad, Which is an independent Association with no linkages with the Resident Welfare Associations of the Sector.</p>
                                            <a href="about.php" class="more-link">Read More <span class="fa fa-angle-double-right"></span></a>
                                        </div>
                                        <!---
                                        <div class="social-links">
                                        	<a href="#"><span class="fa fa-facebook-f"></span></a>
                                            <a href="#"><span class="fa fa-twitter"></span></a>
                                            <a href="#"><span class="fa fa-linkedin"></span></a>
                                            <a href="#"><span class="fa fa-google-plus"></span></a>
                                            <a href="#"><span class="fa fa-skype"></span></a>
                                        </div>
                                        ---->
                                    </div>
                                </div>
                            </div>
                            
                            <!--Footer Column-->
                        	<div class="footer-column col-md-6 offset-1 " style="padding-left: 100px;">
                            	<div class="footer-widget links-widget">
                                	<h2>Useful Links</h2>
                                    <div class="widget-content">
                                        <ul class="list">
                                            <li><a href="#">About Us </a></li>
                                            <li><a href="#">Activites</a></li>
                                            <li><a href="#">Product</a></li>
                                            <li><a href="#">Blog</a></li>
                                            <li><a href="#">Video</a></li>
                                            <li><a href="#">Contact Us</a></li>
                                            
                                        </ul>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>
                    </div>
                    
                    <!--Big Column-->
                	<div class="big-column col-md-4 ">
                    	<div class="row clearfix">
                            
                            
                            
                            <!--Footer Column-->
                        	<div class="footer-column col-md-12">
                            	<div class="footer-widget contact-widget">
                                	<h2>Contact Us</h2>
                                    <div class="widget-content">
                                    	<ul class="contact-info" style="width: 65%;">
                                            <li class="bd"><strong>Punjabi Welfare Associtaion</strong></li>
                                            <li class="bd">Add- Sec-31 Faridabad, Haryana 121008 </li>
                                        	<li class="bd">Email Id-info@punjabiwelfare.in </li>
                                        	<li class="bd">Phone-+91-111-111-1111</li>
                                        </ul>
                                        
                                    	<!--Newsletter One-->
                                        
                                    
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>
                    </div>
                    
                 </div>
             </div>
        
        </div>
        
        <!--Footer Bottom-->
         <div class="footer-bottom">
         	<div class="auto-container">
            	<div class="copyright-text">Copyright &copy; 2020. All Rights Reserved By AIS</div>
            </div>
        </div>
    </footer>
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-long-arrow-up"></span></div>


<script src="<?php echo e(asset('public/front/js/jquery.js')); ?>"></script> 
<script src="<?php echo e(asset('public/front/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/front/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/front/js/revolution.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/front/js/jquery.fancybox.pack.js')); ?>"></script>
<script src="<?php echo e(asset('public/front/js/jquery.fancybox-media.js')); ?>"></script>
<script src="<?php echo e(asset('public/front/js/isotope.js')); ?>"></script>
<script src="<?php echo e(asset('public/front/js/owl.js')); ?>"></script>
<script src="<?php echo e(asset('public/front/js/wow.js')); ?>"></script>
<script src="<?php echo e(asset('public/front/js/appear.js')); ?>"></script>
<script src="<?php echo e(asset('public/front/js/script.js')); ?>"></script>
<script>
	$(document).ready(function() {
    $("#news-slider").owlCarousel({
        items : 2,
        itemsDesktop : [1199,2],
        itemsMobile : [600,1],
        pagination :true,
        autoPlay : true
    });
    
    $("#news-slider2").owlCarousel({
        items:3,
        itemsDesktop:[1199,2],
        itemsDesktopSmall:[980,2],
        itemsMobile:[600,1],
        pagination:false,
        navigationText:false,
        autoPlay:true
    });
    
    $("#news-slider3").owlCarousel({
        items:3,
        itemsDesktop:[1199,2],
        itemsDesktopSmall:[1000,2],
        itemsMobile:[700,1],
        pagination:false,
        navigationText:false,
        autoPlay:true
    });
    
    $("#news-slider4").owlCarousel({
        items:3,
        itemsDesktop:[1199,3],
        itemsDesktopSmall:[1000,2],
        itemsMobile:[600,1],
        pagination:false,
        navigationText:false,
        autoPlay:true
    });
    
    $("#news-slider5").owlCarousel({
        items:3,
        itemsDesktop:[1199,3],
        itemsDesktopSmall:[1000,2],
        itemsMobile:[650,1],
        pagination:false,
        navigationText:false,
        autoPlay:true
    });
    
    $("#news-slider6").owlCarousel({
        items : 3,
        itemsDesktop:[1199,3],
        itemsDesktopSmall:[980,2],
        itemsMobile : [600,1],
        pagination:false,
        navigationText:false
    });
    
    $("#news-slider7").owlCarousel({
        items : 3,
        itemsDesktop : [1199,3],
        itemsDesktopSmall : [1000,2],
        itemsMobile : [650,1],
        pagination :false,
        autoPlay : true
    });
    
    $("#news-slider8").owlCarousel({
        items : 3,
        itemsDesktop:[1199,3],
        itemsDesktopSmall:[980,2],
        itemsMobile : [600,1],
        autoPlay:true
    });
    
    $("#news-slider9").owlCarousel({
        items : 3,
        itemsDesktop:[1199,2],
        itemsDesktopSmall:[980,2],
        itemsTablet:[650,1],
        pagination:false,
        navigation:true,
        navigationText:["",""]
    });
    
    $("#news-slider10").owlCarousel({
        items : 4,
        itemsDesktop:[1199,3],
        itemsDesktopSmall:[980,2],
        itemsMobile : [600,1],
        navigation:true,
        navigationText:["",""],
        pagination:true,
        autoPlay:true
    });
    
    $("#news-slider11").owlCarousel({
        items : 4,
        itemsDesktop:[1199,3],
        itemsDesktopSmall:[980,2],
        itemsMobile : [600,1],
        pagination:true,
        autoPlay:true
    });
    
    $("#news-slider12").owlCarousel({
        items : 2,
        itemsDesktop:[1199,2],
        itemsDesktopSmall:[980,1],
        itemsTablet: [600,1],
        itemsMobile : [550,1],
        pagination:true,
        autoPlay:true
    });
    
    $("#news-slider13").owlCarousel({
        navigation : false,
        pagination : true,
        items : 3,
        itemsDesktop:[1199,3],
        itemsDesktopSmall:[980,2],
        itemsMobile : [600,1],
        navigationText : ["",""]
    });
    
    $("#news-slider14").owlCarousel({
        items : 4,
        itemsDesktop:[1199,3],
        itemsDesktopSmall:[980,2],
        itemsMobile : [550,1],
        pagination:false,
        autoPlay:true
    });
});

</script>
<script>
         $(".video-play").on('click', function(e) {
        e.preventDefault(); 
        var vidWrap = $(this).parent(),
            iframe = vidWrap.find('.video iframe'),
            iframeSrc = iframe.attr('src'),
            iframePlay = iframeSrc += "?autoplay=1";
        vidWrap.children('.video-thumbnail').fadeOut();
        vidWrap.children('.video-play').fadeOut();
        vidWrap.find('.video iframe').attr('src', iframePlay);


    });
    </script>
    <script>
      $(document).ready(function(){
         let scroll_link = $('.scroll');
        
          //smooth scrolling -----------------------
          scroll_link.click(function(e){
              e.preventDefault();
              let url = $('body').find($(this).attr('href')).offset().top;
              $('html, body').animate({
                scrollTop : url
              },700);
              $(this).parent().addClass('active');
              $(this).parent().siblings().removeClass('active');
              return false;	
           });
        });
  </script>
    <script>
        
    </script>
</body>


</html><?php /**PATH /opt/lampp/htdocs/welfare/resources/views/front/footer.blade.php ENDPATH**/ ?>