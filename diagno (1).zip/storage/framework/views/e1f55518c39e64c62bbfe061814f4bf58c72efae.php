<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br/><br/>
    <div class="container" style="padding: 35px;">
        <div class="row">
			<div class="col-md-5 mx-auto">
			<div id="first">
				<div class="myform form ">
					 <div class="logo mb-3">
						 <div class="col-md-12 text-center">
							<h1><a href="<?php echo e(url('customer/logout')); ?>">logout</a></h1>
              
						 </div>
					</div>
                   
                 
				</div>
			</div>
		
			
		</div>
      </div>
<br/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script> 
                $(document).ready(function(){
                  $("#flip").click(function(){
                    $("#panel").toggle("slow");
                  });
                  
                
                });
            </script>

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/gold/resources/views/front/dashboard.blade.php ENDPATH**/ ?>