   
<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
  <style> 
             #panel, #flip {
                  padding: 0px;
                  text-align: center;
                  }
                #panel {
                  padding: 0px;
                  display: none;
                }
               #content {
    position: relative;
    overflow: hidden;
    background-color: #fbfafa05;
}
#footer{
    border-top:none;
}
.oc-item{

   border:1px solid gray;
    background: none;
    text-align: center;
    padding:10px;
}
.p1{
    height: 26px;
     padding: 0px 0px 10px 0px;
     background:none !important;
    
}
 </style>
<!-- Slider 1 -->
<div class="slider" id="slider1">
    <!-- Slides -->
    <div style="background-image:url(<?php echo e(asset('public/front/images/banner.jpg')); ?>)"></div>
    <div style="background-image:url(<?php echo e(asset('public/front/images/banner1.png')); ?>)"></div>
    <!-- The Arrows -->
    <i class="left" class="arrows" style="z-index:2; position:absolute;"><svg viewBox="0 0 100 100"><path d="M 10,50 L 60,100 L 70,90 L 30,50  L 70,10 L 60,0 Z"></path></svg></i>
    <i class="right" class="arrows" style="z-index:2; position:absolute;"><svg viewBox="0 0 100 100"><path d="M 10,50 L 60,100 L 70,90 L 30,50  L 70,10 L 60,0 Z" transform="translate(100, 100) rotate(180) "></path></svg></i>
    <!-- Title Bar -->
    </div>
<section id="content">
		<div class="container-fluid mr">
			<div class="row" style="margin-top:30px;">
				<div class="col-md-4">
					<a href="#"><img src="<?php echo e(asset('public/front/images/gold4.png')); ?>" class="imgbd" alt=""></a>
				</div>
				<div class="col-md-4">
					<img src="<?php echo e(asset('public/front/images/gold5.png')); ?>" class="imgbd" alt="">
				</div>
				<div class="col-md-4">
					<img src="<?php echo e(asset('public/front/images/gold6.png')); ?>" class="imgbd" alt="">
				</div>
			</div>
		
                
                <div id="panel">
                    <div class="row" style="margin-top:30px;">
                		<div class="col-md-4">
                			<a href="#"><img src="<?php echo e(asset('public/front/images/gold9.png')); ?>" class="imgbd" alt=""></a>
                		</div>
                		<div class="col-md-4">
                			<img src="<?php echo e(asset('public/front/images/gold7.png')); ?>" class="imgbd" alt="">
                		</div>
                		<div class="col-md-4">
                			<img src="<?php echo e(asset('public/front/images/gold8.png')); ?>" class="imgbd" alt="">
                		</div>
                	</div>
                </div>
			<div id="flip">
                    <button class="css-5erg081 elpz4pe6">See All</button>
                </div>
		</div>
	</section>
	
	
	<div id="oc-clients-full" class="owl-carousel owl-carousel-full image-carousel bottommargin-sm carousel-widget" data-margin="30" data-loop="false" data-nav="false" data-autoplay="5000" data-pagi="false" data-items-xs="2" data-items-sm="3" data-items-md="4" data-items-lg="5" data-items-xl="6">
					<div class="oc-item">
				   <a href="#">
                  <img src="images/log1.jpg" alt="Clients"><p class="p1">₹3531,<span><del>1425</del></span><br>Maa Love Charm </p>
                   <button type="button" class=" btn btn-primary">Try at Home </button></a>
                   </div>
					<div class="oc-item"><a href="#"><img src="<?php echo e(asset('public/front/images/cq.jpg')); ?>" alt="Clients"><p class="p1">₹3531,<span><del>4521</del></span><br>Swivel Mesh Ring </p><button  class=" btn btn-primary" type="button">Try at Home </button></a></div>
					<div class="oc-item"><a href="#"><img src="<?php echo e(asset('public/front/images/log3.jpg')); ?>" alt="Clients"><p class="p1">₹3531,<span><del>4521</del></span><br>Drop Earrings </p><button class=" btn btn-primary" type="button">Try at Home </button></a></div>
					<div class="oc-item"><a href="#"><img src="<?php echo e(asset('public/front/images/log4.jpg')); ?>" alt="Clients"><p class="p1">₹3531,<span><del>4521</del></span><br>Dual Heart Bracelet </p><button class=" btn btn-primary" type="button">Try at Home </button></a></div>
					<div class="oc-item"><a href="#"><img src="<?php echo e(asset('public/front/images/log5.jpg')); ?>" alt="Clients"><p class="p1">₹3531,<span><del>4521</del></span><br>Pine Adjustable Rings </p><button class=" btn btn-primary" type="button">Try at Home </button></a></div>
					<div class="oc-item"><a href="#"><img src="<?php echo e(asset('public/front/images/log6.jpg')); ?>" alt="Clients"><p class="p1">₹3531,<span><del>4521</del></span><br>Northern Star Cluster Necklace </p><button type="button" class=" btn btn-primary">Try at Home </button></a></div>
					</div>
					

		
	<section id="content" style="background: url(<?php echo e(asset('public/front/images/gol4.png')); ?>) center center / cover no-repeat; height: 362px;"></section>

	<section id="content">
		<div class="content-wrap">
			
				<div class="container">
					<div class="row" style="margin-top:30px;">
						<div class="col-md-6">
							<img src="<?php echo e(asset('public/front/images/gold3.png')); ?>" alt="">
						</div>
						<div class="col-md-6" style="padding:35px;">
							<h2>Gifts That Show Them You Care</h2>
							<div class="underline__container css-1mxcjm6 evgra8b2"><span class="css-ak8f16 evgra8b3"></span><span class="css-i6ykbt evgra8b3"></span></div>
							<ul class="css-kn28h9 elpz4pe5"><li>-  Pick something from our thoughtful gift curation, or surprise them with a Try@Home appointment<br></li><li>-  Fast delivery that’s right on time for your special occasion<br></li><li>-  Guaranteed 15 Day Money Back</li></ul>
							<button class="css-5erg08 elpz4pe6">Gift Something Special</button>
						</div>
						
					</div>
				</div>
				</div>
			</section>
			
			
			
			
				
			<div class="clear"></div>
			<div class="section footer-stick notopmargin" style="background-color:#fb8b2a9c;">
			
				<div class="fslider testimonial testimonial-full" data-animation="fade" data-arrows="false">
					<div class="flexslider">
						<div class="slider-wrap">
							<div class="slide">
								<div class="testi-image">
									<a href="#"><img src="<?php echo e(asset('public/front//testimonials/3.jpg')); ?>" alt="Customer Testimonails"></a>
								</div>
								<div class="testi-content">
									<p style="color: white;font-family:'MuliRegular','Helvetica Neue',Helvetica,Arial,sans-serif;">Similique fugit repellendus expedita excepturi iure perferendis provident quia eaque. Repellendus, vero numquam?</p>
										<div class="testi-meta" style="color: white;">
											Steve Jobs
											<span style="color: white;">Apple Inc.</span>
										</div>
								</div>
							</div>
							<div class="slide">
								<div class="testi-image">
									<a href="#"><img src="<?php echo e(asset('public/front//testimonials/2.jpg')); ?>" alt="Customer Testimonails"></a>
								</div>
								<div class="testi-content">
									<p style="color: white;font-family:'MuliRegular','Helvetica Neue',Helvetica,Arial,sans-serif;">Natus voluptatum enim quod necessitatibus quis expedita harum provident eos obcaecati id culpa corporis molestias.</p>
									<div class="testi-meta"style="color: white;">
										Collis Ta'eed
										<span style="color: white;">Envato Inc.</span>
									</div>
								</div>
							</div>
							<div class="slide">
								<div class="testi-image">
									<a href="#"><img src="<?php echo e(asset('public/front//testimonials/1.jpg')); ?>" alt="Customer Testimonails"></a>
								</div>
								<div class="testi-content">
									<p style="color: white;font-family:'MuliRegular','Helvetica Neue',Helvetica,Arial,sans-serif;">Incidunt deleniti blanditiis quas aperiam recusandae consequatur ullam quibusdam cum libero illo rerum!</p>
									<div class="testi-meta" style="color: white;">
										John Doe
										<span style="color: white;">XYZ Inc.</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
		</div>	
		</div>
		
		<!--<section id="content">
			<div class="container-fluid mr">
				<div class="row" style="margin-top:30px;">
					<div class="col-md-12">
						<h3 style="float:left;">Shop Our Instagram</h3>
						<h3 style="float:right;"># My Carat Lane Story</h3>
					</div>
					<div class="col-md-12">
						<div class="css-18vusmf e104r02j3">
							<div data-name="insta_image_main" class="css-129r5k2 e104r02j4">
								<a href="#" class="e104r02j7 css-xhk7tk epg3bs00">
									<img class="css-1urmjh1 e1nln7oz0 zoom" data-src="https://images.cltstatic.com/live-images/fb65513c9fc241b3ae725ad510e5ce80.jpg" data-srcset="https://images.cltstatic.com/live-images/293947c7bcdf4cb3839860c5bb3a937b.jpg 2x,https://images.cltstatic.com/live-images/8358deb4699f40d19c3dd03b6a00b0f2.jpg 3x" srcset="https://images.cltstatic.com/live-images/293947c7bcdf4cb3839860c5bb3a937b.jpg 2x,https://images.cltstatic.com/live-images/8358deb4699f40d19c3dd03b6a00b0f2.jpg 3x" src="images/gl1.png"  style="height:100%; alt="instagram image">
								</a>
							</div>
							<div data-name="insta_image_sub" class="css-8f8nab e104r02j5">
								<div data-name="insta_image_child" class="css-hw99cy e104r02j6">
									<a href="#" class="css-13o7eu2 e104r02j7">
										<img class="css-1urmjh1 e1nln7oz0 zoom" data-src="https://images.cltstatic.com/live-images/9f5c33372fd14b0abb581bc6f9d430f5.jpg" data-srcset="https://images.cltstatic.com/live-images/d19756e88c7d48b5896562bb99e3cbcd.jpg 2x,https://images.cltstatic.com/live-images/43489c876dfb4d8faa14fc34b777b5ff.jpg 3x" srcset="https://images.cltstatic.com/live-images/d19756e88c7d48b5896562bb99e3cbcd.jpg 2x,https://images.cltstatic.com/live-images/43489c876dfb4d8faa14fc34b777b5ff.jpg 3x" src="images/gl2.png"  style="height:100%; alt="instagram image">
									</a>
								</div>
								<div data-name="insta_image_child" class="css-hw99cy e104r02j6">
									<a href="#" class="css-13o7eu2 e104r02j7">
										<img class="css-1urmjh1 e1nln7oz0 zoom" data-src="https://images.cltstatic.com/live-images/cac73a57eaf04bccadfca92400f00c92.jpg" data-srcset="https://images.cltstatic.com/live-images/fc62db042a47433f984be1d9c3ab4174.jpg 2x,https://images.cltstatic.com/live-images/bd37f39076d44d02bdab4279f054d2f6.jpg 3x" srcset="https://images.cltstatic.com/live-images/fc62db042a47433f984be1d9c3ab4174.jpg 2x,https://images.cltstatic.com/live-images/bd37f39076d44d02bdab4279f054d2f6.jpg 3x" src="images/gl3.png"  style="height:100%; alt="instagram image">
									</a>
								</div>
								<div data-name="insta_image_child" class="css-hw99cy e104r02j6">
									<a href="#" class="css-13o7eu2 e104r02j7">
										<img class="css-1urmjh1 e1nln7oz0 zoom" data-src="https://images.cltstatic.com/live-images/b4dd9d720f564119a5cfbbce770eafa8.jpg" data-srcset="https://images.cltstatic.com/live-images/090eb9f05a3e435a96a8a54acee25125.png 2x,https://images.cltstatic.com/live-images/c9f20fa8ba2a4a268c52f671ee933c2a.png 3x" srcset="https://images.cltstatic.com/live-images/090eb9f05a3e435a96a8a54acee25125.png 2x,https://images.cltstatic.com/live-images/c9f20fa8ba2a4a268c52f671ee933c2a.png 3x" src="images/gl4.png"  style="height:100%; alt="instagram image">
									</a>
								</div>
								<div data-name="insta_image_child" class="css-hw99cy e104r02j6">
									<a href="#" class="css-13o7eu2 e104r02j7">
										<img class="css-1urmjh1 e1nln7oz0 zoom" data-src="https://images.cltstatic.com/live-images/87230453e2064031888ea753c684c86f.jpg" data-srcset="https://images.cltstatic.com/live-images/fcf23b645c0a41f4a82ff3f75ca94501.jpg 2x,https://images.cltstatic.com/live-images/be279164663640928e1b975663e5efe6.jpg 3x" srcset="https://images.cltstatic.com/live-images/fcf23b645c0a41f4a82ff3f75ca94501.jpg 2x,https://images.cltstatic.com/live-images/be279164663640928e1b975663e5efe6.jpg 3x" src="images/gl5.png"  style="height:100%; alt="instagram image">
									</a>
								</div>
								<div data-name="insta_image_child" class="css-hw99cy e104r02j6">
									<a href="#" class="css-13o7eu2 e104r02j7">
										<img class="css-1urmjh1 e1nln7oz0 zoom" data-src="https://images.cltstatic.com/live-images/84c7743c2d8d4f3d85edc18de64c54a9.jpg" data-srcset="https://images.cltstatic.com/live-images/234f9324299a4983a8e6af687ff0485a.jpg 2x,https://images.cltstatic.com/live-images/87249ae88fe745d6a05c0c33e5dd8ef4.jpg 3x" srcset="https://images.cltstatic.com/live-images/234f9324299a4983a8e6af687ff0485a.jpg 2x,https://images.cltstatic.com/live-images/87249ae88fe745d6a05c0c33e5dd8ef4.jpg 3x" src="images/gl6.png"  style="height:100%; alt="instagram image">
									</a>
								</div>
								<div data-name="insta_image_child" class="css-hw99cy e104r02j6">
									<a href="#" class="css-13o7eu2 e104r02j7">
										<img class="css-1urmjh1 e1nln7oz0 zoom" data-src="https://images.cltstatic.com/live-images/223c5834c59344dda82b7f8b6695e13e.jpg" data-srcset="https://images.cltstatic.com/live-images/8f6682fa589f40c7b519fb28dcffd4b8.jpg 2x,https://images.cltstatic.com/live-images/0d4e3d6ed5874f1e867e43eae6180327.jpg 3x" srcset="https://images.cltstatic.com/live-images/8f6682fa589f40c7b519fb28dcffd4b8.jpg 2x,https://images.cltstatic.com/live-images/0d4e3d6ed5874f1e867e43eae6180327.jpg 3x" src="images/gl7.png"  style="height:100%; alt="instagram image">
									</a>
								</div>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</section>-->
		
		
		</div>
		
	</section>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
			<script> 
                $(document).ready(function(){
                  $("#flip").click(function(){
                    $("#panel").toggle("slow");
                  });
                  
                
                });
            </script>

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php /**PATH /home/primewe1/public_html/saromc.com/gold/resources/views/front/index.blade.php ENDPATH**/ ?>