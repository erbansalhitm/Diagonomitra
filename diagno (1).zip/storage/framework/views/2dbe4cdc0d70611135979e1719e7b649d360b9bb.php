<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/bg-page-title-1.jpg);">
        <div class="auto-container">
            <h1>Our Gallery</h1>
            <div class="bread-crumb-outer">
                <ul class="bread-crumb clearfix">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="active">Videos</li>
                </ul>
            </div>
        </div>
    </section>
    
    <section class="about-us-section">
    	
    	    <div class="container">
                <h2 class="text-center">Videos</h2>
                <div class="row">
                    
                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                    <div class="col-md-4 col-sm-12 col-xs-12" >
                 
                      <div class="panel panel-default"  style="box-shadow: -1px 2px 4px 4px grey;">
                        <div class="panel-body">
                        <div class="embed-responsive embed-responsive-16by9">
                        <?php echo $video->url; ?>

                        </div>
                 
                    </div>
                  
                    
                    </div>
                    
                 
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
            	    
                </div>
            </div>
    </section>
    

	
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/primewe1/public_html/saromc.com/welfares/resources/views/front/videos.blade.php ENDPATH**/ ?>