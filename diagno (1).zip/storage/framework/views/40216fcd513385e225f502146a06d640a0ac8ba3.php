<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    .text-box {
	position: absolute;
	top: 50%;
	left: 15%;
	right: 15%;
	color: #000;
	transform: translateY(-50%);
    }
    #slider-animation-2 .carousel-item img{width:100%;}
    .text-box img  {width:100%}
    .red-color{color:red; font-size:60px; text-align:center; margin-bottom:20px; margin-top:40px;
    text-transform:uppercase; width:100%;}
    .text-p{text-align:center; width:100%; margin-bottom:60px;}
</style>
    <section>
        
                   <div id="slider-animation-2" class="carousel slide" data-ride="carousel">                  
                      <!-- The slideshow -->
                      <div class="carousel-inner">
                        <div class="carousel-item active">
                          <img src="<?php echo e(asset('public/front/blog').'/'.$blog->image); ?>" style="height: 355px;" alt="<?php echo e($blog->title); ?>">
                           
                        </div>
                        
                      </div>

                    </div> 
                
    </section>
        <div class="container" style="padding-top: 30px;padding-bottom: 30px;">
            <div class="row">
                
                <div class="col-md-12">
                    <h2><?php echo e($blog->title); ?></h2>
                    <p><?php echo $blog->content; ?></p>
                </div>
            </div>
        </div>
        
        
    
<script>
       wow = new WOW(
      {
        animateClass: 'animated',
        offset:       100,
        callback:     function(box) {
          console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
        }
      }
    );
    wow.init();
    document.getElementById('moar').onclick = function() {
      var section = document.createElement('section');
      section.className = 'section--purple wow fadeInDown';
      this.parentNode.insertBefore(section, this);
    };
</script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script> 
                $(document).ready(function(){
                  $("#flip").click(function(){
                    $("#panel").toggle("slow");
                  });
                  
                
                });
            </script>
            
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/gold/resources/views/front/blog-details.blade.php ENDPATH**/ ?>