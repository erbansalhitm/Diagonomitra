<!DOCTYPE html>
<html>


<head>
<meta charset="utf-8">
<title>Punjabi Welfare</title>
<!-- Stylesheets -->
<link href="<?php echo e(asset('public/front/css/bootstrap.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/front/css/revolution-slider.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/front/css/style.css')); ?>" rel="stylesheet">
<link rel="shortcut icon" href="<?php echo e(asset('public/front/images/favicon.ico')); ?>" type="image/x-icon">
<link rel="icon" href="<?php echo e(asset('public/front/images/favicon.ico')); ?>" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link href="<?php echo e(asset('public/front/css/responsive.css')); ?>" rel="stylesheet">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">
 	
    <!-- Preloader -->
    <!--<div class="preloader"></div>-->
 	
    <!-- Main Header-->
    <header class="main-header">
    	<!-- Header Top -->
    	<div class="header-top">
        	<div class="auto-container">
            	<div class="clearfix">
                    
                    <!--Top Left-->
                    <div class="top-left">
                    	<ul class="clearfix">
                        	<li><span class="icon flaticon-technology"></span>+91-9876543210</li>
                            <li><span class="icon flaticon-note"></span>info@punjabiwelfare.in</li>
                        </ul>
                    </div>
                    
                    <!--Top Right-->
                    <div class="top-right">
                    
                    	<!--social-icon-->
                        <div class="social-icon">
                        	<a href="#"><span class="fa fa-facebook"></span></a>
                            <a href="#"><span class="fa fa-youtube-play"></span></a>
                            <a href="#"><span class="fa fa-linkedin"></span></a>
                            <a href="#"><span class="fa fa-instagram"></span></a>
                            <a href="#"><span class="fa fa-twitter"></span></a>
                        </div>
                        
                        
                    </div>
                    
                </div>
                
            </div>
        </div><!-- Header Top End -->
        
        
        <!-- Main Box -->
    	<div class="main-box">
        	<div class="auto-container">
            	<div class="outer-container clearfix">
                    <!--Logo Box-->
                    <div class="logo-box" style="width: 6%;">
                        <div class="logo"><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('public/front/images/logo.png')); ?>" alt=""></a></div>
                    </div>
                    
                    <!--Nav Outer-->
                    <div class="nav-outer clearfix">
                        <!-- Main Menu -->
                        <nav class="main-menu">
                            <div class="navbar-header">
                                <!-- Toggle Button -->    	
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                </button>
                            </div>
                            
                            <div class="navbar-collapse collapse clearfix">
                                <ul class="navigation clearfix">
                                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                    <li><a href="<?php echo e(url('aboutus')); ?>">About Us</a></li>
                                    <li class="dropdown"><a href="#">Activities</a>
                                    	<ul>
                                            <li><a href="<?php echo e(url('images')); ?>">Image</a></li>
                                            <li><a href="<?php echo e(url('vedios')); ?>">Vedio</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="<?php echo e(url('matrimonial')); ?>">Matrimonial</a>
                                    	
                                    </li>
                                    <li><a href="<?php echo e(url('product')); ?>">Product</a></li>
                                    <li><a href="<?php echo e(url('blog')); ?>">Blog</a></li>
                                    <li><a href="<?php echo e(url('contact')); ?>">Contact</a></li>
                                    <li><a href="<?php echo e(url('login')); ?>">login</a></li>
                                    <li><a href="#"><i class="fa fa-shopping-cart" aria-hidden="true" style="font-size: 23px;"></i></a></li>
									<!---<li><div class="links"><a href="bussiness-listing.php" class="theme-btn btn-style-three">Bussiness Listing</a> </div></li>--->
                                 </ul>
                            </div>
                        </nav><!-- Main Menu End-->
                        
                    </div><!--Nav Outer End-->
                    
                    <!-- Hidden Nav Toggler -->
                    <div class="nav-toggler">
                    <button class="hidden-bar-opener"><span class="icon fa fa-bars"></span></button>
                    </div><!-- / Hidden Nav Toggler -->
                    
            	</div>    
            </div>
        </div>
    
    </header>
    <!--End Main Header -->
    
    
    <!-- Hidden Navigation Bar -->
    <section class="hidden-bar right-align">
        
        <div class="hidden-bar-closer">
            <button class="btn"><i class="fa fa-close"></i></button>
        </div>
        
        <!-- Hidden Bar Wrapper -->
        <div class="hidden-bar-wrapper">
        
            <!-- .logo -->
            <div class="logo text-center">
                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('public/front/images/logo-2.png')); ?>" alt=""></a>			
            </div><!-- /.logo -->
            
            <!-- .Side-menu -->
            <div class="side-menu">
            <!-- .navigation -->
                <ul class="navigation">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li><a href="<?php echo e(url('aboutus')); ?>">About Us</a></li>
                    <li class="dropdown"><a href="#">Causes</a>
                        <ul>
                            <li><a href="#">Our Causes</a></li>
                            <li><a href="#">Single Cause</a></li>
                        </ul>
                    </li>
                    <li class="dropdown"><a href="#">Events</a>
                        <ul>
                            <li><a href="#">Our Events</a></li>
                            <li><a href="#">Event Details</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo e(url('product')); ?>">Product</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li class="dropdown"><a href="#">Shop</a>
                        <ul>
                            <li><a href="#">Our Shop</a></li>
                            <li><a href="#">Shop Single</a></li>
                            <li><a href="#">Shopping Cart</a></li>
                        </ul>
                    </li>
                    <li class="dropdown"><a href="#">Blog</a>
                        <ul>
                            <li><a href="#">Our Blog</a></li>
                            <li><a href="#">Blog Single</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo e(url('contact')); ?>">Contact</a></li>
					<li><a href="<?php echo e(url('login')); ?>">Login</a></li>
					<li><div class="links"><a href="bussiness-listing.php" class="theme-btn btn-style-three">Bussiness Listing</a> </div></li>
                </ul>
            </div><!-- /.Side-menu -->
        
            <div class="social-icons">
                <ul>
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                </ul>
            </div>
        
        </div><!-- / Hidden Bar Wrapper -->
    </section>
    <!-- / Hidden Bar --><?php /**PATH /home/primewe1/public_html/saromc.com/welfares/resources/views/front/header.blade.php ENDPATH**/ ?>