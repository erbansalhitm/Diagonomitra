    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
	 <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    <h1>
    Add Product
    </h1>
    <ol class="breadcrumb">
    <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="<?php echo e(url('admin/add-product')); ?>">Add Product</a></li>
    <li><a href="<?php echo e(url('admin/add-product')); ?>">Add Product</a></li>
    </ol>
    </section>
    
    <!-- Main content -->
    <section class="content">
    <div class="row">
    <!-- left column -->
    <div class="col-md-12">
    <!-- general form elements -->
    <div class="box box-primary">
    <div class="box-header with-border">
	
	<?php if(session('success')): ?>
	<div class="alert alert-success">
	<?php echo e(session('success')); ?>

	</div>
	<?php elseif(session('error')): ?>
	<div class="alert alert-danger">
	<?php echo e(session('error')); ?>

	</div>
	<?php endif; ?>
	
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="alert alert-danger">
	<?php echo e($error); ?>

	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <form role="form" method="POST" action ="<?php echo e(url('admin/add-product')); ?>" enctype="multipart/form-data">
    <div class="box-body">
	<?php echo e(csrf_field()); ?>


    <div class="form-group">
    <label for="exampleInputPassword1">Select Category</label>
    <select class="form-control" id="category" name="category" required>
    <option value = "">Select Category</option>    
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
    <option value = "<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    </div>    

	    
    <div class="form-group">
    <label for="exampleInputEmail1">Product Name</label>
    <input type="text" class="form-control"  id="exampleInputname" name="productname" placeholder="Enter Product Name" required>
    </div>
    
    <div class="form-group">
    <label for="exampleInputEmail1">Price</label>
    <input type="text" class="form-control"  id="exampleInputname" name="price" placeholder="Enter Price" required>
    </div>

    <div class="form-group">
    <label for="exampleInputEmail1">Old Price</label>
    <input type="text" class="form-control"  id="exampleInputname" name="oldprice" placeholder="Enter Old Price" required>
    </div>

    <div class="form-group">
    <label for="exampleInputPassword1">Stock</label>
    <select class="form-control" id="stock" name="stock" required>
    <option value = "1">In Stock</option>
    <option value = "0">Out Stock</option>
    </select>
    </div>    


    <div class="form-group">
    <label for="exampleInputEmail1">Color</label>
    <input type="text" class="form-control"  id="exampleInputname" name="color" placeholder="Enter Color" required>
    </div>

    <div class="form-group">
    <label for="exampleInputEmail1">Size</label>
    <input type="text" class="form-control"  id="exampleInputname" name="size" placeholder="Enter Size" required>
    </div>

    <div class="form-group">
    <label for="exampleInputEmail1">Quantity</label>
    <input type="text" class="form-control"  id="exampleInputname" name="quantity" placeholder="Enter Quantity" required>
    </div>

    <div class="form-group">
    <label for="exampleInputEmail1">Short Detail</label>
    <textarea class="textarea"   name="shortDetail" placeholder="Enter Short Detail"
    style="width: 100%; height: 108px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
    </div>

    <div class="form-group">
    <label for="exampleInputEmail1">Description</label>
    <textarea class="textarea"   name="description" placeholder="Enter Description"
    style="width: 100%; height: 108px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
    </div>

   <div class="form-group">
    <label for="exampleInputEmail1">Specification</label>
    <textarea class="textarea"   name="specification" placeholder="Enter Specification"
    style="width: 100%; height: 108px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
    </div>

    <div class="form-group">
    <label for="exampleInputEmail1">Main Image</label>
    <input type="file" class="form-control"  id="exampleInputname" name="mainImage" placeholder="Enter Image" required>
    </div>

   <div class="form-group">
   <label for="exampleInputEmail1">Other Image</label>
   <input type="file" class="form-control"  id="exampleInputname" name="otherImage" placeholder="Enter Other Image"required>
   </div>


    <!-- /.box-body -->
    
    <div class="box-footer">
    <button type="submit" class="btn btn-primary">Submit</button>
    </div>
    </form>
    </div>
    
    
    </div>
    
    </div>
    <!-- /.row -->
    </section>
    <!-- /.content -->
    </div>
    

    <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    
<?php /**PATH /opt/lampp/htdocs/gold/resources/views/admin/add-product.blade.php ENDPATH**/ ?>