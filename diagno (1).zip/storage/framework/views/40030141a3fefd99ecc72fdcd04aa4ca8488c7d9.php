<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
.steps {
    margin-top: -41px;
    display: inline-block;
    float: right;
    font-size: 16px
}
.step {
    float: left;
    background: white;
    padding: 7px 13px;
    border-radius: 1px;
    text-align: center;
    width: 100px;
    position: relative
}
.step_line {
    margin: 0;
    width: 0;
    height: 0;
    border-left: 16px solid #fff;
    border-top: 16px solid transparent;
    border-bottom: 16px solid transparent;
    z-index: 1008;
    position: absolute;
    left: 99px;
    top: 1px
}
.step_line.backline {
    border-left: 20px solid #f7f7f7;
    border-top: 20px solid transparent;
    border-bottom: 20px solid transparent;
    z-index: 1006;
    position: absolute;
    left: 99px;
    top: -3px
}
.step_complete {
    background: #357ebd
}
.step_complete a.check-bc, .step_complete a.check-bc:hover,.afix-1,.afix-1:hover{
    color: #eee;
}
.step_line.step_complete {
    background: 0;
    border-left: 16px solid #357ebd
}
.step_thankyou {
    float: left;
    background: white;
    padding: 7px 13px;
    border-radius: 1px;
    text-align: center;
    width: 100px;
}
.step.check_step {
    margin-left: 5px;
}
.ch_pp {
    text-decoration: underline;
}
.ch_pp.sip {
    margin-left: 10px;
}
.check-bc,
.check-bc:hover {
    color: #222;
}
.SuccessField {
    border-color: #458845 !important;
    -webkit-box-shadow: 0 0 7px #9acc9a !important;
    -moz-box-shadow: 0 0 7px #9acc9a !important;
    box-shadow: 0 0 7px #9acc9a !important;
    background: #f9f9f9 url(../images/valid.png) no-repeat 98% center !important
}

.btn-xs{
    line-height: 28px;
}

/*login form*/
.login-container{
    margin-top:30px ;
}
.login-container input[type=submit] {
  width: 100%;
  display: block;
  margin-bottom: 10px;
  position: relative;
}

.login-container input[type=text], input[type=password] {
  height: 44px;
  font-size: 16px;
  width: 100%;
  margin-bottom: 10px;
  -webkit-appearance: none;
  background: #fff;
  border: 1px solid #d9d9d9;
  border-top: 1px solid #c0c0c0;
  /* border-radius: 2px; */
  padding: 0 8px;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
}

.login-container input[type=text]:hover, input[type=password]:hover {
  border: 1px solid #b9b9b9;
  border-top: 1px solid #a0a0a0;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
}

.login-container-submit {
  /* border: 1px solid #3079ed; */
  border: 0px;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1); 
  background-color: #357ebd;/*#4d90fe;*/
  padding: 17px 0px;
  font-family: roboto;
  font-size: 14px;
  /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#4787ed)); */
}

.login-container-submit:hover {
  /* border: 1px solid #2f5bb7; */
  border: 0px;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #357ae8;
  /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#357ae8)); */
}

.login-help{
  font-size: 12px;
}

.asterix{
    background:#f9f9f9 url(../images/red_asterisk.png) no-repeat 98% center !important;
}

/* images*/
ol, ul {
  list-style: none;
}
.hand {
  cursor: pointer;
  cursor: pointer;
}
.cards{
    padding-left:0;
}
.cards li {
  -webkit-transition: all .2s;
  -moz-transition: all .2s;
  -ms-transition: all .2s;
  -o-transition: all .2s;
  transition: all .2s;
  background-image: url('//c2.staticflickr.com/4/3713/20116660060_f1e51a5248_m.jpg');
  background-position: 0 0;
  float: left;
  height: 32px;
  margin-right: 8px;
  text-indent: -9999px;
  width: 51px;
}
.cards .mastercard {
  background-position: -51px 0;
}
.cards li {
  -webkit-transition: all .2s;
  -moz-transition: all .2s;
  -ms-transition: all .2s;
  -o-transition: all .2s;
  transition: all .2s;
  background-image: url('//c2.staticflickr.com/4/3713/20116660060_f1e51a5248_m.jpg');
  background-position: 0 0;
  float: left;
  height: 32px;
  margin-right: 8px;
  text-indent: -9999px;
  width: 51px;
}
.cards .amex {
  background-position: -102px 0;
}
.cards li {
  -webkit-transition: all .2s;
  -moz-transition: all .2s;
  -ms-transition: all .2s;
  -o-transition: all .2s;
  transition: all .2s;
  background-image: url('//c2.staticflickr.com/4/3713/20116660060_f1e51a5248_m.jpg');
  background-position: 0 0;
  float: left;
  height: 32px;
  margin-right: 8px;
  text-indent: -9999px;
  width: 51px;
}
.cards li:last-child {
  margin-right: 0;
}
/* images end */




.panel-footer{
    background:#fff;
}
.btn{
    border-radius: 1px;
}
.btn-sm, .btn-group-sm > .btn{
    border-radius: 1px;
}
.input-sm, .form-horizontal .form-group-sm .form-control{
    border-radius: 1px;
}

.panel-info {
    border-color: #999;
}

.panel-heading {
    border-top-left-radius: 1px;
    border-top-right-radius: 1px;
}
.panel {
    border-radius: 1px;
}
.panel-info > .panel-heading {
    color: #eee;
    border-color: #999;
}
.panel-info > .panel-heading {
        background: #2f2f57;
}

hr {
    border-color: #999 -moz-use-text-color -moz-use-text-color;
}

.panel-footer {
    border-bottom-left-radius: 1px;
    border-bottom-right-radius: 1px;
    border-top: 1px solid #999;
}

.btn-link {
    color: #888;
}

hr{
    margin-bottom: 10px;
    margin-top: 10px;
}

/** MEDIA QUERIES **/
@media  only screen and (max-width: 989px){
    .span1{
        margin-bottom: 15px;
        clear:both;
    }
}

@media  only screen and (max-width: 764px){
    .inverse-1{
        float:right;
    }
}

@media  only screen and (max-width: 586px){
    .cart-titles{
        display:none;
    }
    .panel {
        margin-bottom: 1px;
    }
}

.form-control {
    border-radius: 1px;
}
.paytxt{
     margin-bottom:20px;
}
.paytxt a{
    font-weight:bold;
    text-decoration:none;
    color:#ef1eae;
   
}
.btnPlc a{
    padding:12px 65px;
    background: #2f2f57;
    text-decoration:none;
    color:#fff;
   
}
.plcbtn{
    padding:12px 24px;
    background: #ef1eae;
    text-decoration:none;
    color:#fff;
   
}
/*.panel-info{*/
      
/*    padding: 20px 16px;*/
/*}*/
.panel-body{
    box-shadow: 0 2px 20px 0 rgba(0,0,0,.1);
    background: #fff;
    padding: 20px 32px;
}
.r-info .panel-body{
    background: #d0f0ff;
        padding: 20px 20px;
}
.panel-body h4{
    color:#2f2f57;
}
</style>

<main id="main">
    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>How it Works?</h2>
          <ol>
            <li><a href="<?php echo e(route('/')); ?>">Home</a></li>
            <li>Checkout</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Section-2 ======= -->
    <section id="" class="works">
      <div class="container">

        <div class="section-title">
          <h2>Checkout</h2>
        </div>

       

        <div>
            <div class="container">
				<form class="checkout" name="checkout" action="<?php echo e(route('paymentnow')); ?>" method="POST" >
                <div class="row">
                    <div class="col-lg-8 col-md-8">
                         <div class="">
                            <!--SHIPPING METHOD-->
                            <div class="">
                                
                                <div class="panel-body">
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <h4>Shipping Address</h4>
                                            </div>
                                        </div>
										
										<?php if(session('success')): ?>
											<div class="alert alert-success">
											<?php echo e(session('success')); ?>

											</div>
										<?php elseif(session('error')): ?>
											<div class="alert alert-danger">
											<?php echo e(session('error')); ?>

											</div>
										<?php endif; ?>
										
										<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="alert alert-danger">
											<?php echo e($error); ?>

											</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
										
                                    </div>
                                    
                                    <div class="form-group">
										<?php echo e(csrf_field()); ?>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <strong>First Name:</strong>
                                                <input type="text" name="first_name" class="form-control" value="<?php echo e($detail->first_name); ?>" />
                                            </div>
                                            <!--<div class="span1"></div>-->
                                            <div class="col-md-6">
                                                <strong>Last Name:</strong>
                                                <input type="text" name="last_name" class="form-control" value="<?php echo e($detail->last_name); ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-md-12"><strong>Company Name:</strong></div>
                                            <div class="col-md-12">
                                                <input type="text" class="form-control" name="company" value="<?php echo e($detail->company); ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-md-12"><strong>Phone Number:</strong></div>
                                            <div class="col-md-12"><input type="text" name="phone_number" class="form-control" value="<?php echo e($detail->phone_number); ?>"  /></div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-md-12"><strong>Email Address:</strong></div>
                                            <div class="col-md-12"><input type="text" name="email_address" class="form-control" value="<?php echo e($detail->email); ?>"  /></div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-md-6"><strong>Street Address:</strong>
                                                <input type="text" name="address" class="form-control" value="<?php echo e($detail->address); ?>"  />
                                            </div>
                                            <div class="col-md-6"><strong>City:</strong>
                                                <input type="text" name="city" class="form-control" value="<?php echo e($detail->city); ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <div class="row">
											<div class="col-md-6"><strong>State:</strong>
												<input type="text" name="state" class="form-control"  value="<?php echo e($detail->state); ?>" />
											</div>
											<div class="col-md-6"><strong>Zip / Postal Code:</strong>
												<input type="text" name="zip_code" class="form-control" value="<?php echo e($detail->zip_code); ?>" />
											</div>
                                        </div>
                                    </div>
                                    
                                    
                                    <input type="checkbox" id="ac" name="create_account" value="yes">
                                    <label for="ac"> Create an account</label><br>

                                </div>
                            </div>
                            
                        </div>
                    </div>
                    
                    <div class="col-lg-4 col-md-4">
                         <div class="panel panel-info r-info">
                                <div class="panel-heading p-2 mb-2">
                                    Review Order 
                                </div>
                                <div class="panel-body">
                                    <div class="form-group">
                                        <div class="row">
                                            
                                            <div class="col-lg-8 col-md-8">
                                                <div class="">Package name</div>
                                            </div>
                                            <div class="col-lg-4 col-md-4 text-right">
                                                <h6><span><?php echo e($prices->plan); ?></span> </h6>
                                            </div>
                                        </div>
                                       
                                    </div>
                                    <div class="form-group"><hr /></div>
                                    
                                    
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <strong>Subtotal</strong>
                                                <div class="float-right"><span>₹<?php echo e($prices->price); ?></span><span>   </span></div>
                                            </div>
                                           
                                        </div>
                                        
                                    </div>
                                    <div class="form-group"><hr /></div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <strong>Order Total</strong>
                                                <div class="float-right"><span>₹<?php echo e($prices->price); ?></span><span>   </span></div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    
                                    <div class="paytxt">
                                        <input type="radio" id="op" name="payment" value="Online" checked >
                                          <label for="op">Online Payment</label><br>
                                        <input type="radio" id="cod" name="payment" value="Cash">
                                          <label for="cod">Cash on delivery</label><br>
                                       
                                    </div>
                                    
                                    <div class="btnPlc">
                                        <input type="hidden" name="price" value="<?php echo e($prices->price); ?>"  required >
                                        <input type="hidden" name="plan" value="<?php echo e($prices->plan); ?>" required >
                                        <input type="submit" name="placeorder" value="Place Order" class="alert alert-info" >
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
				</form>
            </div>
        </div>


      </div>
    </section>

   

  </main><!-- End #main -->


<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\socid\resources\views/front/checkout.blade.php ENDPATH**/ ?>