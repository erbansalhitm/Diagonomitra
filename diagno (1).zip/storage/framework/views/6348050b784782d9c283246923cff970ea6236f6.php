
 
  <?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!--  HOME SLIDER BLOCK  -->
    
<section class="footer-widget-area footer-widget-area-bg section-custom-bg" style="background:linear-gradient( rgba(17,17,17,0.9),  rgba(17,17,17,0.9) ), url(<?php echo e(asset('public/front/')); ?>/images/section_custom_bg.jpg&quot;); background-position: center center;  
background-repeat: no-repeat;  background-attachment: inherit; background-size: cover;  overflow: hidden; ">
<div class="container" >
<div class="row" style="margin-top:50px;margin-bottom:50px">
<h1 class="text-center" style="color:#fff" >About US</h1>
</div>
</div>
</section>
   
 

  <!--  ABOUT US -->

  <section class="section-content-block">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-sm-12 visible-lg visible-md">
          <img src="<?php echo e(asset('public/front/')); ?>/images/about_feat_bg_2.jpg" alt="feat image" />
        </div>

        <div class="col-md-6 col-sm-12 col-xs-12 " >
          <div class=" theme-custom-box-shadow" style="padding:30px">
            <p class="our-experience">
             About Us
              <br />
             Who We Are
              
            </p>

            We have been in the repair and service business since 1984. We
            have experienced service department ready to handle all of your
            repair tasks. Our team will get your device with guarantee. 
			Our team will get your device with guarantee.
			 We have been in the repair and service business since 1984. We
            have experienced service department ready to handle all of your
            repair tasks. Our team will get your device with guarantee. 
			Our team will get your device with guarantee.

            <p class="margin-top-24">

            </p>
          </div>
        </div>
        <!-- end .col-sm-12  -->
      </div>
    </div>
    <!--  end .container  -->
  </section>
  <!--  end .section-content-block -->

  

  

  <section class="section-content-block section-secondary-bg">
    <div class="container">
      <div class="row wow fadeInUp">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="appointment-form-wrapper light-layout margin-bottom-24 clearfix theme-custom-no-box-shadow">
            <div class="col-md-4 col-sm-12">
              <div class="appointment-form-heading text-left">
			  
                <h2 class="form-title text-capitalize margin-top-24">
                  GET A Query
                </h2>

                <p>
                  Please fill out the query form and very soon we will
                  contact with you to schedule .
                </p>
              </div>
            </div>

            <div class="col-md-8 col-sm-12">
              <form class="appoinment-form margin-top-42">
                <div class="form-group col-md-4">
                  <input id="your_name" class="form-control" placeholder="Name" type="text" required=""
                    data-msg="This field is required." />
                </div>
                <div class="form-group col-md-4">
                  <input id="your_email" class="form-control" placeholder="Email" type="email" required=""
                    data-msg="This field is required." />
                </div>
                <div class="form-group col-md-4">
                  <input id="your_phone" class="form-control" placeholder="Phone" type="text" required=""
                    data-msg="This field is required." />
                </div>

                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                  <textarea id="textarea_message" class="form-control" rows="3" placeholder="Your Message..."
                    required="" data-msg="This field is required."></textarea>
                </div>

                <div class="form-group col-md-12 col-sm-12 col-xs-12 text-left">
                  <button id="btn_submit" class="btn btn-theme btn-square wow zoomIn" type="submit">
                   Send
                  </button>
                </div>
              </form>
            </div>
          </div>
          <!-- end .appointment-form-wrapper  -->
        </div>
        <!--  end .col-lg-6 -->
      </div>
      <!--  end .row  -->
    </div>
    <!--  end .container -->
  </section>
  <!--  end .appointment-section  -->
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\dm\resources\views/front/about.blade.php ENDPATH**/ ?>