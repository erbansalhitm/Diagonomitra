<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<main id="main">
    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Pricing</h2>
          <ol>
            <li><a href="<?php echo e(route('/')); ?>">Home</a></li>
            <li>Pricing</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <section style="background:#f8f8fb">
      <div class="container">
        <div class="section-title">
          <h2>Our Pricing Plans</h2>
        </div>
        <div class="row">
		  <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
          <div class="col-lg-4 col-md-4" style="margin-bottom: 10px;">
            <div class="price-box1" >
              <h4 style=" font-weight: 600;" ><?php echo e($price->plan); ?> <p style="font-family: sans-serif">Rs. <?php echo e($price->price); ?>/m</p></h4>
              </div>
               <div class="price-box">
              <ul >
               <?php echo $price->shortDetail; ?>

                <div class="moreBtn btn-shadow" style="padding-left:60px">
            <a href="<?php echo e(route('pricing')); ?>">Order Now</a>
          </div>
              </ul>
              
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </div>
      </div>
    </section>

   
   

  </main><!-- End #main -->

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\socid\resources\views/front/pricing.blade.php ENDPATH**/ ?>