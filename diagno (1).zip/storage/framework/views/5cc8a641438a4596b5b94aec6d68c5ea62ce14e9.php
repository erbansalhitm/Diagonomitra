<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!--Main Slider-->
    <section class="main-slider">
        
        <div class="tp-banner-container">
            <div style="width:80%;float:left;">
            <div class="tp-banner" style="max-height: 445px !important;">
                <ul>
                    
                    <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="<?php echo e(asset('public/front/images/main-slider/image-1.jpg')); ?>"   data-saveperformance="off"  data-title="Awesome Title Here">
                    <img src="<?php echo e(asset('public/front/images/main-slider/image-1.jpg')); ?>" style="height:70%;" alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat" style="height:70%;"> 
                    
                    <div class="tp-caption sfl sfb tp-resizeme"
                    data-x="left" data-hoffset="15"
                    data-y="center" data-voffset="-50"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><h2>THEY ARE <span class="theme_color">HUMANS</span> <br>AS WELL</h2></div>
                    
                    <div class="tp-caption sfr sfb tp-resizeme"
                    data-x="left" data-hoffset="15"
                    data-y="center" data-voffset="40"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><div class="text">Make a better world for humans as Authism</div></div>
                    
                    <div class="tp-caption sfl sfb tp-resizeme"
                    data-x="left" data-hoffset="15"
                    data-y="center" data-voffset="100"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><a href="#" class="theme-btn btn-style-one">DONATE NOW</a></div>
                    
                    <div class="tp-caption sfb sfb tp-resizeme"
                    data-x="right" data-hoffset="-15"
                    data-y="center" data-voffset="0"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><figure class="content-image"><img src="<?php echo e(asset('public/front/images/main-slider/content-image-1.png')); ?>" style="height:70%;" alt=""></figure></div>
                    
                    
                    </li>
                    
                    <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="<?php echo e(asset('public/front/images/main-slider/image-2.jpg')); ?>"  data-saveperformance="off"  data-title="Awesome Title Here">
                    <img src="<?php echo e(asset('public/front/images/main-slider/image-2.jpg')); ?>" style="height:70%;" alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat"> 
                    
                    <div class="tp-caption sfl sfb tp-resizeme"
                    data-x="left" data-hoffset="600"
                    data-y="center" data-voffset="-60"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><h2><span class="theme_color">HUNGRY</span> CHILDRENS!</h2></div>
                    
                    <div class="tp-caption sfr sfb tp-resizeme"
                    data-x="left" data-hoffset="600"
                    data-y="center" data-voffset="20"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><div class="text">About 200 million children between the ages of 5 and 17 <br>are longing for food</div></div>
                    
                    <div class="tp-caption sfl sfb tp-resizeme"
                    data-x="left" data-hoffset="600"
                    data-y="center" data-voffset="100"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><a href="#" class="theme-btn btn-style-two"><span class="fa fa-heart"></span> &ensp; DONATE NOW</a></div>
                    
                    
                    </li>
                    
                    <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="<?php echo e(asset('public/front/images/main-slider/image-1.jpg')); ?>"  data-saveperformance="off"  data-title="Awesome Title Here">
                    <img src="<?php echo e(asset('public/front/images/main-slider/image-1.jpg')); ?>" style="height:70%;" alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat"> 
                    
                    <div class="tp-caption sft sfb tp-resizeme"
                    data-x="center" data-hoffset="0"
                    data-y="center" data-voffset="-50"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><h2 class="text-center">THEY ARE <span class="theme_color">HUMANS</span> <br>AS WELL</h2></div>
                    
                    <div class="tp-caption sfb sfb tp-resizeme"
                    data-x="center" data-hoffset="0"
                    data-y="center" data-voffset="40"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><div class="text text-center">Make a better world for humans as Authism</div></div>
                    
                    <div class="tp-caption sfb sfb tp-resizeme"
                    data-x="center" data-hoffset="0"
                    data-y="center" data-voffset="110"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><a href="#" class="theme-btn btn-style-one">DONATE NOW</a></div>
                    
                    
                    </li>
                    
                </ul>
                
                <div class="tp-bannertimer"></div>
            </div>
            </div>
            <div style="width:20%;float:right;">
                <marquee style="font-family: Book Antiqua; color: #FFFFFF;height: 600px;background: #fff;" bgcolor="#000080" direction="up" height="80"  >
                    <img src="<?php echo e(asset('public/front/images/image/1.jpeg')); ?>" style="height:205px;" class="img-thumbnail"><br>
                    <img src="<?php echo e(asset('public/front/images/image/1.jpeg')); ?>" style="height:205px;" class="img-thumbnail">
                    <img src="<?php echo e(asset('public/front/images/image/1.jpeg')); ?>" style="height:205px;" class="img-thumbnail">
                    <img src="<?php echo e(asset('public/front/images/image/1.jpeg')); ?>" style="height:205px;" class="img-thumbnail">
                </marquee>
            </div>
        </div>
    </section>
    <section style="padding-top:611px;">
    <div class="onoffswitch3">
    <input type="checkbox" name="onoffswitch3" class="onoffswitch3-checkbox" id="myonoffswitch3" checked>
    <label class="onoffswitch3-label" for="myonoffswitch3">
        <span class="onoffswitch3-inner">
            <span class="onoffswitch3-active">
                <marquee class="scroll-text">Avengers: Infinity War's Iron Spider Suit May Use Bleeding Edge Tech  <span class="glyphicon glyphicon-forward"></span> Russo brothers ask for fans not to spoil Avengers: Infinity War <span class="glyphicon glyphicon-forward"></span>  Bucky's Arm Miraculously Regenerates On Avengers: Infinity War Poster</marquee>
                <span class="onoffswitch3-switch">BREAKING NEWS</span>
            </span>
            <span class="onoffswitch3-inactive"><span class="onoffswitch3-switch">SHOW BREAKING NEWS</span></span>
        </span>
    </label>
</div>
  </section>  
    <!--Who We Are-->
    <section class="about-us-section">
        <div class="auto-container">
            
            <!--Section Title-->
            <div class="sec-title centered">
                <h2>About Us</h2>
                <div class="separator"></div>
                <!--<div class="desc-text">Bushwick viral skateboard cold-pressed godard. Cliche narwhal austin, godard stumptown butcher pour-over umami offal art party kitsch flexitarian artisan chia. Sartorial narwhal ethical listicle meggings cardigan four dollar toast. </div>-->
            </div>
            <!--Content Box-->
            <div class="content-box">
                <div class="row clearfix">
                    <!--Content Column-->
                    <div class="content-column col-lg-7 col-md-6 col-sm-12 col-xs-12">
                        <div class="inner-box">
                            <div class="text-content">
                                <p>We are a Nonpolitical, Community Service Association which has come into existence with the support of approximately 250+ families residing in Sector-31 Faridabad, Which is an independent Association with no linkages with the Resident Welfare Associations of the Sector.</p>
                                <p>The key objectives for incorporating this Association are To arrange and organize various kinds of Welfare programs e.g. Vocational Education, Job fairs, Personality development programs, Social activities for Senior citizens, Women, Children, Cultural Events etc for the community. Promote literacy, cultural and other social activities of Awareness Programs including Adult Education Classes.To arrange and organize Bhagwati Jagran, Chowki, Festivals like Vaisakhi, Lohri etc., Bh…</p>
                            </div>
                            <div class="links" style="padding-top: 25px;"> <a href="about.php" class="theme-btn btn-style-four">READ MORE</a></div>
                        </div>
                    </div>
                    
                    <!--Image Column-->
                    <div class="image-column col-lg-5 col-md-6 col-sm-12 col-xs-12">
                        <figure class="image wow fadeInRight" data-wow-duration="1500ms" data-wow-delay="0ms"><img src="<?php echo e(asset('public/front/images/about.jpeg')); ?>" style="height: 280px;" alt=""></figure>
                    </div>
                    
                </div>
            </div>
            
            <div class="row clearfix">
                
                <!--Default Icon Column-->
                <div class="default-icon-column col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="icon-box"><span class="flaticon-target"></span></div>
                        <h3>Our Mission</h3>
                        <div class="separator"></div>
                        <div>Bushwick viral skateboard cold-pressed godard. Cliche narwhal austin, godard stumptown butcher pour-over umami offal art party kitsch. </div>
                    </div>
                </div>
                
                <!--Default Icon Column-->
                <div class="default-icon-column col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="icon-box"><span class="flaticon-binoculars"></span></div>
                        <h3>Our Vision</h3>
                        <div class="separator"></div>
                        <div>Bushwick viral skateboard cold-pressed godard. Cliche narwhal austin, godard stumptown butcher pour-over umami offal art party kitsch. </div>
                    </div>
                </div>
                
                <!--Default Icon Column-->
                <div class="default-icon-column col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="icon-box"><span class="flaticon-envelope"></span></div>
                        <h3>Our Message</h3>
                        <div class="separator"></div>
                        <div>Bushwick viral skateboard cold-pressed godard. Cliche narwhal austin, godard stumptown butcher pour-over umami offal art party kitsch. </div>
                    </div>
                </div>
                
            </div>
            
        </div>
    </section>
    
    
    <!--Recent Causes Section-->
    <div class="container">
        <div class="sec-title centered">
                <h2>OUR ACTIVITIES</h2>
                <div class="separator"></div>
                
            </div>
   <div class="row">
      <div id="adv_team_4_columns_carousel" class="carousel slide four_shows_one_move team_columns_carousel_wrapper" data-ride="carousel" data-interval="2000" data-pause="hover">
         <!--========= Wrapper for slides =========-->
         <div class="carousel-inner" role="listbox">
            <!--========= 1st slide =========-->
            <div class="item">
               <div class="col-sm-3" >
                        <div class="item" >
                            <a href="7.php"><img src="<?php echo e(asset('public/front/images/image/1.jpeg')); ?>" style="height:205px;" class="img-thumbnail"></a>
                            <h5 style="text-align:center;padding: 10px;">Events-Mata ki chowki</h5>
                        </div>
                        
                    </div>
                    <div class="col-sm-3" >
                        <div class="item">
                            <a href="8.php"><img src="<?php echo e(asset('public/front/images/image/2.jpeg')); ?>" style="height:205px;" class="img-thumbnail"></a>
                            <h5 style="text-align:center;padding: 10px;">Events-Baishakhi pics below</h5>
                        </div>
                    </div>
                    <div class="col-sm-3" >
                        <div class="item" >
                            <a href="9.php"><img src="<?php echo e(asset('public/front/images/image/4.jpeg')); ?>" style="height:205px;" class="img-thumbnail"></a>
                            <h5 style="text-align:center;padding: 10px;">Community Meetings</h5>
                        </div>
                    </div>
                    <div class="col-sm-3" >
                        <div class="item" >
                            <a href="10.php"><img src="<?php echo e(asset('public/front/images/image/3.jpeg')); ?>" style="height:205px;" class="img-thumbnail"></a>
                            <h5 style="text-align:center;padding: 10px;">New years eve celebrations</h5>
                        </div>
                    </div>
            </div>
            <!--========= 2nd slide =========-->
            <div class="item active">
               <div class="col-sm-3" >
                        <div class="item" >
                            <a href="7.php"><img src="<?php echo e(asset('public/front/images/image/1.jpeg')); ?>" style="height:205px;" class="img-thumbnail"></a>
                            <h5 style="text-align:center;padding: 10px;">Events-Mata ki chowki</h5>
                        </div>
                        
                    </div>
                    <div class="col-sm-3" >
                        <div class="item" >
                            <a href="8.php"><img src="<?php echo e(asset('public/front/images/image/2.jpeg')); ?>" style="height:205px;" class="img-thumbnail"></a>
                            <h5 style="text-align:center;padding: 10px;">Events-Baishakhi pics below</h5>
                        </div>
                    </div>
                    <div class="col-sm-3" >
                        <div class="item" >
                            <a href="9.php"><img src="<?php echo e(asset('public/front/images/image/4.jpeg')); ?>" style="height:205px;" class="img-thumbnail"></a>
                            <h5 style="text-align:center;padding: 10px;">Community Meetings</h5>
                        </div>
                    </div>
                    <div class="col-sm-3" >
                        <div class="item" >
                            <a href="10.php"><img src="<?php echo e(asset('public/front/images/image/3.jpeg')); ?>" style="height:205px;" class="img-thumbnail"></a>
                            <h5 style="text-align:center;padding: 10px;">New years eve celebrations</h5>
                        </div>
                    </div>
            </div>
            
         </div>
         <!--======= Navigation Buttons =========-->
         <!--======= Left Button =========-->
         
      </div>
   </div>
</div>
    
    
    <!--How To Contribute Section-->
    
   <!--- 
    
   
    <section class="call-to-action" style="background-image:url(images/background/image-1.jpg);">
        <div class="auto-container">
            
            <div class="sec-title centered">
                <h2>What People Are Saying</h2>
                <div class="separator"></div>
                
            </div>
            
            <div class="links"><a href="login.php" class="theme-btn btn-style-two">Login</a></div>
        </div>
    </section>
    
    
    
    
    
    ---->
    
    <!--News Section-->
    <section class="news-section">
        <div class="auto-container">
            <!--Section Title-->
            <div class="sec-title centered">
                <h2>OUR BLOG</h2>
                <div class="separator"></div>
                
            </div>
            
            <div class="">
                <div class="container">
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div id="news-slider2" class="owl-carousel">
                                <div class="post-slide2">
                                    <div class="post-img">
                                        <a href="#"><img src="<?php echo e(asset('public/front/images/blog/blog1.jpg')); ?>" alt=""></a>
                                    </div>
                                    <div class="post-content">
                                        <h3 class="post-title"><a href="#">Latest News Post</a></h3>
                                        <p class="post-description">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec elementum mauris. Praesent vehicula gravida dolor, ac efficitur sem sagittis.
                                        </p>
                                        
                                        <a href="#" class="theme-btn btn-style-three">read more</a>
                                    </div>
                                </div>
             
                                <div class="post-slide2">
                                    <div class="post-img">
                                        <a href="#"><img src="<?php echo e(asset('public/front/images/blog/blog2.jpg')); ?>" alt=""></a>
                                    </div>
                                    <div class="post-content">
                                        <h3 class="post-title"><a href="#">Latest News Post</a></h3>
                                        <p class="post-description">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec elementum mauris. Praesent vehicula gravida dolor, ac efficitur sem sagittis.
                                        </p>
                                        
                                        <a href="#" class="theme-btn btn-style-three">read more</a>
                                    </div>
                                </div>
                                
                                <div class="post-slide2">
                                    <div class="post-img">
                                        <a href="#"><img src="<?php echo e(asset('public/front/images/blog/blog3.jpg')); ?>" alt=""></a>
                                    </div>
                                    <div class="post-content">
                                        <h3 class="post-title"><a href="#">Latest News Post</a></h3>
                                        <p class="post-description">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec elementum mauris. Praesent vehicula gravida dolor, ac efficitur sem sagittis.
                                        </p>
                                        
                                        <a href="#" class="theme-btn btn-style-three">read more</a>
                                    </div>
                                </div>
                                
                                <div class="post-slide2">
                                    <div class="post-img">
                                        <a href="#"><img src="<?php echo e(asset('public/front/images/blog/blog5.jpg')); ?>" alt=""></a>
                                    </div>
                                    <div class="post-content">
                                        <h3 class="post-title"><a href="#">Latest News Post</a></h3>
                                        <p class="post-description">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec elementum mauris. Praesent vehicula gravida dolor, ac efficitur sem sagittis.
                                        </p>
                                        
                                        <a href="#" class="theme-btn btn-style-three">read more</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section  class="testimonial">
 <div class="container-fluid">
     <div class="sec-title centered" style="margin-bottom:0px;">
                <h2>Videos</h2>
                <div class="separator"></div>
                
            </div>
 <div class="row">
 
 
 

 
 
  <div class="container">
  
  <div class="row">
    <div class="col-md-12">
      
        
  
  <div class="row">
    <div class="col-md-12">
      <div class="carousel slide media-carousel" id="abc">
        <div class="carousel-inner">
        
        <!-- /.slide 1 -->
          <div class="item  active">  
          <div class="col-md-4 col-sm-12 col-xs-12" >
         
              <div class="panel panel-default"  style="box-shadow: -1px 2px 4px 4px grey;">
            <div class="panel-body">
            <div class="embed-responsive embed-responsive-16by9">
  <iframe width="560" height="315" src="https://www.youtube.com/embed/-wE1PF6aYbE" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe>
            </div>
         
          </div>
          
            
            </div>
            
         
          </div>
            <div class="col-md-4 col-sm-12 col-xs-12" >
         
                 <div class="panel panel-default"  style="box-shadow: -1px 2px 4px 4px grey;">
            <div class="panel-body">
            <div class="embed-responsive embed-responsive-16by9">
 <iframe width="560" height="315" src="https://www.youtube.com/embed/26bN6AUIfNA" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe>
            </div>
         
          </div>
          
           
            </div>
         
          </div>
          <div class="col-md-4 col-sm-12 col-xs-12">
         
                 <div class="panel panel-default"  style="box-shadow: -1px 2px 4px 4px grey;">
            <div class="panel-body">
            <div class="embed-responsive embed-responsive-16by9">
 <iframe width="560" height="315" src="https://www.youtube.com/embed/26bN6AUIfNA" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe>
            </div>
         
          </div>
          
           
            </div>
         
          </div>
        </div>
          
          
           <!-- /.slide 2 -->
         
          
        </div>
        
      </div>
    </div>
  </div>   
      
      
                                
    </div><!-- /.col-12  end -->
  </div>  <!-- /.ROW end -->
</div>  <!-- /.container end -->
 
 

 
 
 </div><!-- /. row end -->
 </div><!-- /.container fluid end -->
 
 </section>
    <div class="container">
    <div class="row">
        <div class="col-sm-12" style="text-align:center;">
            <div class="sec-title centered" style="margin-bottom:0px;">
                <h2>Testimonials</h2>
                <div class="separator"></div>
           </div>
        </div>
        <div class="col-sm-6">
        
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
              <!-- Wrapper for slides -->
              <div class="carousel-inner">
                <div class="item active">
                  <div class="row" style="padding: 20px">
                    <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                    <p class="testimonial_para">Lorem Ipsum ist ein einfacher Demo-Text für die Print- und Schriftindustrie. Lorem Ipsum ist in der Industrie bereits der Standard Demo-Text "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo en.</p><br>
                    <div class="row">
                    <div class="col-sm-2">
                        <img src="http://demos1.showcasedemos.in/jntuicem2017/html/v1/assets/images/jack.jpg" class="img-responsive" style="width: 80px">
                        </div>
                        <div class="col-sm-10">
                        <h4><strong>Jack Andreson</strong></h4>
                        <p class="testimonial_subtitle"><span>Chlinical Chemistry Technologist</span><br>
                        <span>Officeal All Star Cafe</span>
                        </p>
                    </div>
                    </div>
                  </div>
                </div>
               <div class="item">
                   <div class="row" style="padding: 20px">
                    <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                    <p class="testimonial_para">Lorem Ipsum ist ein einfacher Demo-Text für die Print- und Schriftindustrie. Lorem Ipsum ist in der Industrie bereits der Standard Demo-Text "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo en.</p><br>
                    <div class="row">
                    <div class="col-sm-2">
                        <img src="http://demos1.showcasedemos.in/jntuicem2017/html/v1/assets/images/kiara.jpg" class="img-responsive" style="width: 80px">
                        </div>
                        <div class="col-sm-10">
                        <h4><strong>Kiara Andreson</strong></h4>
                        <p class="testimonial_subtitle"><span>Chlinical Chemistry Technologist</span><br>
                        <span>Officeal All Star Cafe</span>
                        </p>
                    </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <div class="col-sm-6">
        
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
              <!-- Wrapper for slides -->
              <div class="carousel-inner">
                <div class="item active">
                  <div class="row" style="padding: 20px">
                    <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                    <p class="testimonial_para">Lorem Ipsum ist ein einfacher Demo-Text für die Print- und Schriftindustrie. Lorem Ipsum ist in der Industrie bereits der Standard Demo-Text "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo en.</p><br>
                    <div class="row">
                    <div class="col-sm-2">
                        <img src="http://demos1.showcasedemos.in/jntuicem2017/html/v1/assets/images/jack.jpg" class="img-responsive" style="width: 80px">
                        </div>
                        <div class="col-sm-10">
                        <h4><strong>Jack Andreson</strong></h4>
                        <p class="testimonial_subtitle"><span>Chlinical Chemistry Technologist</span><br>
                        <span>Officeal All Star Cafe</span>
                        </p>
                    </div>
                    </div>
                  </div>
                </div>
               <div class="item">
                   <div class="row" style="padding: 20px">
                    <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                    <p class="testimonial_para">Lorem Ipsum ist ein einfacher Demo-Text für die Print- und Schriftindustrie. Lorem Ipsum ist in der Industrie bereits der Standard Demo-Text "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo en.</p><br>
                    <div class="row">
                    <div class="col-sm-2">
                        <img src="http://demos1.showcasedemos.in/jntuicem2017/html/v1/assets/images/kiara.jpg" class="img-responsive" style="width: 80px">
                        </div>
                        <div class="col-sm-10">
                        <h4><strong>Kiara Andreson</strong></h4>
                        <p class="testimonial_subtitle"><span>Chlinical Chemistry Technologist</span><br>
                        <span>Officeal All Star Cafe</span>
                        </p>
                    </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <div class="col-sm-12">
            <div class="controls testimonial_control pull-right">
                <a class="left fa fa-chevron-left btn btn-default testimonial_btn" href="#carousel-example-generic"
                  data-slide="prev"></a>

                <a class="right fa fa-chevron-right btn btn-default testimonial_btn" href="#carousel-example-generic"
                  data-slide="next"></a>
              </div>
        </div>
    </div>
</div>
    
    <!--Sponsors Section-->
    <section class="sponsors-section" >
        <div class="auto-container">
            <!--Section Title-->
            <div class="sec-title centered">
                <h2 style="color:#000;">OUR SPONSORS</h2>
                <div class="separator"></div>
            </div>
            
            <div class="sponsors-outer">
                <!--Sponsors Carousel-->
                <ul class="sponsors-carousel">
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/logo.png')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/logo.png')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/logo.png')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/logo.png')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/logo.png')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/logo.png')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/logo.png')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/logo.png')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/logo.png')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/logo.png')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/logo.png')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/logo.png')); ?>" alt=""></a></figure></li>
                </ul>
            </div>
            
        </div>
    </section>
    
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/welfare/resources/views/front/index.blade.php ENDPATH**/ ?>