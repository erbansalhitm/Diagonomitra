
<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!--Main Slider-->
    <?php if($sliders): ?>
    <section class="main-slider">
        <div class="tp-banner-container">
            <div style="width:80%;float:left;">
            <div class="tp-banner" style="max-height: 445px !important;">
                <ul>
                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="<?php echo e(asset('public/front/slider/').'/'.$slider->sliderImage); ?>"   data-saveperformance="off"  data-title="Awesome Title Here">
                    <img src="<?php echo e(asset('public/front/slider/').'/'.$slider->sliderImage); ?>" style="height:70%;" alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat" style="height:70%;"> 
                    
                    <div class="tp-caption sfl sfb tp-resizeme"
                    data-x="left" data-hoffset="15"
                    data-y="center" data-voffset="-50"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><h2>THEY ARE <span class="theme_color">HUMANS</span> <br>AS WELL</h2></div>
                    
                    <div class="tp-caption sfr sfb tp-resizeme"
                    data-x="left" data-hoffset="15"
                    data-y="center" data-voffset="40"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><div class="text">Make a better world for humans as Authism</div></div>
                    
                    <div class="tp-caption sfl sfb tp-resizeme"
                    data-x="left" data-hoffset="15"
                    data-y="center" data-voffset="100"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><a href="#" class="theme-btn btn-style-one">DONATE NOW</a></div>
                    
                    <div class="tp-caption sfb sfb tp-resizeme"
                    data-x="right" data-hoffset="-15"
                    data-y="center" data-voffset="0"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><figure class="content-image"><img src="<?php echo e(asset('public/front/images/main-slider/content-image-1.png')); ?>" style="height:70%;" alt=""></figure></div>
                    
                    
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                    
                    
                </ul>
                
                <div class="tp-bannertimer"></div>
            </div>
            </div>
            <div style="width:20%;float:right;">
                <marquee style="font-family: Book Antiqua; color: #FFFFFF;height: 600px;background: #fff;" bgcolor="#000080" direction="up" height="80"  >
                    <img src="<?php echo e(asset('public/front/images/image/1.jpeg')); ?>" style="height:205px;" class="img-thumbnail"><br>
                    <img src="<?php echo e(asset('public/front/images/image/1.jpeg')); ?>" style="height:205px;" class="img-thumbnail">
                    <img src="<?php echo e(asset('public/front/images/image/1.jpeg')); ?>" style="height:205px;" class="img-thumbnail">
                    <img src="<?php echo e(asset('public/front/images/image/1.jpeg')); ?>" style="height:205px;" class="img-thumbnail">
                </marquee>
            </div>
        </div>
        
    </section>
    <?php endif; ?>
    <section style="padding-top:611px;">
    <div class="onoffswitch3">
    <input type="checkbox" name="onoffswitch3" class="onoffswitch3-checkbox" id="myonoffswitch3" checked>
    <label class="onoffswitch3-label" for="myonoffswitch3">
        <span class="onoffswitch3-inner">
            <span class="onoffswitch3-active">
                <marquee class="scroll-text">Avengers: Infinity War's Iron Spider Suit May Use Bleeding Edge Tech  <span class="glyphicon glyphicon-forward"></span> Russo brothers ask for fans not to spoil Avengers: Infinity War <span class="glyphicon glyphicon-forward"></span>  Bucky's Arm Miraculously Regenerates On Avengers: Infinity War Poster</marquee>
                <span class="onoffswitch3-switch">BREAKING NEWS</span>
            </span>
            <span class="onoffswitch3-inactive"><span class="onoffswitch3-switch">SHOW BREAKING NEWS</span></span>
        </span>
    </label>
</div>
  </section>  
    <!--Who We Are-->
    <?php if($aboutus): ?>
    <section class="about-us-section">
        <div class="auto-container">
            
            <!--Section Title-->
            <div class="sec-title centered">
                <h2>About Us</h2>
                <div class="separator"></div>
                
            </div>
            <!--Content Box-->
            <div class="content-box">
                <div class="row clearfix">
                    <!--Content Column-->
                    <div class="content-column col-lg-7 col-md-6 col-sm-12 col-xs-12">
                        <div class="inner-box">
                            <div class="text-content">
                                <?php echo e(strip_tags($aboutus->content)); ?>

                            </div>
                            <div class="links" style="padding-top: 25px;"> <a href="<?php echo e(url('aboutus')); ?>" class="theme-btn btn-style-four">READ MORE</a></div>
                        </div>
                    </div>
                    
                    <!--Image Column-->
                    <div class="image-column col-lg-5 col-md-6 col-sm-12 col-xs-12">
                        <figure class="image wow fadeInRight" data-wow-duration="1500ms" data-wow-delay="0ms"><img src="<?php echo e(asset('public/front/about').'/'.$aboutus->image); ?>" style="height: 280px;" alt=""></figure>
                    </div>
                    
                </div>
            </div>
            
            <div class="row clearfix">
                
                <!--Default Icon Column-->
                <div class="default-icon-column col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="icon-box"><span class="flaticon-target"></span></div>
                        <h3>Our Mission</h3>
                        <div class="separator"></div>
                        <div><?php echo e(strip_tags($aboutus->widget1)); ?> </div>
                    </div>
                </div>
                
                <!--Default Icon Column-->
                <div class="default-icon-column col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="icon-box"><span class="flaticon-binoculars"></span></div>
                        <h3>Our Vision</h3>
                        <div class="separator"></div>
                        <div><?php echo e(strip_tags($aboutus->widget2)); ?> </div>
                    </div>
                </div>
                
                <!--Default Icon Column-->
                <div class="default-icon-column col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="icon-box"><span class="flaticon-envelope"></span></div>
                        <h3>Our Message</h3>
                        <div class="separator"></div>
                        <div><?php echo e(strip_tags($aboutus->widget3)); ?> </div>
                    </div>
                </div>
                
            </div>
            
        </div>
    </section>
    <?php endif; ?>
    
    <!--Recent Causes Section-->
    <?php if($activities): ?>
    <div class="container">
        <div class="sec-title centered">
                <h2>OUR ACTIVITIES</h2>
                <div class="separator"></div>
                
            </div>
   <div class="row">
      <div id="adv_team_4_columns_carousel" class="carousel slide four_shows_one_move team_columns_carousel_wrapper" data-ride="carousel" data-interval="2000" data-pause="hover">
         <!--========= Wrapper for slides =========-->
         <div class="carousel-inner" role="listbox">
            <!--========= 1st slide =========-->
            <div class="item active">
                    <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activitie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-3" >
                        
                        <div class="item" >
                            <a href="<?php echo e(route('activitie.all',$activitie->id)); ?>"><img src="<?php echo e(asset('public/front/activities/').'/'.$activitie->image); ?>" style="height:205px;" class="img-thumbnail"></a>
                            <h5 style="text-align:center;padding: 10px;"><?php echo e($activitie->title); ?></h5>
                        </div>
                        
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
             <div class="item">
                    <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activitie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-3" >
                        
                        <div class="item" >
                            <a href="<?php echo e(route('activitie.all',$activitie->id)); ?>"><img src="<?php echo e(asset('public/front/activities/').'/'.$activitie->image); ?>" style="height:205px;" class="img-thumbnail"></a>
                            <h5 style="text-align:center;padding: 10px;"><?php echo e($activitie->title); ?></h5>
                        </div>
                        
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            
            
         </div>
         <!--======= Navigation Buttons =========-->
         <!--======= Left Button =========-->
         
      </div>
   </div>
</div>
<?php endif; ?>    
    

    
    <!--News Section-->
    <?php if($blogs): ?>
    <section class="news-section">
        <div class="auto-container">
            <!--Section Title-->
            <div class="sec-title centered">
                <h2>OUR BLOG</h2>
                <div class="separator"></div>
                
            </div>
            
            <div class="">
                <div class="container">
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div id="news-slider2" class="owl-carousel">
                                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="post-slide2">
                                    <div class="post-img">
                                        <a href="#"><img src="<?php echo e(asset('public/front/blog').'/'.$blog->image); ?>" alt=""></a>
                                    </div>
                                    <div class="post-content">
                                        <h3 class="post-title"><a href="javascript:void(0)"><?php echo e($blog->title); ?></a></h3>
                                        <p class="post-description">
                                            <?php echo e(strip_tags($blog->content)); ?>

                                        </p>
                                        
                                        <a href="javascript:void(0)" class="theme-btn btn-style-three">read more</a>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
    
    <?php if($videos): ?>
    <section  class="testimonial">
        <div class="container-fluid">
            <div class="sec-title centered" style="margin-bottom:0px;">
                <h2>Videos</h2>
                <div class="separator"></div>
                
            </div>
        <div class="row">
 
  <div class="container">
  
  <div class="row">
    <div class="col-md-12">
      
        
  
  <div class="row">
    <div class="col-md-12">
      <div class="carousel slide media-carousel" id="abc">
        <div class="carousel-inner">
        
        <!-- /.slide 1 -->
          <div class="item  active">
            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
            <div class="col-md-4 col-sm-12 col-xs-12" >
         
              <div class="panel panel-default"  style="box-shadow: -1px 2px 4px 4px grey;">
                <div class="panel-body">
                <div class="embed-responsive embed-responsive-16by9">
                <?php echo $video->url; ?>

                </div>
         
            </div>
          
            
            </div>
            
         
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
          
        </div>
          
          
           <!-- /.slide 2 -->
         
          
        </div>
        
      </div>
    </div>
  </div>   
      
      
                                
    </div><!-- /.col-12  end -->
  </div>  <!-- /.ROW end -->
</div>  <!-- /.container end -->
 
 

 
 
 </div><!-- /. row end -->
 </div><!-- /.container fluid end -->
 
 </section>
 <?php endif; ?>
    <div class="container">
    <?php if($testimonials): ?>    
    <div class="row">
        <div class="col-sm-12" style="text-align:center;">
            <div class="sec-title centered" style="margin-bottom:0px;">
                <h2>Testimonials</h2>
                <div class="separator"></div>
           </div>
        </div>
        <div class="col-sm-6">
        
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
              <!-- Wrapper for slides -->
              <div class="carousel-inner">
                <div class="item active">
                  <div class="row" style="padding: 20px">
                    <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                    <p class="testimonial_para"><?php echo e(strip_tags($testimonials[0]->content)); ?></p><br>
                    <div class="row">
                    <div class="col-sm-2">
                        <img src="<?php echo e(asset('public/front/testimonial').'/'.$testimonials[0]->image); ?>" class="img-responsive" style="width: 80px">
                        </div>
                        <div class="col-sm-10">
                        <h4><strong><?php echo e($testimonials[0]->name); ?></strong></h4>
                        <p class="testimonial_subtitle"><span><?php echo e($testimonials[0]->designation); ?></span><br>
                        </p>
                    </div>
                    </div>
                  </div>
                </div>
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                <div class="item">
                  <div class="row" style="padding: 20px">
                    <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                    <p class="testimonial_para"><?php echo e(strip_tags($testimonial->content)); ?></p><br>
                    <div class="row">
                    <div class="col-sm-2">
                        <img src="<?php echo e(asset('public/front/testimonial').'/'.$testimonial->image); ?>" class="img-responsive" style="width: 80px">
                        </div>
                        <div class="col-sm-10">
                        <h4><strong><?php echo e($testimonial->name); ?></strong></h4>
                        <p class="testimonial_subtitle"><span><?php echo e($testimonial->designation); ?></span><br>
                        </p>
                    </div>
                    </div>
                  </div>
                </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
        </div>
        <div class="col-sm-6">
        
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
              <!-- Wrapper for slides -->
              <div class="carousel-inner">
                <div class="item active">
                  <div class="row" style="padding: 20px">
                    <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                    <p class="testimonial_para"><?php echo e(strip_tags($testimonials[0]->content)); ?></p><br>
                    <div class="row">
                    <div class="col-sm-2">
                        <img src="<?php echo e(asset('public/front/testimonial').'/'.$testimonials[0]->image); ?>" class="img-responsive" style="width: 80px">
                        </div>
                        <div class="col-sm-10">
                        <h4><strong><?php echo e($testimonials[0]->name); ?></strong></h4>
                        <p class="testimonial_subtitle"><span><?php echo e($testimonials[0]->designation); ?></span><br>
                        </p>
                    </div>
                    </div>
                  </div>
                </div>
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                <div class="item">
                  <div class="row" style="padding: 20px">
                    <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                    <p class="testimonial_para"><?php echo e(strip_tags($testimonial->content)); ?></p><br>
                    <div class="row">
                    <div class="col-sm-2">
                        <img src="<?php echo e(asset('public/front/testimonial').'/'.$testimonial->image); ?>" class="img-responsive" style="width: 80px">
                        </div>
                        <div class="col-sm-10">
                        <h4><strong><?php echo e($testimonial->name); ?></strong></h4>
                        <p class="testimonial_subtitle"><span><?php echo e($testimonial->designation); ?></span><br>
                        </p>
                    </div>
                    </div>
                  </div>
                </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
        </div>
        <div class="col-sm-12">
            <div class="controls testimonial_control pull-right">
                <a class="left fa fa-chevron-left btn btn-default testimonial_btn" href="#carousel-example-generic"
                  data-slide="prev"></a>

                <a class="right fa fa-chevron-right btn btn-default testimonial_btn" href="#carousel-example-generic"
                  data-slide="next"></a>
              </div>
        </div>
    </div>
    <?php endif; ?>
</div>
    
    <!--Sponsors Section-->
    <?php if($sponsors): ?>
    <section class="sponsors-section" >
        <div class="auto-container">
            <!--Section Title-->
            <div class="sec-title centered">
                <h2 style="color:#000;">OUR SPONSORS</h2>
                <div class="separator"></div>
            </div>
            
            <div class="sponsors-outer">
                <!--Sponsors Carousel-->
                <ul class="sponsors-carousel">
                    <?php $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/sponsors/').'/'.$sponsor->image); ?>" alt=""></a></figure></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            
        </div>
    </section>
    <?php endif; ?>
    
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\welfair\resources\views/front/index.blade.php ENDPATH**/ ?>