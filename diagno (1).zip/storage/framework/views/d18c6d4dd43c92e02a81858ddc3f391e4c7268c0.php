
<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2> Client</h2>
          <ol>
            <li><a href="<?php echo e(route('/')); ?>">Home</a></li>
            <li>Client</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->
<main id="main">
<section >
    <div class="container">
         <div class="section-title">
          <h2>Our Client</h2>
        </div>
        <div class="row">
			<?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <img src="<?php echo e(asset('public/front/client/').'/'.$client->image); ?>" width="100%">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
  </section><!-- End Hero -
  
  
   </main><!-- End #main -->

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\socid\resources\views/front/client.blade.php ENDPATH**/ ?>