    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
	 <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    <h1>
    Edit Doctor
    </h1>
    <ol class="breadcrumb">
    <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="#">Edit Doctor</a></li>
    <li><a href="#">Edit Doctor</a></li>
    </ol>
    </section>
    
    <!-- Main content -->
    <section class="content">
    <div class="row">
    <!-- left column -->
    <div class="col-md-12">
    <!-- general form elements -->
    <div class="box box-primary">
    <div class="box-header with-border">
	
	<?php if(session('success')): ?>
	<div class="alert alert-success">
	<?php echo e(session('success')); ?>

	</div>
	<?php elseif(session('error')): ?>
	<div class="alert alert-danger">
	<?php echo e(session('error')); ?>

	</div>
	<?php endif; ?>
	
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="alert alert-danger">
	<?php echo e($error); ?>

	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <form role="form" method="POST" action ="<?php echo e(route('admin.doctors-edit',$doctor->id)); ?>" enctype="multipart/form-data">
    <div class="box-body">
	<?php echo e(csrf_field()); ?>


	<div class="form-group">
    <label for="exampleInputEmail1">Specialist</label>
    <select class="form-control"  id="exampleInputname" name="specialist" required>
        <option value="<?php echo e($doctor->specialists); ?>"><?php echo e($doctor->specialists); ?></option>
		<?php $__currentLoopData = $specialists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($specialist->name); ?>"><?php echo e($specialist->name); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
    </div>
    
    <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" class="form-control"  id="exampleInputname" name="name" placeholder="Enter Doctor Name" value="<?php echo e($doctor->name); ?>" required>
    </div>
    
    <div class="form-group">
    <label for="exampleInputEmail1">Mobile</label>
    <input type="text" class="form-control"  id="exampleInputname" name="mobile" placeholder="Enter Doctor Mobile" value="<?php echo e($doctor->mobile); ?>" required>
    </div>
    
    <div class="form-group">
    <label for="exampleInputEmail1">Password</label>
    <input type="text" class="form-control"  id="exampleInputname" name="password" placeholder="Enter Doctor Password" value="<?php echo e($doctor->password); ?>" required>
    </div>
    
    <div class="form-group">
    <label for="exampleInputEmail1">Email</label>
    <input type="email" class="form-control"  id="exampleInputname" name="email" placeholder="Enter Doctor Email" value="<?php echo e($doctor->email); ?>" >
    </div>
    
    <div class="form-group">
    <label for="exampleInputEmail1">Experience in Years</label>
    <input type="text" class="form-control"  id="exampleInputname" name="experience" placeholder="Enter Experience" value="<?php echo e($doctor->experience); ?>" >
    </div>
	
	<div class="form-group">
    <label for="exampleInputEmail1">Fee</label>
    <input type="text" class="form-control"  id="exampleInputname" name="fee" placeholder="Enter Fee" value="<?php echo e($doctor->fee); ?>" required>
    </div>
	
	<div class="form-group">
    <label for="exampleInputEmail1">Address</label>
    <input type="text" class="form-control"  id="exampleInputname" name="address" placeholder="Enter Address" value="<?php echo e($doctor->address); ?>" >
    </div>
    
    <div class="form-group">
    <label for="exampleInputEmail1">Pincode</label>
    <input type="text" class="form-control"  id="exampleInputname" name="pincode" placeholder="Enter Pincode" value="<?php echo e($doctor->pincode); ?>" >
    </div>
	
	<div class="form-group">
    <label for="exampleInputEmail1">Timing</label>
    <input type="text" class="form-control"  id="exampleInputname" name="timing" placeholder="Enter Timing" value="<?php echo e($doctor->timing); ?>" >
    </div>
	
	<div class="form-group">
    <label for="exampleInputEmail1">Qualifications</label>
    <input type="text" class="form-control"  id="exampleInputname" name="qualifications" placeholder="Enter Qualifications" value="<?php echo e($doctor->qualifications); ?>" >
    </div>
	
	<div class="form-group">
    <label for="exampleInputEmail1">Memberships</label>
    <input type="text" class="form-control"  id="exampleInputname" name="memberships" placeholder="Enter Memberships" value="<?php echo e($doctor->memberships); ?>" >
    </div>
	
	<div class="form-group">
    <label for="exampleInputEmail1">Awards</label>
    <input type="text" class="form-control"  id="exampleInputname" name="awards" placeholder="Enter Awards" value="<?php echo e($doctor->awards); ?>" >
    </div>
	
	<div class="form-group">
    <label for="exampleInputEmail1">Professional Experience</label>
    <textarea class="textarea"   name="professional_experience" placeholder="Enter Professional Experience"
    style="width: 100%; height: 108px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo e($doctor->professional_experience); ?></textarea>
    </div>
	
	<div class="form-group">
    <label for="exampleInputEmail1">Discription</label>
    <textarea class="textarea"   name="discription" placeholder="Enter Discription"
    style="width: 100%; height: 108px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo e($doctor->discription); ?></textarea>
    </div>

    
    <div class="form-group">
    <label for="exampleInputEmail1">Image</label>
    <input type="file" class="form-control"  id="exampleInputname" name="image" placeholder="Enter Image">
    </div>
    
    <img src="<?php echo e(asset('public/front/doctors/').'/'.$doctor->image); ?>" width="200px">
    

    
    <!-- /.box-body -->
    
    <div class="box-footer">
    <button type="submit" class="btn btn-primary">Submit</button>
    </div>
    </form>
    </div>
    
    
    </div>
    
    </div>
    <!-- /.row -->
    </section>
    <!-- /.content -->
    </div>
    
   
    

    <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    
<?php /**PATH /home/u769120014/domains/diagnomitra.com/public_html/resources/views/admin/edit-doctors.blade.php ENDPATH**/ ?>