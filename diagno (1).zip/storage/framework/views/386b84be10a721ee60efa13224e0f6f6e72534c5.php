<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>




/* Style the tab */
.tab {
  float: left;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
  width: 25%;
  
}

/* Style the buttons inside the tab */
.tab button {
  display: block;
  background-color: inherit;
  color: black;
  padding: 15px 16px;
  width: 100%;
  border: none;
  outline: none;
  text-align: left;
  cursor: pointer;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #2f2f57;
}

/* Create an active/current "tab button" class */
.tab button.active {
  background-color: #2f2f57;
  color: #fff;
}

/* Style the tab content */
.tabcontent {
  float: left;
  padding: 0px 12px;
  border: 1px solid #ccc;
  width: 75%;
  height: auto;
    
}

img{
  max-width:262px;
  max-height:197px;
}
input[type=file]{
padding:10px;

color: #000;
    font-size: 14px;
    font-weight: 400;
    border-top: 1px solid;
    border-left: 1px solid;
    border-right: 1px solid;
    border-bottom: 1px solid;
}
  
.tab1 {
  overflow: hidden;
}

/* Style the buttons inside the tab */
.tab1 button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 20px 18px;
  transition: 0.3s;
  font-size: 25px;
  color:#fff;
}

/* Change background color of buttons on hover */
.tab1 button:hover {
 background-color: #2f2f57;
}

.tab1 button.active {
  background-color: #2f2f57;
}

/* Style the tab content */
.tab1content {
  border: 1px solid #c9c3ba;
  padding: 0.5em; 
  background-color: #fff;
    box-shadow: 0px 5px 15px 0px rgba(0,0,0,.15);
    border-radius: 10px;
}



.tab-content{
    width: 100%;
}
.nav-tabs{
        width: 100%;
    height: 43px;
}

/**/

.tabContent{
    padding:10px 30px;
}
.tabContent h3{
        color: #55bbea;
}
.tabContent h4, .tabContent h6{
        color: #000;
         
}

.tabContent table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

.tabContent td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

.tabContent tr:nth-child(even) {
  background-color: #f7f7f7;
}
.dash-page{
    padding-top: 70px;
}
.nav-pills .nav-link.active, .nav-pills .show>.nav-link{
    background: #2f2f57;
}
.btn-style-three{
    background-color: #2f2f57;
    padding: 12px 59px;
    border-radius: 5px;
    border: none;
    color: #fff;
}
.plan-txt a{
    text-decoration:none;
    font-size:22px;
    color: #2f2f57;
}
</style>



</br></br>


<div class="site-section dash-page">
    <div class="container-fluid">
    
    
    <div class="row">
    
    <div class="tab">
		<button class="tablinks" onclick="openCity(event, 'personalinformation')" id="defaultOpen"><i class="fas fa-user-shield"></i> Personal Details</button>
		<button class="tablinks" onclick="openCity(event, 'emailId')"><i class="fas fa-envelope-open-text"></i> Our Plans</button>
            
        <a href="<?php echo e(route('user.logout')); ?>">LogOut</a>
         
    </div>

    <div id="personalinformation" class="tabcontent" style="display: block;">
	  <form name="update-details" method="POST" action="<?php echo e(route('user.updateprofile')); ?>">
      <div class="container" style="width:100%;">
          <div class="row">
              <div class="col-sm-12" style="padding:10px">
                  <h4 class="theme-btn" style="color:#2f2f57;">Personal Details</h4><hr>
              </div>
			  
			
          </div><br>
		  <?php if(session('success')): ?>
				<div class="alert alert-success">
				<?php echo e(session('success')); ?>

				</div>
			<?php elseif(session('error')): ?>
				<div class="alert alert-danger">
				<?php echo e(session('error')); ?>

				</div>
			<?php endif; ?>
			
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="alert alert-danger">
				<?php echo e($error); ?>

				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
		  
		  <div class="form-group">
				<?php echo e(csrf_field()); ?>

				<div class="row">
					<div class="col-md-6">
						<strong>First Name:</strong>
						<input type="text" name="first_name" class="form-control" value="<?php echo e($detail->first_name); ?>" />
					</div>
					<!--<div class="span1"></div>-->
					<div class="col-md-6">
						<strong>Last Name:</strong>
						<input type="text" name="last_name" class="form-control" value="<?php echo e($detail->last_name); ?>" />
					</div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-md-6">
						<strong>Company Name:</strong>
						<input type="text" class="form-control" name="company" value="<?php echo e($detail->company); ?>"  />
					</div>
					<div class="col-md-6">
						<strong>Phone Number:</strong>
						<input type="text" name="phone_number" class="form-control" value="<?php echo e($detail->phone_number); ?>"  />
					</div>
				</div>
			</div>
						
			<div class="form-group">
				<div class="row">
					<div class="col-md-6"><strong>Street Address:</strong>
						<input type="text" name="address" class="form-control" value="<?php echo e($detail->address); ?>" />
					</div>
					<div class="col-md-6"><strong>City:</strong>
						<input type="text" name="city" class="form-control" value="<?php echo e($detail->city); ?>" />
					</div>
				</div>
			</div>
			
			<div class="form-group">
				<div class="row">
					<div class="col-md-6"><strong>State:</strong>
						<input type="text" name="state" class="form-control" value="<?php echo e($detail->state); ?>" />
					</div>
					<div class="col-md-6"><strong>Zip / Postal Code:</strong>
						<input type="text" name="zip_code" class="form-control" value="<?php echo e($detail->zip_code); ?>" />
					</div>
				</div>
			</div>
          
			<div class="col-sm-12">
				<input class="theme-btn btn-style-three" type="submit" value="Submit">
			</div>
    
          
      </div>
	  </form>
      </br>
    </div>

<div id="emailId" class="tabcontent" style="display: block;">
 
  <div class="container" style="width:100%;">
      <div class="row">
          <div class="col-sm-12" style="padding:10px">
              <h4 class="theme-btn " style="color:#2f2f57;">Our Plan</h4><hr>
          </div>
      </div><br>
	  <?php if($detail->plan): ?>
      <div class="row">
          
          <div class="col-sm-4">
              <div class="plan-txt">
                   <a href="#"><?php echo e($detail->plan); ?></a>
              </div>
           
          </div>
          <div class="col-sm-4">
              <div class="plan-txt">
              <a href="#">Rs. <?php echo e($detail->amount); ?>/m</a>
              </div>
          </div>
          <div class="col-sm-4">
              <div class="plan-txt">
              <a href="#"><?php echo e($detail->updated_at); ?></a>
              </div>
          </div>
          
      </div>
	  <?php else: ?>
	  <div class="row">

          <div class="col-sm-4">
              <div class="plan-txt">
                   Plan not found
              </div>
           
          </div>
		  
      </div>
	  <?php endif; ?>	
      <!---->
     

  </div>
  </br>
</div>
<!--End Plans -->



</div>
</div>
</div>





<!--New Tab-->


<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>



<script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
</script> 

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\socid\resources\views/front/dashboard.blade.php ENDPATH**/ ?>