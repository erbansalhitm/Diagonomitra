<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- ======= Hero Section ======= -->
  <section id="hero">
    <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">

      <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

      <div class="carousel-inner" role="listbox">

        <!-- Slide 1 -->
        <div class="carousel-item active" style="background-image: url('<?php echo e(asset('public/front/slider/').'/'.$slid->sliderImage); ?>')">
        </div>

        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="carousel-item" style="background-image: url('<?php echo e(asset('public/front/slider/').'/'.$slider->sliderImage); ?>')">
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

      </div>

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon icofont-simple-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon icofont-simple-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>

    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Section-1 ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title">
          <h2><?php echo e($homepage->title); ?></h2>
          <!--<p><?php echo e($homepage->content); ?></p>-->
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-4">
            <div class="sec-box" >
              <i class="bx bxl-facebook"></i>
              <h5>Facebook</h5>
            </div>
          </div>
          <div class="col-lg-4 col-md-4">
            <div class="sec-box" >
              <i class="bx bxl-twitter"></i>
            <h5>Twitter</h5>
            </div>
            
          </div>
          <div class="col-lg-4 col-md-4">
            <div class="sec-box" >
              <i class="bx bxl-instagram"></i>
            <h5 >Instagram</h5>
            </div>
            
          </div>
          <div class="col-lg-4 col-md-4">
            <div class="sec-box">
              <i class="bx bxl-skype"></i>
            <h5>Skype</h5>
            </div>
            
          </div>
          <div class="col-lg-4 col-md-4">
            <div class="sec-box" >
              <i class="bx bxl-linkedin"></i>
              <h5>LinkedIn</h5>
            </div>
            
          </div>
          <div class="col-lg-4 col-md-4">
            <div class="sec-box" >
              <i class="bx bxl-youtube"></i>
              <h5>Youtube</h5>
            </div>
            
          </div>
        </div>

      </div>
    </section>
   
    <!-- ======= Section-2 ======= -->
    <section id="" class="works" >
      <div class="container">

        <div class="section-title">
          <h2><?php echo e($aboutus->title); ?></h2>
        </div>

        <div>
          <p>
            <?php echo e(strip_tags($aboutus->content)); ?>

          </p>
        </div>

        <div>
          <div class="row">
            <div class="col-lg-6 col-md-6">
              <div>
                <h4 class="text-center">BEFORE</h4>
              </div>
              <div class="before-img">
                <img src="<?php echo e(asset('public/front/about/').'/'.$aboutus->bimage); ?>">
              </div>
            </div>
            <div class="col-lg-6 col-md-6">
              <div>
                <h4 class="text-center">AFTER</h4>
              </div>
              <div class="after-img">
                <img src="<?php echo e(asset('public/front/about/').'/'.$aboutus->aimage); ?>">
              </div>
            </div>
          </div>
        </div>


      </div>
    </section>

    <!-- ======= Section-3 ======= -->
    <section id="" class="works">
      <div class="container">

        <div class="section-title">
          <h2>Why social media</h2>
        </div>

        <div>
          <h4 style="font-family: sans-serif;">
		  <?php echo e($media->title); ?>

          </h4>
          <?php echo substr(strip_tags($media->content),0,400); ?>

		  </br> 	
		  </br> 	
		  </br> 	
          <div class="moreBtn btn-shadow">
            <a href="<?php echo e(route('media')); ?>">Read More</a>
          </div>
        </div>

      


      </div>
    </section>

    <section style="background:#f8f8fb">
      <div class="container">
        <div class="section-title">
          <h2>Our Pricing Plans</h2>
        </div>
        <div class="row">
		  <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
          <div class="col-lg-4 col-md-4" style="margin-bottom: 10px;">
            <div class="price-box1" >
              <h4 style=" font-weight: 600;" ><?php echo e($price->plan); ?> <p style="font-family: sans-serif">Rs. <?php echo e($price->price); ?>/m</p></h4>
              </div>
               <div class="price-box">
              <ul >
               <?php echo $price->shortDetail; ?>

                <div class="moreBtn btn-shadow" style="padding-left:50px"></br>
            <a href="<?php echo e(route('pricing')); ?>">Order Now</a>
          </div>
              </ul>
              
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </div>
      </div>
    </section>

   <section style="background:#DCDCDC">
     <div class="container">
      <div class="section-title">
          <h2>Contact Us</h2>
        </div>
       <div class="row">
         <div class="col-lg-12 col-md-12">
           <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="form-row">
                <div class="col-lg-6 col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                  <div class="validate"></div>
                </div>
                <div class="col-lg-6 col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="WhatsApp No." data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                  <div class="validate"></div>
                </div>
                
              </div>
              
              <div class="form-row">
                <div class="col-lg-6 col-md-6 form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                  <div class="validate"></div>
                </div>
                <div class="col-lg-6 col-md-6 form-group">
                  <input type="text" class="form-control" name="subject"  placeholder="Your Subject" data-rule="subject" data-msg="Please enter a valid Subject" />
                  <div class="validate"></div>
                </div>
                
                 
              </div>
              <div class="form-row">
                
                <div class="col-lg-6 col-md-6 form-group">
                <textarea class="form-control" name="message" rows="3" data-rule="required" data-msg="Please write something for us" placeholder="Description"></textarea>
                <div class="validate"></div>
                </div>
                
                 <div class="col-lg-6 col-md-6 form-group">
               <div class="text-center homeContact" style="margin-top: 30px;"><button type="submit">Send</button></div>
                </div>
              </div>
              
              
             
              
            </form>
         </div>
       </div>
     </div>
   </section>

  </main><!-- End #main -->

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\socid\resources\views/front/index.blade.php ENDPATH**/ ?>