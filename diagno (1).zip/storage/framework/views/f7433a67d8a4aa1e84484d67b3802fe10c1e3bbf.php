
<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-3">
  <div class="row">
    <?php echo $__env->make('doctor.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-sm-9">
      <div class="card px-3 py-3">
      <div class="tab-content" id="v-pills-tabContent">
        <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
          <div class="row">
            <div class="col-sm-6"><h5><b>Slot List</b></h5></div>
                <div class="col-sm-12 col-md-12 col-xl-12 col-lg-12">
                    <?php if(session('msg')): ?>
                        <?php echo session('msg'); ?>

                    <?php endif; ?>
                    
                </div>
                
                
            </div>
            
             <table class="table">
                <thead>
                  <tr>
                    <th>Slot</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                  <tr>
                    <td><?php echo e($slot->slot); ?></td>
                    <td><a href="<?php echo e(route('doctor.delete-slot',$slot->id)); ?>">Delete</a></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>    
            
        </div>
        
        </div>
        </div>
      </div>
    </div>
  </div>

  <?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH /home/u769120014/domains/diagnomitra.com/public_html/resources/views/doctor/slot-list.blade.php ENDPATH**/ ?>