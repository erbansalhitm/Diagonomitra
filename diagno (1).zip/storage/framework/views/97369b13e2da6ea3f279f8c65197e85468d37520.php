<!DOCTYPE html>
	<html dir="ltr" lang="en-US">
	<head>
	    	<title>Golden</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="author" content="SemiColonWeb" />
          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700|Raleway:300,400,500,600,700|Crete+Round:400i" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(asset('public/front/css/bootstrap.css')); ?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(asset('public/front/style.css')); ?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(asset('public/front/css/dark.css')); ?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(asset('public/front/css/font-icons.css')); ?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(asset('public/front/css/animate.css')); ?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(asset('public/front/css/magnific-popup.css')); ?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(asset('public/front/css/calendar.css')); ?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(asset('public/front/css/responsive.css')); ?>" type="text/css" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />

	
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<style>

/* Smartphones (portrait and landscape) ----------- */
@media  only screen and (min-device-width : 320px) and (max-device-width : 480px) {
.huj{margin-top:-75px;}
}

/* Smartphones (landscape) ----------- */
@media  only screen and (min-width : 321px) {
.huj{margin-top:-75px;}
}

/* Smartphones (portrait) ----------- */
@media  only screen and (max-width : 320px) {
.huj{margin-top:-75px;}
}

/* iPads (portrait and landscape) ----------- */
@media  only screen and (min-device-width : 768px) and (max-device-width : 1024px) {
.huj{margin-top:0px;}
}

/* iPads (landscape) ----------- */
@media  only screen and (min-device-width : 768px) and (max-device-width : 1024px) and (orientation : landscape) {
.huj{margin-top:-75px;}
}

/* iPads (portrait) ----------- */
@media  only screen and (min-device-width : 768px) and (max-device-width : 1024px) and (orientation : portrait) {
.huj{margin-top:-75px;}
}
/**********
iPad 3
**********/
@media  only screen and (min-device-width : 768px) and (max-device-width : 1024px) and (orientation : landscape) and (-webkit-min-device-pixel-ratio : 2) {
.huj{margin-top:0px;}
}

@media  only screen and (min-device-width : 768px) and (max-device-width : 1024px) and (orientation : portrait) and (-webkit-min-device-pixel-ratio : 2) {
.huj{margin-top:0px;}
}
/* Desktops and laptops ----------- */
@media  only screen  and (min-width : 1224px) {
.huj{margin-top:0px;}
}

/* Large screens ----------- */
@media  only screen  and (min-width : 1824px) {
.huj{margin-top:0px;}
}

/* iPhone 4 ----------- */
@media  only screen and (min-device-width : 320px) and (max-device-width : 480px) and (orientation : landscape) and (-webkit-min-device-pixel-ratio : 2) {
.huj{margin-top:-75px;}
}

@media  only screen and (min-device-width : 320px) and (max-device-width : 480px) and (orientation : portrait) and (-webkit-min-device-pixel-ratio : 2) {
.huj{margin-top:-75px;}
}

/* iPhone 5 ----------- */
@media  only screen and (min-device-width: 320px) and (max-device-height: 568px) and (orientation : landscape) and (-webkit-device-pixel-ratio: 2){
.huj{margin-top:-75px;}
}

@media  only screen and (min-device-width: 320px) and (max-device-height: 568px) and (orientation : portrait) and (-webkit-device-pixel-ratio: 2){
.huj{margin-top:-75px;}
}

/* iPhone 6, 7, 8 ----------- */
@media  only screen and (min-device-width: 375px) and (max-device-height: 667px) and (orientation : landscape) and (-webkit-device-pixel-ratio: 2){
.huj{margin-top:-75px;}
}

@media  only screen and (min-device-width: 375px) and (max-device-height: 667px) and (orientation : portrait) and (-webkit-device-pixel-ratio: 2){
.huj{margin-top:-75px;}
}

/* iPhone 6+, 7+, 8+ ----------- */
@media  only screen and (min-device-width: 414px) and (max-device-height: 736px) and (orientation : landscape) and (-webkit-device-pixel-ratio: 2){
.huj{margin-top:-75px;}
}

@media  only screen and (min-device-width: 414px) and (max-device-height: 736px) and (orientation : portrait) and (-webkit-device-pixel-ratio: 2){
.huj{margin-top:-75px;}
}

/* iPhone X ----------- */
@media  only screen and (min-device-width: 375px) and (max-device-height: 812px) and (orientation : landscape) and (-webkit-device-pixel-ratio: 3){
.huj{margin-top:-75px;}
}

@media  only screen and (min-device-width: 375px) and (max-device-height: 812px) and (orientation : portrait) and (-webkit-device-pixel-ratio: 3){
.huj{margin-top:-75px;}
}

/* iPhone XS Max, XR ----------- */
@media  only screen and (min-device-width: 414px) and (max-device-height: 896px) and (orientation : landscape) and (-webkit-device-pixel-ratio: 3){
    .huj{margin-top:-75px;}
}

@media  only screen and (min-device-width: 414px) and (max-device-height: 896px) and (orientation : portrait) and (-webkit-device-pixel-ratio: 3){
.huj{margin-top:-75px;}
}

/* Samsung Galaxy S3 ----------- */
@media  only screen and (min-device-width: 320px) and (max-device-height: 640px) and (orientation : landscape) and (-webkit-device-pixel-ratio: 2){
.huj{margin-top:-75px;}
}

@media  only screen and (min-device-width: 320px) and (max-device-height: 640px) and (orientation : portrait) and (-webkit-device-pixel-ratio: 2){
.huj{margin-top:-75px;}
}

/* Samsung Galaxy S4 ----------- */
@media  only screen and (min-device-width: 320px) and (max-device-height: 640px) and (orientation : landscape) and (-webkit-device-pixel-ratio: 3){
.huj{margin-top:-75px;}
}

@media  only screen and (min-device-width: 320px) and (max-device-height: 640px) and (orientation : portrait) and (-webkit-device-pixel-ratio: 3){
.huj{margin-top:-75px;}
}

/* Samsung Galaxy S5 ----------- */
@media  only screen and (min-device-width: 360px) and (max-device-height: 640px) and (orientation : landscape) and (-webkit-device-pixel-ratio: 3){
.huj{margin-top:-75px;}
}

@media  only screen and (min-device-width: 360px) and (max-device-height: 640px) and (orientation : portrait) and (-webkit-device-pixel-ratio: 3){
.huj{
          margin-top:-75px;
          font-size: 18px;
          text-align:center;
          position: relative;} 
}


/* Extra large devices (large laptops and desktops, 1200px and up) */
@media  only screen and (min-width: 1200px) {
    .huj{
          margin-top:0px;
          font-size: 18px;
          text-align:center;
          position: relative;} 
}




 .mng{
        right: 0px;
         top: 12px;
        border-radius: 0px 0px 8px 8px;
    }
.dropdown-content {
  margin-top: 23px;
    background: #ffffff;
    display: none;
    position: absolute;
    min-width: 260px;
    box-shadow: 5px 8px 26px 20px rgba(0, 0, 0, 0.05);
    z-index: 199999;
}

.dropdown-content a {
  color: black;
  padding: 6px 12px;
  text-decoration: none;
  display: block;
  font-family:sans-serif;
}
.dropdown:hover .dropdown-content {display: block;
        border-top: 5px solid #f58220;
        
}
#header.full-header #primary-menu>ul{
    border-right:none !important;
}
.huj{
        padding: 8px 0px;
}
#header.full-header #logo{ border-right:none !important;}
</style>
	</head>
	<body class="stretched">

	<div id="wrapper" class="clearfix" style="overflow-x: hidden;">

		<header id="header" class="full-header sticky-header">
			<div id="header-wrap">
				<div class="container clearfix">
					<div id="primary-menu-trigger"><i class="icon-reorder" style="font-size: 30px;"></i></div>

					<div id="logo">
						<a href="<?php echo e(url('/')); ?>" class="standard-logo" data-dark-logo="<?php echo e(asset('public/front/images/logo-dark.png')); ?>"><img src="<?php echo e(asset('public/front/images/magdam.png')); ?>" alt="Canvas Logo"></a>
							<a href="index.php" class="retina-logo" data-dark-logo="images/logo-dark@2x.png">
							    <img src="<?php echo e(asset('public/front/images/magdam.png')); ?>" alt="Canvas Logo" style="margin-top: 26px;margin-left: -18px;"></a>
					</div>

					<nav id="primary-menu">
						<ul>
							<li class="current"><a href="<?php echo e(url('/')); ?>"><div>Home</div></a></li>
							<li><a href="<?php echo e(url('about')); ?>"><div>About Us</div></a></li>
							<li><a href="<?php echo e(url('product')); ?>"><div>Products</div></a></li>
							<!-- <li class="mega-menu"><div class="dropdown">
                                <button class="dropbtn">Products 
                                  <i class="fa fa-caret-down" style="margin-left: 4px;"></i>
                                </button>
                                <div class="dropdown-content" style="margin-top: 0px;">
                                  <a href="<?php echo e(url('product')); ?>">Gown</a>
                                  <a href="<?php echo e(url('product')); ?>">Crop Top Skirt</a>
                                  <a href="<?php echo e(url('product')); ?>">Lehnga</a>
                                  <a href="<?php echo e(url('product')); ?>">Kurtis</a>
                                  <a href="<?php echo e(url('product')); ?>">Indo Western</a>
                                  <a href="<?php echo e(url('product')); ?>">Midi Dress</a>
                                  <a href="<?php echo e(url('product')); ?>">Top</a>
                                  <a href="<?php echo e(url('product')); ?>">Bottom</a>
                                  <a href="<?php echo e(url('product')); ?>">Night Wear</a>
                                </div>
                              </div></li> -->
							<li class="mega-menu"><a href="<?php echo e(url('blog')); ?>"><div>Blog</div></a></li>
						
							<li class="mega-menu"><a href="<?php echo e(url('contact')); ?>"><div>Contact Us</div></a></li>
							<li class="mega-menu"><a href="<?php echo e(url('tryathome')); ?>"><div>TRY AT HOME</div></a></li>
							
							
					</ul>
                    <div class="fright clearfix" style="margin: 15px 15px;">
					
				
					<!--<a href="login.php" class="social-icon si-small si-borderless si-pinterest dropdown">-->
					<!--	<i class="icon-user gh"></i>-->
					<!--	<i class="icon-user"></i>-->
					<!--	<div class="dropdown-content">-->
     <!--                <h3 style="text-align:center">Your Account</h3>-->
     <!--                </div>-->
					<!--</a>-->
					
<div class="dropdown huj">
  
  <i class="icon-user"></i>
  <div class="dropdown-content mng" >
  <h3 style="text-align:center;font-weight: 700; margin-top: 18px;">Your Account</h3>
  <p style="padding:0px 8px;">Access account & manage your orders.</p>
    <div class="" style="display:flex;margin:10px 15px"> <a href="<?php echo e(url('login')); ?>"> <button class="btn btn-primary">Sign Up</button></a>  <a href="<?php echo e(url('login')); ?>"><button class="btn btn-primary" style="float:right;">Log In</button> </a></div>
  </div>
</div>
	
					<!--<a href="#" class="social-icon si-small si-borderless si-vimeo">-->
					<!--	<i class="icon-heart"></i>-->
					<!--	<i class="icon-heart"></i>-->
					<!--</a>-->
					
				</div>
						<!--<div id="top-cart">
							<a href="#" id="top-cart-trigger"><i class="icon-shopping-cart"></i><span>5</span></a>
							<div class="top-cart-content">
								<div class="top-cart-title">
									<h4>Shopping Cart</h4>
								</div>
								<div class="top-cart-items">
									<div class="top-cart-item clearfix">
									    
										<div class="top-cart-item-image">
											<a href="#"><img src="images/shop/small/1.jpg" alt="Blue Round-Neck Tshirt" /></a>
										</div>
										<div class="top-cart-item-desc">
											<a href="#">Blue Round-Neck Tshirt</a>
												<span class="top-cart-item-price">$19.99</span>
												<span class="top-cart-item-quantity">x 2</span>
										</div>
									</div>
									<div class="top-cart-item clearfix">
										<div class="top-cart-item-image">
											<a href="#"><img src="images/shop/small/6.jpg" alt="Light Blue Denim Dress" /></a>
										</div>
										<div class="top-cart-item-desc">
											<a href="#">Light Blue Denim Dress</a>
											<span class="top-cart-item-price">$24.99</span>
											<span class="top-cart-item-quantity">x 3</span>
										</div>
									</div>
								</div>
								<div class="top-cart-action clearfix">
									<span class="fleft top-checkout-price">$114.95</span>
									<button class="button button-3d button-small nomargin fright">View Cart</button>
								</div>
							</div>
						</div>-->

						<!--<div id="top-search">
							<a href="#" id="top-search-trigger"><i class="icon-search3"></i><i class="icon-line-cross"></i></a>
								<form action="#" method="get">
									<input type="text" name="q" class="form-control" value="" placeholder="Type &amp; Hit Enter..">
								</form>
						</div>-->
					</nav>
				</div>
			</div>
		</header><?php /**PATH /opt/lampp/htdocs/gold/resources/views/front/header.blade.php ENDPATH**/ ?>