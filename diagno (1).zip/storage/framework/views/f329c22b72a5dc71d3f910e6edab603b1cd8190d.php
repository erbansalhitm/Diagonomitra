<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main">
    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Why social media?</h2>
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>Why social media?</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Section-3 ======= -->
    <section id="" class="works">
      <div class="container">

        <div class="section-title">
          <h2>Why social media</h2>
        </div>

        <div>
          <h4>
		  <?php echo e($media->title); ?>

          </h4>
			<?php echo $media->content; ?>



      </div>
    </section>

   
   

  </main><!-- End #main -->

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\socid\resources\views/front/media.blade.php ENDPATH**/ ?>