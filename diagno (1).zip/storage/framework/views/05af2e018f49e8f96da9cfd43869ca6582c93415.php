<div class="col-sm-3">
  <div class="card px-3 py-3">
    <p class="mb-0"><img class="profileicons" src="<?php echo e(asset('public/front/doctors').'/'.$doctor->image); ?>"> <?php echo e($doctor->name); ?></p>
  </div>
  <div class="card py-3 mt-2">
    <a class="light_color_text px-3" href="<?php echo e(route('doctor.enquiry')); ?>"> <img class="smallicons" src="<?php echo e(asset('public/front')); ?>/images/box.svg"> Enquiry <span class="float-right"><img src="<?php echo e(asset('public/front')); ?>/images/arrow_right.svg"></span></a>
    <hr>
    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <label class="light_color_text px-3"><img class="smallicons" src="<?php echo e(asset('public/front')); ?>/images/account.svg"> Account Settings</label>
      <a class="nav-link profile_patient active pl-5 pr-0" href="<?php echo e(route('doctor.dashboard')); ?>" >Personal Information</a>
     
    </div>
    <hr>
    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <label class="light_color_text px-3"><img class="smallicons" src="<?php echo e(asset('public/front')); ?>/images/account.svg"> Booking Slot</label>
      <a class="nav-link profile_patient active pl-5 pr-0" href="<?php echo e(route('doctor.add-slot')); ?>" >Add Slot</a>
      <a class="nav-link profile_patient active pl-5 pr-0" href="<?php echo e(route('doctor.slot-list')); ?>" >Slot List</a>
     
    </div>
    <a class="py-3 px-3 light_color_text" href="<?php echo e(route('doctor.logout')); ?>"><img class="smallicons" src="<?php echo e(asset('public/front')); ?>/images/logout.svg"> Logout</a>
  </div>
</div><?php /**PATH /home/u769120014/domains/diagnomitra.com/public_html/resources/views/doctor/sidebar.blade.php ENDPATH**/ ?>