
<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-3">
  <div class="row">
    <?php echo $__env->make('doctor.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-sm-9">
      <div class="card px-3 py-3">
      <div class="tab-content" id="v-pills-tabContent">
        <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
          <div class="row">
            <div class="col-sm-6"><h5><b>Personal Information</b></h5></div>
                <div class="col-sm-12 col-md-12 col-xl-12 col-lg-12">
                    <?php if(session('msg')): ?>
                        <?php echo session('msg'); ?>

                    <?php endif; ?>
                    
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
                
                
            </div>
            <form name="edit-profile" method="POST" action="<?php echo e(route('doctor.edit-profile')); ?>" enctype="multipart/form-data" >
                <?php echo e(csrf_field()); ?>

                <div class="form-row mt-2">
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                    <label for="inputEmail4">Full Name</label>
                    <input type="text" class="form-control" id="inputEmail4"  name="name" value="<?php echo e($doctor->name); ?>" >
                </div>
                  
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Email Id</label>
                  <input type="email" class="form-control" id="inputAddress"  name="email" value="<?php echo e($doctor->email); ?>">
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Specialists</label>
                  <input type="text" class="form-control" id="inputAddress"  name="specialists" value="<?php echo e($doctor->specialists); ?>">
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Experience in Years</label>
                  <input type="text" class="form-control" id="inputAddress"  name="experience" value="<?php echo e($doctor->experience); ?>">
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Fee</label>
                  <input type="text" class="form-control" id="inputAddress"  name="fee" value="<?php echo e($doctor->fee); ?>">
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Address</label>
                  <input type="text" class="form-control" id="inputAddress"  name="address" value="<?php echo e($doctor->address); ?>">
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Pincode</label>
                  <input type="text" class="form-control" id="inputAddress"  name="pincode" value="<?php echo e($doctor->pincode); ?>">
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Timing</label>
                  <input type="text" class="form-control" id="inputAddress"  name="timing" value="<?php echo e($doctor->timing); ?>">
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Qualifications</label>
                  <input type="text" class="form-control" id="inputAddress"  name="qualifications" value="<?php echo e($doctor->qualifications); ?>">
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Memberships</label>
                  <input type="text" class="form-control" id="inputAddress"  name="memberships" value="<?php echo e($doctor->memberships); ?>">
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Awards</label>
                  <input type="text" class="form-control" id="inputAddress"  name="awards" value="<?php echo e($doctor->awards); ?>">
                </div>
                
                <div class="col-sm-12 col-md-12 col-xl-6 col-lg-6">
                    <div><label class="mr-3 mb-0 f-18">Gender : </label></div>
                    <div class="form-check-inline mt-2">
                      <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="gender" value="Male" <?php if($doctor->gender == 'Male'): ?><?php echo e('checked'); ?><?php endif; ?> >Male
                      </label>
                    </div>
                    <div class="form-check-inline">
                      <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="gender" value="Female" <?php if($doctor->gender == 'Female'): ?><?php echo e('checked'); ?><?php endif; ?> >Female
                      </label>
                    </div>
                </div>
                </br>
                <div class="form-group col-sm-12 col-md-12 col-xl-12 col-lg-12">
                  <label for="inputAddress">Discription</label>
                  <textarea class="form-control" id="inputAddress"  name="discription" ><?php echo e($doctor->discription); ?></textarea>
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-12 col-lg-12">
                  <label for="inputAddress">Professional Experience</label>
                  <textarea class="form-control" id="inputAddress"  name="professional_experience" ><?php echo e($doctor->professional_experience); ?></textarea>
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <label for="inputAddress">Profile Image</label>
                  <input type="file" class="form-control" id="inputAddress"  name="image">
                </div>
                
                <div class="form-group col-sm-12 col-md-12 col-xl-6 col-lg-6">
                  <img src="<?php echo e(asset('public/front/doctors').'/'.$doctor->image); ?>" style="width:130px">
                </div>
                
                <div class="col-sm-12 col-md-12 col-xl-12 col-lg-12">
                <input type="submit" name="submit" value="Submit"class="btn blue_color_bg" >
                </div>
                </div> 
            </form>
        </div>
        
        </div>
        </div>
      </div>
    </div>
  </div>

  <?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH /home/u769120014/domains/diagnomitra.com/public_html/resources/views/doctor/edit-profile.blade.php ENDPATH**/ ?>