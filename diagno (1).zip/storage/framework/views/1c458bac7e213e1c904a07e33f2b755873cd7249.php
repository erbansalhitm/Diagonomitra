<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--Page Title-->
    <section class="page-title" style="background-image:url(<?php echo e(asset('public/front/images/background/About-Us-Banner.png')); ?>);">
        <div class="auto-container">
            <h1>About Us</h1>
            <div class="bread-crumb-outer">
                <ul class="bread-crumb clearfix">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="active">About Us</li>
                </ul>
            </div>
        </div>
    </section>
    
    
    <!--About Us-->
    <section class="about-us-section">
    	<div class="auto-container">
        	
            <!--Section Title-->
            <div class="sec-title centered">
            	<h2>ABOUT US</h2>
                <div class="separator"></div>
              
            <!--Content Box-->
            <div class="content-box">
            	<div class="row clearfix">
                	<!--Content Column-->
                    <div class="content-column col-lg-7 col-md-6 col-sm-12 col-xs-12">
                    	<div class="inner-box">
                        	<div class="text-content">
                                <p>We are a Nonpolitical, Community Service Association which has come into existence with the support of approximately 250+ families residing in Sector-31 Faridabad, Which is an independent Association with no linkages with the Resident Welfare Associations of the Sector.</p>
                                <p>The key objectives for incorporating this Association are To arrange and organize various kinds of Welfare programs e.g. Vocational Education, Job fairs, Personality development programs, Social activities for Senior citizens, Women, Children, Cultural Events etc for the community. Promote literacy, cultural and other social activities of Awareness Programs including Adult Education Classes.To arrange and organize Bhagwati Jagran, Chowki, Festivals like Vaisakhi, Lohri etc., Bhajan Kirtan, social, cultural, educational and child welfare programs/activities from time to time.To organize free Medical Camps, free Medical-Aid for the General Welfare of Public and to provide social-economic assistance to poor/needy people of the community. </p>
                            </div>
                        </div>
                    </div>
                    
                    <!--Image Column-->
                    <div class="image-column col-lg-5 col-md-6 col-sm-12 col-xs-12">
                    	<figure class="image wow fadeInRight" data-wow-duration="1500ms" data-wow-delay="0ms"><img src="<?php echo e(asset('public/front/images/about.jpeg')); ?>" style="height: 305px;" alt=""></figure>
                    </div>
                    
                </div>
            </div>
            
            <div class="row clearfix">
            	
                <!--Default Icon Column-->
                <div class="default-icon-column col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="icon-box"><span class="flaticon-target"></span></div>
                        <h3>Our Mission</h3>
                        <div class="separator"></div>
                        <div class="text">Bushwick viral skateboard cold-pressed godard. Cliche narwhal austin, godard stumptown butcher pour-over umami offal art party kitsch. </div>
                    </div>
                </div>
                
                <!--Default Icon Column-->
                <div class="default-icon-column col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="icon-box"><span class="flaticon-binoculars"></span></div>
                        <h3>Our Vision</h3>
                        <div class="separator"></div>
                        <div class="text">Bushwick viral skateboard cold-pressed godard. Cliche narwhal austin, godard stumptown butcher pour-over umami offal art party kitsch. </div>
                    </div>
                </div>
                
                <!--Default Icon Column-->
                <div class="default-icon-column col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="icon-box"><span class="flaticon-envelope"></span></div>
                        <h3>Our Message</h3>
                        <div class="separator"></div>
                        <div class="text">Bushwick viral skateboard cold-pressed godard. Cliche narwhal austin, godard stumptown butcher pour-over umami offal art party kitsch. </div>
                    </div>
                </div>
                
            </div>
            
        </div>
    </section>
    
    
    
    
    
    <!--Sponsors Section-->
    <section class="sponsors-section-two">
    	<div class="auto-container">
        	<!--Section Title-->
            <div class="sec-title centered">
            	<h2>OUR SPONSORS</h2>
                <div class="separator"></div>
            </div>
            
            <div class="sponsors-outer">
                <!--Sponsors Carousel Two-->
                <ul class="sponsors-carousel-two">
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/sponsors/7.jpg')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/sponsors/8.jpg')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/sponsors/9.jpg')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/sponsors/10.jpg')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/sponsors/11.jpg')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/sponsors/7.jpg')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/sponsors/8.jpg')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/sponsors/9.jpg')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/sponsors/10.jpg')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/sponsors/11.jpg')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/sponsors/7.jpg')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/sponsors/8.jpg')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/sponsors/9.jpg')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/sponsors/10.jpg')); ?>" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/images/sponsors/11.jpg')); ?>" alt=""></a></figure></li>
                </ul>
            </div>
            
        </div>
    </section>
	
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/welfare/resources/views/front/about.blade.php ENDPATH**/ ?>