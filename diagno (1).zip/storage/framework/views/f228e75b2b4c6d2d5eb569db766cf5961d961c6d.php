<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main">
    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>How it Works?</h2>
          <ol>
            <li><a href="<?php echo e(route('/')); ?>">Home</a></li>
            <li>How it Works?</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Section-2 ======= -->
    <section id="" class="works">
      <div class="container">

        <div class="section-title">
          <h2><?php echo e($aboutus->title); ?></h2>
        </div>

        <div>
          <p>
            <?php echo $aboutus->content; ?>

          </p>
        </div>

        <div>
          <div class="row">
            <div class="col-lg-6 col-md-6">
              <div>
                <h4 class="text-center">BEFORE</h4>
              </div>
              <div class="before-img">
                <img src="<?php echo e(asset('public/front/about/').'/'.$aboutus->bimage); ?>">
              </div>
            </div>
            <div class="col-lg-6 col-md-6">
              <div>
                <h4 class="text-center">AFTER</h4>
              </div>
              <div class="after-img">
                <img src="<?php echo e(asset('public/front/about/').'/'.$aboutus->aimage); ?>">
              </div>
            </div>
          </div>
        </div>


      </div>
    </section>

   
   

  </main><!-- End #main -->


   <?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\socid\resources\views/front/work.blade.php ENDPATH**/ ?>