<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="author" content="Rahul Gauniyal">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Redwingsolutions | It solutions for all your needs. </title>

	<!-- Favicons -->
	<link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('public/front/')); ?>/img/favicon/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('public/front/')); ?>/img/favicon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('public/front/')); ?>/img/favicon/favicon-16x16.png">
	<link rel="manifest" href="<?php echo e(asset('public/front/')); ?>/img/favicon/site.webmanifest">
	<link rel="mask-icon" href="<?php echo e(asset('public/front/')); ?>/img/favicon/safari-pinned-tab.svg" color="#5bbad5">
	<meta name="msapplication-TileColor" content="#da532c">
	<meta name="theme-color" content="#ffffff">

	<!-- Google Fonts -->
	<link
		href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap"
		rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=PT+Sans:ital,wght@0,400;0,700;1,400;1,700&display=swap"
		rel="stylesheet">

	<!-- Libraries CSS Files -->
	<link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/fontawesome-all.min.css">
	<link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/owl.carousel.min.css">
	<link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/slick.css">
	<link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/normalize.css">
	<link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/aos.css">
	<link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/flexboxgrid.css">

	<!-- Main CSS Files -->
	<link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/style.css">

</head>

<!-- Body Tag Starts -->

<body id="body-tag" class="custom-body-tag">

	<!-- Header Starts -->
	<header id="header-tag" class="custom-header-tag">
		<div class="custom-header">
			<div class="custom-top-header">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<div class="custom-header-info">
								<ul>
									<li><i class="fas fa-phone-volume"></i>
										<a href="tel:+91-9866028012">+91-9866028012</a></li>
									<li><i class="fas fa-envelope-open-text"></i>
										<a href="ktrao@redsol.in">ktrao@redsol.in</a></li>
								</ul>
							</div>
						</div>
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<div class="custom-header-sociallinks">
								<ul>
									<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
									<li><a href="#"><i class="fab fa-twitter"></i></a></li>
									<li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
									<li> <a href="#"><i class="fab fa-google-plus-g"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="custom-bottom-header">
				<div class="container">
					<div class="row">
						<!-- Header Logo -->
						<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
							<div class="custom-header-logo">
								<a href="<?php echo e(route('/')); ?>"><img src="<?php echo e(asset('public/front/')); ?>/img/logo.png "
										alt="Redwingsolutions Logo"></a>
							</div>
						</div>
						<div class="mobileicon"><i class="fas fa-bars"></i></div>
						<!-- Header Menu -->
						<div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
							<nav class="custom-header-menu">
								<ul>
									<li><a href="<?php echo e(route('/')); ?>">Home</a></li>
									<li><a href="<?php echo e(route('service')); ?>">Services</a></li>
									<li><a href="<?php echo e(route('about')); ?>">About</a></li>
									<li><a href="<?php echo e(route('products')); ?>">Products</a></li>
									<li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
								</ul>
							</nav>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<!-- Header Ends -->

	<!-- Banner Starts -->
	<?php if(!empty($sliders)): ?>
	<section id="banner-tag" class="custom-banner-tag page-section">
		<div class="custom-banner">

			<div id="bnnr-carousel" class="owl-carousel owl-theme">
				<?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="item">
					<div class="bannerbg1" style="background-image:url(<?php echo e(asset('public/front/slider/').'/'.$slider->sliderImage); ?>);">
						<div class="container">
							<div class="row">
								<div class="col-xs-12 col-sm-12 col-md-9 col-lg-7  start-align">
									<div class="custom-banner-content" data-aos="fade-up">
										<h1><?php echo e($slider->title); ?></h1>
										<p><?php echo e($slider->content); ?></p>
										<a href="<?php echo e(route('contact')); ?>" class="button">Contact Now</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</section>
	<?php endif; ?>
	<!-- Banner End -->


	<!-- Main Section Content -->
	<main id="cntnsctns" class="csmt-cntnsctns">

		<!-- Service Section Starts -->
		<?php if(!empty($services)): ?>
		<section id="service-section" class="cstm-service sctnblck page-section">
			<div class="custom-srvccntn">
				<div class="container">
					<div class="sctntle srvctitle">
						<h6>Services</h6>
						<h2>Our Work</h2>
					</div>
					<div class="row">
						<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
							<div class="srvccntnblck" data-aos="fade-up">
								<span class="srvcbox">
									<div class="bckgrndicon"><img src="<?php echo e(asset('public/front/service/').'/'.$service->image); ?>" alt=""></div>
									<h4><?php echo e($service->name); ?></h4>
									<p><?php echo e(substr(strip_tags($service->content),0,100)); ?></p>
								</span>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
							<a href="<?php echo e(route('service')); ?>" class="button">Know more</a>
						</div>
					</div>
				</div>
			</div>
		</section>
		<?php endif; ?>
		<!-- Service Section Ends -->

		<!-- About Section Starts -->
		<?php if(!empty($aboutus)): ?>
		<section id="about-section" class="cstm-about sctnblck">
			<div class="custom-abtcntn">
				<div class="container">
					<div class="row end-lg">
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-5 offset-lg-7">
							<div class="abttext">
								<div class="sctntle abttitle" data-aos="fade-up">
									<h6>About Us</h6>
								</div>
								<div class="abt-text" data-aos="fade-left">
									<h2><?php echo e($aboutus->title); ?></h2>
									<p><?php echo e(substr(strip_tags($aboutus->content),0,200)); ?></p>
								</div>
								<a href="<?php echo e(route('about')); ?>" class="button">About us</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section><!-- About Section Ends -->
		<?php endif; ?>
		<!-- Brand Section -->
		<?php if(!empty($partners)): ?>
		<section id="brndsldr-section" class="cstm-brndsldr sctnblck">
			<div class="brand-area">
				<div class="container">
					<div class="sctntle prtnrtitle" data-aos="fade-up">
						<h2>Our Partners</h2>
					</div>
					<div class="brand-active brndsldr">
						<?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="single-brand">
							<img src="<?php echo e(asset('public/front/partner/').'/'.$partner->image); ?>" alt="">
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</section><!-- Brand Section End-->
		<?php endif; ?>
		<!-- Cta Section -->
		<section id="quotecta" class="ctaquote page-section">
			<div class="container" data-aos="fade-up-right">
				<div class="quotetext">
					<div class="row center-lg center-md center-sm between-lg between-md between-sm">
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-8">
							<h3>Get connect with our consultants.</h3>
							<p>Our consulting services help enterprises in effective business transformation and our
								ultimate goal is to
								employ our deep expertise in fulfilling your requirements to the full range of IT
								solutions including
								software, hardware, IT infrastructure, IT support and operations. We guarantee to deploy
								all of our resources
								to effectively address your concern.
							</p>
						</div>
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
							<a class="quotebtn" href="<?php echo e(route('contact')); ?>">Consult now</a>
						</div>
					</div>
				</div>
			</div>
		</section><!-- Cta Section End -->

		<!-- Brand Section -->
		<?php if(!empty($clients)): ?>
		<section id="brndsldr-section" class="cstm-brndsldr sctnblck">
			<div class="brand-area">
				<div class="container">
					<div class="sctntle prtnrtitle" data-aos="fade-up">
						<h2>Our Cleints</h2>
					</div>
					<div class="brand-active brndsldr">
						<?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="single-brand">
							<img src="<?php echo e(asset('public/front/client/').'/'.$client->image); ?>" alt="">
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</section><!-- Brand Section End-->
		<?php endif; ?>
	</main>

	<!-- Footer Starts -->
	<footer id="footer-tag" class="custom-footer-tag">
		<div class="custom-footer">
			<div class="container">
				<div class="row middle-align">
					<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
						<div class="ftr-lnks">
							<ul>
									<li><a href="<?php echo e(route('/')); ?>">Home</a></li>
									<li><a href="<?php echo e(route('service')); ?>">Services</a></li>
									<li><a href="<?php echo e(route('about')); ?>">About</a></li>
									<li><a href="<?php echo e(route('products')); ?>">Products</a></li>
									<li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
							</ul>
						</div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
						<div class="ftr-certifct">
							<ul>
								<li><img src="<?php echo e(asset('public/front/')); ?>/img/certi1.jpg" alt=""></li>
								<li><img src="<?php echo e(asset('public/front/')); ?>/img/certi2.jpeg" alt=""></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer><!-- Footer Ends -->

	<footer id="ftrbtmtag" class="custom-ftrbtmtag">
		<div class="custom-footerbtm">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
						<div class="cstmcpyrght">
							<p>&copy;<script>
									document.write(new Date().getFullYear());
								</script> All rights reserved Made by <a href="https://digioodles.com"
									target="_blank">Digioodles.</a></p>
						</div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
						<div class="ftr-sociallinks">
							<ul>
								<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="#"><i class="fab fa-twitter"></i></a></li>
								<li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
								<li> <a href="#"><i class="fab fa-google-plus-g"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer><!-- Footer Ends -->

	<!-- Backto-top -->
	<a href="javascript:void();" id="back-to-top"><i class="fas fa-level-up-alt"></i></a>


	<!-- Vendor JS Files -->
	<script src="<?php echo e(asset('public/front/')); ?>/js/jquery-3.5.1.min.js"></script>
	<script src="<?php echo e(asset('public/front/')); ?>/js/easing.js"></script>
	<script src="<?php echo e(asset('public/front/')); ?>/js/jquery-migrate-3.3.0.min.js"></script>
	<script src="<?php echo e(asset('public/front/')); ?>/js/slick.min.js"></script>
	<script src="<?php echo e(asset('public/front/')); ?>/js/aos.js"></script>
	<script src="<?php echo e(asset('public/front/')); ?>/js/owl.carousel.min.js"></script>

	<!-- Template Main JS File -->
	<script src="<?php echo e(asset('public/front/')); ?>/js/custom.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\hp\resources\views/front/index.blade.php ENDPATH**/ ?>