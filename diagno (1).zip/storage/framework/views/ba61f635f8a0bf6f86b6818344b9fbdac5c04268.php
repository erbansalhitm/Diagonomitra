<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="container my-4">
    
   <div class="row">
       <div class="col-lg-8 col-md-12 offset-md-2">
           <div class="signup-form">
               <h2 class="text-center py-3">Doctor Forgot Password</h2>
               <div class="d-forgot-msg"></div>
               <form class="mt-4">
                                    
					<div class="form-group row">

						<div class="col-sm-12">
						  <lebel>Enter Registred Mobile Number</lebel>	
						  <input type="text" class="form-control d-register-mobile" id="mobile" name="mobile" placeholder="Mobile Number">
						  <i class="d-register-mobile-msg text-danger"></i>
						</div>

					</div>

					<div class="subbtn">
						<button style="width: 100%;" type="button" class="mt-2 blue_color_bg" id="d-forgot-now" >Send Password</button>
					</div>
					
                </form>
           </div>
            
       </div>
   </div>
  </div>
  
  	<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  
    <script type="text/javascript">

		$(document).ready(function() {
          $('#d-forgot-now').on('click',function () {
            
            var check = true;
           
			var _token = "<?php echo e(csrf_token()); ?>";
			
            var register_mobile = $('.d-register-mobile').val();
            
            var numberFormat = /^\d{10}$/;
    		if (register_mobile == "" || register_mobile == null) {
    			$('.d-register-mobile-msg').text('Please enter your Mobile number');
    			check = false;
    		}
    		else if (!numberFormat.test(register_mobile)) {
    			    $('.d-register-mobile-msg').text('Please enter your proper Mobile number');
    				check = false;
    		}else
            {
                $('.d-register-mobile-msg').text('');
            }
                        
            if(check == false){
                
			    return false;
		    }
		    else{
			
            $.ajax({
				type: 'post',
				url: "<?php echo e(route('doctor-forgot-password')); ?>",
				data: {_token: _token,register_mobile: register_mobile},
				success:function(res){
				    
				    if(res == '1')
				    {
				       $('.d-forgot-msg').html('<div class="alert alert-success">Password sent at your mobile number.</div>'); 
				       
				       window.setTimeout(function() {
                            location.reload();
                        }, 3000);
				       
				    }else
				    {
				        $('.d-forgot-msg').html(res);    
				    }
				    					
				}
			})
			
			
		    }
            
		    return false;			

          });
        
        });
		
		
    </script>
    
 <?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diagno\resources\views/front/doctor-forgot-password.blade.php ENDPATH**/ ?>