
  <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add Slider
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Slider</a></li>
        <li class="active">Add Slider</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
			
				<?php if(session('success')): ?>
				<div class="alert alert-success">
				<?php echo e(session('success')); ?>

				</div>
				<?php elseif(session('error')): ?>
				<div class="alert alert-danger">
				<?php echo e(session('error')); ?>

				</div>
				<?php endif; ?>
			
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="POST" action ="<?php echo e(url('admin/add-slider')); ?>" enctype="multipart/form-data">
              <div class="box-body">
				        <?php echo csrf_field(); ?>
               
                <div class="form-group">
                  <label for="exampleInputEmail1">Slider Title</label>
                  <input type="text" class="form-control" id="exampleInputname" name="title" placeholder="Slider Title" >
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Slider Content</label>
                  <input type="text" class="form-control" id="exampleInputname" name="content" placeholder="Slider Content" >
                </div>
  
                <div class="form-group">
                  <label for="exampleInputEmail1">Slider Image</label>
                  <input type="file" class="form-control" id="exampleInputname" name="sliderImage" placeholder="Upload Slider" >
                </div>
    
				
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>


        </div>

      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
 <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php /**PATH C:\xampp\htdocs\dm\resources\views/admin/add-slider.blade.php ENDPATH**/ ?>