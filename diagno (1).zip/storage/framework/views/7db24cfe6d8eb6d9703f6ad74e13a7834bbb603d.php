<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if($products): ?>
    <section class="page-title" style="background-image:url(<?php echo e(asset('public/front/')); ?>/images/background/bg-page-title-1.jpg);">
        <div class="auto-container">
            <h1><?php echo e($products->name); ?></h1>
            <div class="bread-crumb-outer">
                <ul class="bread-crumb clearfix">
                    <li><a href="<?php echo e(route('/')); ?>">Home</a></li>
                    <li class="active"><?php echo e($products->name); ?></li>
                </ul>
            </div>
        </div>
    </section>
    
    
    <!--Shop Single-->
    <div class="shop-single">
    	<div class="auto-container">
    		<!--Product Details Section-->
            <section style=" padding-top: 0px; padding-bottom: 0px;">
                <!--Basic Details-->
                <div class="container">
		<div class="card">
			<div class="container-fliud">
				<div class="wrapper row">
					<div class="preview col-md-6">
						
						<div class="preview-pic tab-content">
						  <div class="tab-pane active" id="pic-1"><img src="<?php echo e(asset('public/front/product/').'/'.$products->image); ?>" /></div>
						   <?php if($products->otherImages): ?>
    						  <?php $__currentLoopData = explode(',',$products->otherImages); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    						  <div class="tab-pane" id="pic-2<?php echo e(md5($image)); ?>"><img src="<?php echo e(asset('public/front/product/').'/'.$image); ?>" /></div>
    						  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						   <?php endif; ?>
						  
						</div>
						<ul class="preview-thumbnail nav nav-tabs">
						  <li class="active"><a data-target="#pic-1" data-toggle="tab"><img src="<?php echo e(asset('public/front/product/').'/'.$products->image); ?>" /></a></li>
						  <?php if($products->otherImages): ?>
    						  <?php $__currentLoopData = explode(',',$products->otherImages); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    						  <li><a data-target="#pic-2<?php echo e(md5($image)); ?>" data-toggle="tab"><img src="<?php echo e(asset('public/front/product/').'/'.$image); ?>" /></a></li>
    						  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						   <?php endif; ?>
						</ul>
						
					</div>
					<div class="details col-md-6">
						<h3 class="product-title"><?php echo e($products->name); ?></h3>
						
						<p class="product-description"><?php echo e(strip_tags($products->shortDetail)); ?></p>
						<h4 class="price">current price: <span><?php echo e($products->price); ?></span></h4>
						
						<h5 class="sizes">sizes:
							<span class="size" data-toggle="tooltip" title="small">s</span>
							<span class="size" data-toggle="tooltip" title="medium">m</span>
							<span class="size" data-toggle="tooltip" title="large">l</span>
							<span class="size" data-toggle="tooltip" title="xtra large">xl</span>
						</h5>
						
						<div class="action">
							<form method="post" action ="<?php echo e(route('addtocart')); ?>">
							<?php echo e(csrf_field()); ?>

							<input type="hidden" value="<?php echo e($products->id); ?>" name="id">
							<input  class="add-to-cart btn btn-default" type="submit" value="add to cart" >
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div><!--Basic Details-->
                
                
                <!--Product Info Tabs-->
                
                
                <!--Related Products-->
                <div class="related-products">
                    <div class="normal-title"><h3>Related Products</h3></div>
                    
                    <div class="row clearfix">
                        
                        <!--Default Shop Item-->
                        <?php $__currentLoopData = $releted_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="default-shop-item col-lg-3 col-md-4 col-sm-6 col-xs-12">
                            <div class="inner-box">
                                <div class="image-box">
                                    <figure class="image"><a href="<?php echo e(route('product.product-detail',$product->slug)); ?>"><img src="<?php echo e(asset('public/front/product/').'/'.$product->image); ?>" alt=""></a></figure>
                                    <div class="prod-options">
                                        <a class="lightbox-image option-btn" href="<?php echo e(asset('public/front/product/').'/'.$product->image); ?>" title="Image Caption Here" data-fancybox-group="example-gallery"><span class="fa fa-search"></span></a>
                                        <a class="option-btn" href="<?php echo e(route('product.product-detail',$product->slug)); ?>"><span class="fa fa-shopping-cart"></span></a>
                                    </div>
                                </div>
                                <div class="lower-content">
                                    <h3><a href="<?php echo e(route('product.product-detail',$product->slug)); ?>"><?php echo e($product->name); ?></a></h3>
                                    <div class="price"><span class="price-txt">Rs <?php echo e($product->price); ?></span></div>
                                    
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
                
            </section>
        </div>
    </div>
    <?php endif; ?>

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\welfair\resources\views/front/product-detail.blade.php ENDPATH**/ ?>