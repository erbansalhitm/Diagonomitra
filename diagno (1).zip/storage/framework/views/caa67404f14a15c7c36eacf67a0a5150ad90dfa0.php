 <div class="col-sm-3">
      <div class="card px-3 py-3">
        <p class="mb-0"><img class="profileicons" src="<?php echo e(asset('public/front')); ?>/images/profile_pic.svg"> <?php echo e($user->name); ?></p>
      </div>
      <div class="card py-3 mt-2">
        
        <a class="light_color_text px-3" href="<?php echo e(route('user.booking-list')); ?>"> <img class="smallicons" src="<?php echo e(asset('public/front')); ?>/images/box.svg"> Bookings <span class="float-right"><img src="<?php echo e(asset('public/front')); ?>/images/arrow_right.svg"></span></a>
        <hr>
        <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
          <label class="light_color_text px-3"><img class="smallicons" src="<?php echo e(asset('public/front')); ?>/images/account.svg"> Account Settings</label>
          <a class="nav-link profile_patient active pl-5 pr-0" href="<?php echo e(route('user.dashboard')); ?>" >Personal Information</a>
         
        </div>
        
        <a class="py-3 px-3 light_color_text" href="<?php echo e(route('user.logout')); ?>"><img class="smallicons" src="<?php echo e(asset('public/front')); ?>/images/logout.svg"> Logout</a>
      </div>
    </div><?php /**PATH C:\xampp\htdocs\diagno\resources\views/user/sidebar.blade.php ENDPATH**/ ?>