    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
	 <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    <h1>
    Seller Details
    </h1>
    <ol class="breadcrumb">
    <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="#">Seller Details</a></li>
    <li><a href="#">Seller Details</a></li>
    </ol>
    </section>
    
    <!-- Main content -->
    <section class="content">
    <div class="row">
    <!-- left column -->
    <div class="col-md-12">
    <!-- general form elements -->
    <div class="box box-primary">
    <div class="box-header with-border">
	
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <table class="table">
            <tr>
                <th>Name</th>
                <th>Contact</th>
                <th>Email</th>
                <th>State</th>
                <th>City</th>
                <th>Address</th>
            </tr>
            <tr>
                <td><?php echo e($seller->name); ?></td>
                <td><?php echo e($seller->mobile); ?></td>
                <td><?php echo e($seller->email); ?></td>
                <td><?php echo e($seller->state); ?></td>
                <td><?php echo e($seller->city); ?></td>
                <td><?php echo e($seller->address); ?></td>
            </tr>
            
        </table>
        
        <br>
        <label>Discription: <?php echo e($seller->discription); ?></label>
    </div>
    
    
    </div>
    
    </div>
    <!-- /.row -->
    </section>
    <!-- /.content -->
    </div>
    
   
    

    <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    
<?php /**PATH /home/u769120014/domains/diagnomitra.com/public_html/resources/views/admin/seller-details.blade.php ENDPATH**/ ?>