<footer id="footer" class="dark" style="background: #e7dae7; border-top:none;">
	<div class="container">

		<div class="footer-widgets-wrap clearfix">
		    <div class="row">
		        <div class="col-md-2">
		            <h5 class="hm" style="color:#000;">Know your Jewellery</h5>
		            <p class="pm">DIAMOND GUIDE</p>
                    <p class="pm">JEWELLERY GUIDE</p>
                    <p class="pm">GEMSTONES GUIDE</p>
		            <div class="fright clearfix">
					
					
					<a href="#" class="social-icon si-small si-borderless si-pinterest top1">
						<i class="icon-pinterest" style="color: #d758e7;border: 1px solid #d758e7;"></i>
						<i class="icon-pinterest" style="color: #d758e7;border: 1px solid #d758e7;"></i>
					</a>
					
					
					<a href="#" class="social-icon si-small si-borderless si-yahoo top1">
						<i class="icon-facebook" style="color:#d758e7;border: 1px solid #d758e7;"></i>
						<i class="icon-facebook" style="color:#d758e7;border: 1px solid #d758e7;"></i>
					</a>
					<a href="#" class="social-icon si-small si-borderless si-linkedin top1">
						<i class="icon-instagram" style="color:#d758e7;border: 1px solid #d758e7;"></i>
						<i class="icon-instagram" style="color:#d758e7;border: 1px solid #d758e7;"></i>
					</a>
				</div>
		        </div>
		        <div class="col-md-3">
		            <h5 class="hm" style="color:#000;">CaratLane Advantage</h5>
		            <p class="pm">15-DAY RETURNS</p>
                    <p class="pm">FREE SHIPPING</p>
                    <p class="pm">FINANCING OPTIONS</p>
		        </div>
		        <div class="col-md-2">
		            <h5 class="hm" style="color:#000;">Customer Service</h5>
		            <p class="pm">RETURN POLICY</p>
                    <p class="pm">ORDER STATUS</p>
		        </div>
		        <div class="col-md-2">
		            <h5 class="hm" style="color:#000;">About Us</h5>
		            <p class="pm">OUR STORY</p>
                    <p class="pm">PRESS</p>
                    <p class="pm">BLOG</p>
		        </div>
		        <div class="col-md-3">
		            <h5 class="hm" style="color:#000;">Contact Us</h5>
		            <p class="pm">A-33, Rajendra Nagar, Bareilly - 243 122 (U.P.)</p>
					<p class="pm">contact@mugdham.com</p>
					<p class="pm">+91-9354629146</p>
					<p class="pm">www.mugdham.com</p>
					<button class="btn btn" style="margin-top: 10px;border: 1px solid #8c62fa;">Find A Store</button>
		        </div>
		    </div>
			<!--<div class="col_two_third">
				<div class="col_one_third">
					<div class="widget clearfix">
						<img src="images/magdam.png" alt="" class="footer-logo">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do </p>
							
					</div>
				</div>
				<div class="col_one_third" style="margin-top: 35px;">
					<div class="widget widget_links clearfix">
						<h4>Blogroll</h4>
							<ul>
								<li><a href="#">Blog</a></li>
								<li><a href="#">Products</a></li>
								<li><a href="#">About Us</a></li>
								
							</ul>
					</div>
				</div>
				<div class="col_one_third col_last" style="margin-top: 35px;">
					<div class="widget clearfix">
						<h4>Customer Service</h4>
							<ul>
								<li><a href="#">Return Policy</a></li>
								<li><a href="#">Order Status</a></li>
								
							</ul>
					</div>
				</div>
			</div>-->
			<!--<div class="col_one_third col_last" style="margin-top: 35px;">
				<div class="widget clearfix" style="margin-bottom: -20px;">
				    <h4>Contact Us</h4>
					<p style="margin-bottom: 0px;"><i class="icon-home" style="font-size: large;color: #fff;"></i>&nbsp;A-33, Rajendra Nagar, Bareilly - 243 122 (U.P.)</p>
					<p style="margin-bottom: 0px;"><i class="icon-envelope" style="font-size: large;color: #fff;"></i>&nbsp;contact@mugdham.com</p>
					<p style="margin-bottom: 0px;"><i class="icon-phone" style="font-size: large;color: #fff;"></i>&nbsp;+91-9354629146</p>
					<p style="margin-bottom: 0px;"><i class="icon-globe" style="font-size: large;color: #fff;"></i>&nbsp;www.mugdham.com</p>
				</div>
				
					
			</div>-->
			
				
					
			
		</div>
	</div>

	<div id="copyrights" style="padding:0;background: #e7dae7;" >
		<div class="container clearfix">
			<div class="col_half" style="color:#52484b;">
				Copyrights Mugdham &copy; 2020 <br>
				<div class="copyright-links"><a href="#"  style="color:#52484b;">Site Map</a>/<a href="#"  style="color:#52484b;">Terms of Use</a> / <a href="#"  style="color:#52484b;">Privacy Policy</a> / <a href="#"  style="color:#52484b;">Corporate</a> / <a href="#"  style="color:#52484b;">Xclusive</a></div>
			</div>
			<div class="col_half col_last tright">
				<div class="fright clearfix">
					
				
					<a href="#" class="social-icon si-small si-borderless si-github" style="width: 47px;">
						<img src="<?php echo e(asset('public/front/images/visa.png')); ?>" alt="">
					</a>
					<a href="#" class="social-icon si-small si-borderless si-yahoo" style="width: 47px;">
						<img src="<?php echo e(asset('public/front/images/ms.png')); ?>" alt="">
					</a>
					<a href="#" class="social-icon si-small si-borderless si-linkedin" style="width: 47px;">
						<img src="<?php echo e(asset('public/front/images/pp.png')); ?>" alt="">
					</a>
					<a href="#" class="social-icon si-small si-borderless si-linkedin" style="width: 47px;">
						<img src="<?php echo e(asset('public/front/images/ae.png')); ?>" alt="">
					</a>
				</div>
				<div class="clear"></div>
					
			</div>
		</div>
	</div>
</footer>
</div>

<div id="gotoTop" class="icon-angle-up"></div>

	<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="js/jquery.js"></script>
	<script src="<?php echo e(asset('public/front/js/plugins.js')); ?>"></script>
	<script src="<?php echo e(asset('public/front/js/jquery.calendario.js')); ?>"></script>
	<script src="<?php echo e(asset('public/front/js/events-data.js')); ?>"></script>
	<script src="https://maps.google.com/maps/api/js?key=AIzaSyCzkxzbEni5vR_Ugt1De8gBzrLX3236bnA"></script>
	<script src="<?php echo e(asset('public/front/js/jquery.gmap.js')); ?>"></script>

	<script src="<?php echo e(asset('public/front/js/functions.js')); ?>"></script>
	<script>
			jQuery(document).ready( function($){
				var newDate = new Date(2019, 9, 31);
				$('#countdown-ex1').countdown({until: newDate});
			});

			var cal = $( '#calendar' ).calendario( {
				onDayClick : function( $el, $contentEl, dateProperties ) {

					for( var key in dateProperties ) {
						console.log( key + ' = ' + dateProperties[ key ] );
					}

				},
				caldata : canvasEvents
			} ),
			$month = $( '#calendar-month' ).html( cal.getMonthName() ),
			$year = $( '#calendar-year' ).html( cal.getYear() );

			$( '#calendar-next' ).on( 'click', function() {
				cal.gotoNextMonth( updateMonthYear );
			} );
			$( '#calendar-prev' ).on( 'click', function() {
				cal.gotoPreviousMonth( updateMonthYear );
			} );
			$( '#calendar-current' ).on( 'click', function() {
				cal.gotoNow( updateMonthYear );
			} );

			function updateMonthYear() {
				$month.html( cal.getMonthName() );
				$year.html( cal.getYear() );
			}

			$('#google-map4').gMap({
				 address: 'Australia',
				 maptype: 'ROADMAP',
				 zoom: 3,
				 markers: [
					{
						address: "Melbourne, Australia",
						html: "Melbourne, Australia"
					},
					{
						address: "Sydney, Australia",
						html: "Sydney, Australia"
					},
					{
						address: "Perth, Australia",
						html: "Perth, Australia"
					}
				 ],
				 doubleclickzoom: false,
				 controls: {
					 panControl: true,
					 zoomControl: true,
					 mapTypeControl: false,
					 scaleControl: false,
					 streetViewControl: false,
					 overviewMapControl: false
				 }
			});
		</script>
		<script>
			$(document).ready(function(){
			  $(".fancybox").fancybox({
					openEffect: "none",
					closeEffect: "none"
				});
				
				$(".zoom").hover(function(){
					
					$(this).addClass('transition');
				}, function(){
					
					$(this).removeClass('transition');
				});
			});
				
		</script>
		<script>
			
   wow = new WOW(
      {
        animateClass: 'animated',
        offset:       100,
        callback:     function(box) {
          console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
        }
      }
    );
    wow.init();
    document.getElementById('moar').onclick = function() {
      var section = document.createElement('section');
      section.className = 'section--purple wow fadeInDown';
      this.parentNode.insertBefore(section, this);
    };
		</script>
		<script>
		    
(function($) {
  "use strict";
  $.fn.sliderResponsive = function(settings) {
    
    var set = $.extend( 
      {
        slidePause: 5000,
        fadeSpeed: 800,
        autoPlay: "on",
        showArrows: "off", 
        hideDots: "off", 
        hoverZoom: "on",
        titleBarTop: "off"
      },
      settings
    ); 
    
    var $slider = $(this);
    var size = $slider.find("> div").length; //number of slides
    var position = 0; // current position of carousal
    var sliderIntervalID; // used to clear autoplay
      
    // Add a Dot for each slide
    $slider.append("<ul></ul>");
    $slider.find("> div").each(function(){
      $slider.find("> ul").append('<li></li>');
    });
      
    // Put .show on the first Slide
    $slider.find("div:first-of-type").addClass("show");
      
    // Put .showLi on the first dot
    $slider.find("li:first-of-type").addClass("showli")

     //fadeout all items except .show
    $slider.find("> div").not(".show").fadeOut();
    
    // If Autoplay is set to 'on' than start it
    if (set.autoPlay === "on") {
        startSlider(); 
    } 
    
    // If showarrows is set to 'on' then don't hide them
    if (set.showArrows === "on") {
        $slider.addClass('showArrows'); 
    }
    
    // If hideDots is set to 'on' then hide them
    if (set.hideDots === "on") {
        $slider.addClass('hideDots'); 
    }
    
    // If hoverZoom is set to 'off' then stop it
    if (set.hoverZoom === "off") {
        $slider.addClass('hoverZoomOff'); 
    }
    
    // If titleBarTop is set to 'on' then move it up
    if (set.titleBarTop === "on") {
        $slider.addClass('titleBarTop'); 
    }

    // function to start auto play
    function startSlider() {
      sliderIntervalID = setInterval(function() {
        nextSlide();
      }, set.slidePause);
    }
    
    // on mouseover stop the autoplay
    $slider.mouseover(function() {
      if (set.autoPlay === "on") {
        clearInterval(sliderIntervalID);
      }
    });
      
    // on mouseout starts the autoplay
    $slider.mouseout(function() {
      if (set.autoPlay === "on") {
        startSlider();
      }
    });

    //on right arrow click
    $slider.find("> .right").click(nextSlide)

    //on left arrow click
    $slider.find("> .left").click(prevSlide);
      
    // Go to next slide
    function nextSlide() {
      position = $slider.find(".show").index() + 1;
      if (position > size - 1) position = 0;
      changeCarousel(position);
    }
    
    // Go to previous slide
    function prevSlide() {
      position = $slider.find(".show").index() - 1;
      if (position < 0) position = size - 1;
      changeCarousel(position);
    }

    //when user clicks slider button
    $slider.find(" > ul > li").click(function() {
      position = $(this).index();
      changeCarousel($(this).index());
    });

    //this changes the image and button selection
    function changeCarousel() {
      $slider.find(".show").removeClass("show").fadeOut();
      $slider
        .find("> div")
        .eq(position)
        .fadeIn(set.fadeSpeed)
        .addClass("show");
      // The Dots
      $slider.find("> ul").find(".showli").removeClass("showli");
      $slider.find("> ul > li").eq(position).addClass("showli");
    }

    return $slider;
  };
})(jQuery);


 
//////////////////////////////////////////////
// Activate each slider - change options
//////////////////////////////////////////////
$(document).ready(function() {
  
  $("#slider1").sliderResponsive({
  // Using default everything
    // slidePause: 5000,
    // fadeSpeed: 800,
    // autoPlay: "on",
    // showArrows: "off", 
    // hideDots: "off", 
    // hoverZoom: "on", 
    // titleBarTop: "off"
  });
  
  $("#slider2").sliderResponsive({
    fadeSpeed: 300,
    autoPlay: "off",
    showArrows: "on",
    hideDots: "on"
  });
  
  $("#slider3").sliderResponsive({
    hoverZoom: "off",
    hideDots: "on"
  });
  
}); 



		</script>
		<script>
		   $("#signup").click(function() {
$("#first").fadeOut("fast", function() {
$("#second").fadeIn("fast");
});
});

$("#signin").click(function() {
$("#second").fadeOut("fast", function() {
$("#first").fadeIn("fast");
});
});


  
         $(function() {
           $("form[name='login']").validate({
             rules: {
               
               email: {
                 required: true,
                 email: true
               },
               password: {
                 required: true,
                 
               }
             },
              messages: {
               email: "Please enter a valid email address",
              
               password: {
                 required: "Please enter password",
                
               }
               
             },
             submitHandler: function(form) {
               form.submit();
             }
           });
         });
         


$(function() {
  
  $("form[name='registration']").validate({
    rules: {
      firstname: "required",
      lastname: "required",
      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },
    
    messages: {
      firstname: "Please enter your firstname",
      lastname: "Please enter your lastname",
      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },
  
    submitHandler: function(form) {
      form.submit();
    }
  });
}); 
		</script>
		
		<script>
		    
		</script>
</body>


</html><?php /**PATH /home/primewe1/public_html/saromc.com/gold/resources/views/front/footer.blade.php ENDPATH**/ ?>