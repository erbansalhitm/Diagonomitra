<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Socidom - Best Social Media Management Agency</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo e(asset('public/front/')); ?>/assets/img/favicon.ico" rel="icon">
  <link href="<?php echo e(asset('public/front/')); ?>/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo e(asset('public/front/')); ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo e(asset('public/front/')); ?>/assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="<?php echo e(asset('public/front/')); ?>/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="<?php echo e(asset('public/front/')); ?>/assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="<?php echo e(asset('public/front/')); ?>/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="<?php echo e(asset('public/front/')); ?>/assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="<?php echo e(asset('public/front/')); ?>/assets/vendor/venobox/venobox.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('public/front/')); ?>/assets/css/style.css" rel="stylesheet">

 
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <!--<h1 class="logo mr-auto"><a href="index.html">LOGO</a></h1>-->
      
       <a href="<?php echo e(route('/')); ?>" class="logo mr-auto"><img src="<?php echo e(asset('public/front/')); ?>/assets/img/Socidom-logo.png" alt="" class="img-fluid" ></a>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="<?php echo e(route('/')); ?>">Home</a></li>
          <li><a href="<?php echo e(route('work')); ?>">What we do?</a></li>
          <li><a href="<?php echo e(route('media')); ?>">Why Social Media?</a></li>
          <li><a href="<?php echo e(route('pricing')); ?>">Pricing</a></li>
          <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>

        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header --><?php /**PATH C:\xampp\htdocs\socid\resources\views/front/header.blade.php ENDPATH**/ ?>