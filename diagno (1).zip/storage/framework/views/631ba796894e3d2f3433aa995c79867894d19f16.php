<style>
.footer-hr {
    background: #fa6303!important;
    margin: 0;
    float: none;
    margin-bottom: 20px;
    width: 50px;
    height: 2px;
}
.contact-list {
    color: #797979;
    padding: 2px 8px;
    text-decoration: none;
    border: 1px solid #fff;
    border-radius: 2px;
    -webkit-border-radius: 8px;
    -moz-border-radius: 8px;
    -o-border-radius: 8px;
    transition: all .17s ease-in-out;
    -moz-transition: all .17s ease-in-out;
    -webkit-transition: all .17s ease-in-out;
    -o-transition: all .17s ease-in-out;
    margin-bottom: 6px;
}
</style>

<!-- START FOOTER  -->

  <footer class="section-pure-black-bg">
    <section class="footer-widget-area footer-widget-area-bg " data-bg_color="#111111"
      data-bg_opacity="0.9" style="background: url(<?php echo e(asset('public/front/')); ?>/images/footer-bg.gif);">
      <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-12 col-xs-12 text-justify">
            <div class="footer-widget ">
              <div class="sidebar-widget-wrapper">
                <div class="textwidget about-footer">
                  <div class="footer-widget-header clearfix">
                    <h3>ABOUT US</h3>
                  </div>
                  <div class="footer-hr"></div>
                  <!--  end .footer-widget-header -->

                  <div class="footer-about-text " style="text-align: initial;">
                 Lorem ipsum dolor sit amet, consectetur adipiscing elit curabitur
            eu ante non ex lobortis posuere.Lorem ipsum dolor sit amet,
                  </div>

                  <div class="social-icons margin-top-24">
                    <a href="#">
                      <i class="fa fa-facebook" style="margin-top:10px"></i>
                    </a>

                    <a href="#">
                      <i class="fa fa-twitter" style="margin-top:10px"></i>
                    </a>

                    <a href="#">
                      <i class="fa fa-pinterest-p" style="margin-top:10px"></i>
                    </a>

                    <a href="#">
                      <i class="fa fa-instagram" style="margin-top:10px"></i>
                    </a>

                    <a href="#">
                      <i class="fa fa-linkedin" style="margin-top:10px"></i>
                    </a>
                  </div>
                </div>
              </div>
              <!-- end .footer-widget-wrapper  -->
            </div>
            <!--  end .footer-widget  -->
          </div>
          <!--  end .col-md-4 col-sm-12 -->

         

          <div class="col-md-3 col-sm-6 col-xs-12  ">
            <div class="footer-widget">
              <div class="sidebar-widget-wrapper ">
                <div class="footer-widget-header clearfix">
                  <h3>QUICK LINKS</h3>
                </div>
                 <div class="footer-hr"></div>
                <!--  end .footer-widget-header -->

                <div class="textwidget">
			
                    <a href="<?php echo e(route('aboutus')); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i> About US</a><br />
                     
                  
				<a href="<?php echo e(route('contactus')); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i> Contact uS</a><br/>
				<a href=""><i class="fa fa-long-arrow-right" aria-hidden="true"></i> Services</a><br/>
				<a href="<?php echo e(route('blogs')); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i> Blogs</a><br/>
				<a href="#"><i class="fa fa-long-arrow-right" aria-hidden="true"></i> Privacy</a><br/>
                  
                </div>
              </div>
              <!-- end .footer-widget-wrapper  -->
            </div>
            <!--  end .footer-widget  -->
          </div>
          
           <div class="col-md-3 col-sm-6 col-xs-12  ">
            <div class="footer-widget">
              <div class="sidebar-widget-wrapper ">
                <div class="footer-widget-header clearfix">
                  <h3>QUICK LINKS</h3>
                </div>
                 <div class="footer-hr"></div>
                <!--  end .footer-widget-header -->

                <div class="textwidget">
			
                    <a href="<?php echo e(route('products')); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Product</a><br />
                     
                  	<a href="#"><i class="fa fa-long-arrow-right" aria-hidden="true"></i> Quality</a><br/>
				<a href="<?php echo e(route('careers')); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Careers</a><br/>
				<a href="#"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Terms</a><br/>
				<a href="#"><i class="fa fa-long-arrow-right" aria-hidden="true"></i> Disclaimer</a><br/>
				
                  
                </div>
              </div>
              <!-- end .footer-widget-wrapper  -->
            </div>
            <!--  end .footer-widget  -->
          </div>
          <!--  end .col-md-4 col-sm-12 -->
		   <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="footer-widget">
              <div class="sidebar-widget-wrapper">
                <div class="footer-widget-header clearfix">
                  <h3>CONTACT US</h3>
                </div>
                 <div class="footer-hr"></div>
                <!--  end .footer-widget-header -->
<div class="contact-list"><em><i class="fa fa-building" aria-hidden="true"></i> </em><a href="#" class="footer-link">Demo</a></div>
<div class="contact-list"><em><i class="fa fa-building" aria-hidden="true"></i> </em><a href="#" class="footer-link">support@demo.in</a></div>
<div class="contact-list"><em><i class="fa fa-building" aria-hidden="true"></i> </em><a href="#" class="footer-link">Delhi, Uttam Nagar,Delhi-110059, India</a></div>
<div class="contact-list"><em><i class="fa fa-building" aria-hidden="true"></i> </em><a href="#" class="footer-link">Office:&nbsp;+91-0000-0000</a></div>
               <!-- <div class="textwidget">
                  <i class="fa fa-envelope-o fa-contact"></i>
                  <p>
                    <a href="#">support@demo.in</a><br /><a
                      href="#">info@demo.in</a>
                  </p>

                  <i class="fa fa-location-arrow fa-contact"></i>
                  <p>Delhi, Uttam Nagar,<br />Delhi-110059, India</p>

                  <i class="fa fa-phone fa-contact"></i>
                  <p>
                    Office:&nbsp;+91-0000-0000<br />Cell:&nbsp;+91-0000-0000
                  </p>
                </div>
              </div>
              <!-- end .footer-widget-wrapper  -->
            </div>
            <!--  end .footer-widget  -->
          </div>
          <!--  end .col-md-4 col-sm-12 -->
        </div>
        <!-- end row  -->
      </div>
      <!-- end .container  -->
    </section>
    <!--  end .footer-widget-area  -->

    <!--FOOTER CONTENT  -->

    <section class="footer-contents">
      <div class="container">
        <div class="row clearfix">
          <div class="col-md-6 col-sm-12 clearfix">
            <p class="copyright-text">
              Copyright © 2020. All Right Reserved - by Demo
            </p>
          </div>

          <div class="col-md-6 col-sm-12 text-right clearfix">
            <ul class="footer-link">
              <li><a href="javascript:void(0)">Discounts</a></li>
              <li><a href="javascript:void(0)">Careers</a></li>
              <li><a href="javascript:void(0)">Terms</a></li>
              <li><a href="javascript:void(0)">Privacy</a></li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  </footer>

  <!-- BACK TO TOP BUTTON  -->

  <a id="backTop">Back To Top</a>

  <script src="<?php echo e(asset('public/front/')); ?>/js/jquery.min.js"></script>
  <script src="<?php echo e(asset('public/front/')); ?>/js/bootstrap.min.js"></script>
  <script src="<?php echo e(asset('public/front/')); ?>/js/wow.min.js"></script>
  <script src="<?php echo e(asset('public/front/')); ?>/js/jquery.backTop.min.js"></script>
  <script src="<?php echo e(asset('public/front/')); ?>/js/waypoints.min.js"></script>
  <script src="<?php echo e(asset('public/front/')); ?>/js/waypoints-sticky.min.js"></script>
  <script src="<?php echo e(asset('public/front/')); ?>/js/owl.carousel.min.js"></script>
  <script src="<?php echo e(asset('public/front/')); ?>/js/jquery.stellar.min.js"></script>
  <script src="<?php echo e(asset('public/front/')); ?>/js/jquery.counterup.min.js"></script>
  <script src="<?php echo e(asset('public/front/')); ?>/js/venobox.min.js"></script>
  <script src="<?php echo e(asset('public/front/')); ?>/js/custom-scripts.js"></script>
</body>


<!-- Mirrored from www.networkroot.in/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 11 Sep 2020 16:17:17 GMT -->
</html><?php /**PATH C:\xampp\htdocs\dm\resources\views/front/footer.blade.php ENDPATH**/ ?>