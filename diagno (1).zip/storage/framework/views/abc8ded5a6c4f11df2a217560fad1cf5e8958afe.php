

<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 

 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Stores List
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo e(url('admin/stores-list')); ?>">Stores List</a></li>
     <li><a href="<?php echo e(url('admin/stores-list')); ?>">Stores List</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">


          <div class="box">
            <div class="box-header">
              <h3 class="box-title">
				<?php if(session('success')): ?>
				<div class="alert alert-success">
				<?php echo e(session('success')); ?>

				</div>
				<?php elseif(session('error')): ?>
				<div class="alert alert-danger">
				<?php echo e(session('error')); ?>

				</div>
				<?php endif; ?>
              </h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Image</th>
                  <th>Name</th>
                  <th>Mobile</th>
                  <th>Email</th>
                  <th>Status</th>
                  <th>Action</th>

                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><img src="<?php echo e(asset('public/front/stores/').'/'.$store->image); ?>" width="100px"></td>
                    <td><?php echo e($store->name); ?></td>
                    <td><?php echo e($store->mobile); ?></td>
                    <td><?php echo e($store->email); ?></td>
                    <td>
                        <input type="hidden" name="store_id" class="store_id" value="<?php echo e($store->id); ?>">
                        <select class="form-control status" name="status">
                        <option value="0" <?php echo e(($store->status=='0')?'selected':''); ?>>Unapproved</option>
                        <option value="1" <?php echo e(($store->status=='1')?'selected':''); ?>>Approved</option>
                        </select>
                    </td>
                  <td>
                      <a href="<?php echo e(url('admin/stores-view/').'/'.$store->id."/"); ?>">View</a> |
                      <a href="<?php echo e(url('admin/qrcode-view/').'/'.$store->id."/"); ?>">QR Code</a> |
                      <a href="<?php echo e(url('admin/stores-delete/').'/'.$store->id."/"); ?>">Delete</a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
    <script type="text/javascript">
        $(document).ready(function(){
            $('.status').on('change',function(){
                var status = $(this).val();
                var self= $(this);
                var store_id = self.closest('td').find('.store_id').val();
                    
                $.ajax({
                    type: 'GET',
                    url: "<?php echo e(route('admin.update-store-status')); ?>",
                    data: {"status": status,"store_id":store_id},
                    success:function(res){
                    if(res) {
                            alert('done');
                        }
                    }
                })
            })
        })
    </script>

 <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 
<?php /**PATH /home/u769120014/domains/diagnomitra.com/public_html/resources/views/admin/stores-list.blade.php ENDPATH**/ ?>