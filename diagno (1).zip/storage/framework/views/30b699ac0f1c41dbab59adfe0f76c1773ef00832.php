<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/bg-page-title-1.jpg);">
        <div class="auto-container">
            <h1>Our Gallery</h1>
            <div class="bread-crumb-outer">
                <ul class="bread-crumb clearfix">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="active">All Activity Images</li>
                </ul>
            </div>
        </div>
    </section>
    
    <section class="about-us-section">
    	
    	    <div class="container">
                <h2 class="text-center">Activity Images</h2>
                <div class="row">
                    
                    <?php $__currentLoopData = explode(',',$activities->extraimage); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activitie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	    <div class="col-sm-3" >
            	        <div class="item" style="box-shadow: -1px 2px 4px 4px grey;">
            	            <a href="javascript:void(0)"><img src="<?php echo e(asset('public/front/activities/').'/'.$activitie); ?>" style="height:205px;" class="img-thumbnail"></a>
            	        </div>
            		    
            	    </div>
            	     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            	    
                </div>
            </div>
    </section>
    

	
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/primewe1/public_html/saromc.com/welfares/resources/views/front/allactivitie.blade.php ENDPATH**/ ?>