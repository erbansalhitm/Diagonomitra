	<!DOCTYPE html>
	<html lang="en">
	<head>
	  <title>Diagonomitra</title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	  <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/stylesheet.css">  
	  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
	    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css" integrity="sha384-REHJTs1r2ErKBuJB0fCK99gCYsVjwxHrSU0N7I1zl9vZbggVJXRMsv/sLlOAGb4M" crossorigin="anonymous">
	 <link rel="shortcut icon" type="image/x-icon" href="http://saromc.com/diagno/public/favicon.png">
	    <style>
	        .modal-nav .nav-link{
	            border:none;
	            padding: 3px 10px;
                margin: 5px 5px;
	        }
	        .modal-nav .nav-tabs{
	               width: 70%;
                margin: auto;
	        }
	        .modal-nav a{
	            background: #ba388f;
	            color:#fff;
	        }
	        .modal-nav .nav-tabs .nav-item.show .nav-link, .nav-tabs .nav-link.active {
	             background: #8a2769;
	            color:#fff;
	        }
	        .modal-nav .nav-tabs {
                border: none;
            }
            .modal-nav .nav-tabs .nav-link{
                border-top-left-radius: 0;
                border-top-right-radius: 0;
            }
            .hidetab{
                display:none;
            }
            #mySidenav{
                 display:none;
            }
            @media  only screen and (max-width: 767px) {
                .hidetab{
                    display:block;
                }
                 #mySidenav{
                 display:block;
            }
                
            }
            .otpbtn a{
                color: #2562B6;
                font-size: 12px;
            }
            .otpbtn{
                    display: block;
            }
	    </style>
	
	</head>
	<body>
	<header>
	  <div class="container-fluid">
		<nav class="navbar navbar-default">
		  
			<div class="row" style="width: 100%">
			  <!---->
			  <div id="mySidenav" class="sidenav">
                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                <a href="<?php echo e(route('doctors')); ?>">Doctor Consultation</a>
                <a href="<?php echo e(route('labtest')); ?>">Lab Test</a>
                <a href="<?php echo e(route('epharmacy')); ?>">E-Pharmacy</a>
                <a href="<?php echo e(route('health_store')); ?>">Health Store</a>
                 <a href="<?php echo e(route('cart')); ?>">Cart</a>
                <button style="margin-left: 15px;" type="button" data-toggle="modal" data-target="#join_popup" class="mt-2 blue_color_border">Login/Signup</button>
              </div>
              <div class="col-2 pt-1 nopadding hidetab">
                <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
              </div> 
			  <!---->
			  
			  
			  
			  
			  
			   <div class="col-10 col-sm-3 col-md-3 col-lg-3 col-xl-3">
				  <div class="navbar-header top_white_line">
					<a class="navbar-brand" href="<?php echo e(route('/')); ?>"><img src="<?php echo e(asset('public/front/')); ?>/images/dlogo.png"></a>
				</div>
			   </div>
			  
			  <div class="col-lg-9 col-xl-9 mt-2 d-none d-sm-none d-md-none d-lg-block nopadding float-right">        
				<ul class="nav nav-pills navbar-right">
				  <li class="nav-item"><a href="<?php echo e(route('doctors')); ?>"><span class=""></span><button class="btn nobtn blue_color_on_hover">Doctor Consultation</button></a></li>
				  <li class="nav-item"><a href="<?php echo e(route('labtest')); ?>"><span class=""></span><button class="btn nobtn blue_color_on_hover">Lab Test</button></a></li>
				  <li class="nav-item"><a href="<?php echo e(route('epharmacy')); ?>"><span class=""></span><button class="btn nobtn blue_color_on_hover">E-Pharmacy</button></a></li>
				  <li class="nav-item"><a href="<?php echo e(route('health_store')); ?>"><span class=""></span><button class="btn nobtn blue_color_on_hover">Health Store</button></a></li>
				 
				  <li class="nav-item"><a href="<?php echo e(route('cart')); ?>" type="button" class="mt-2 blue_color_border">Cart(<?php echo e(Cart::getContent()->count()); ?>)</a></li>
				  <?php if(session('user')): ?>
				  <li class="nav-item"><a href="<?php echo e(route('user.dashboard')); ?>" type="button"  class="mt-2 blue_color_border">Dashboard</a></li>
				  <?php elseif(session('doctor')): ?>
				  <li class="nav-item"><a href="<?php echo e(route('doctor.dashboard')); ?>" type="button"  class="mt-2 blue_color_border">Dashboard</a></li>
				  <?php elseif(session('store')): ?>
				  <li class="nav-item"><a href="<?php echo e(route('store.dashboard')); ?>" type="button"  class="mt-2 blue_color_border">Dashboard</a></li>
				  <?php else: ?>
				  <li class="nav-item"><button type="button" data-toggle="modal" data-target="#join_popup" class="mt-2 blue_color_border">Login/Signup</button></li>	  
				  <?php endif; ?>
				</ul>       
			  </div>


		  </div>
		</nav>
	  </div>
	</header>


	<!-- Modal -->
	<div class="modal fade" id="join_popup" tabindex="-1" role="dialog" aria-labelledby="join_popupTitle" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered width400" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<h6 class="modal-title" id="ModalLongTitle">Welcome to Diagnomitra</h6>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			  <span aria-hidden="true">&times;</span>
			</button>
		  </div>
		  
		    <nav class="modal-nav">
              <div class="nav nav-tabs" id="nav-tab" role="tablist">
                <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#u1" role="tab" aria-controls="nav-home" aria-selected="true">For User</a>
                <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#u2" role="tab" aria-controls="nav-profile" aria-selected="false">For Doctor</a>
                <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#u3" role="tab" aria-controls="nav-profile" aria-selected="false">Store</a>
              </div>
            </nav>
		  
		  
		  
		  
		    <div class="tab-content" id="nav-tabContent">
              <div class="tab-pane fade show active" id="u1" role="tabpanel" aria-labelledby="nav-home-tab">
                  
                  <!--Login-->
        		  <div class="login_master_img align-center my-4">
        			<img src="<?php echo e(asset('public/front/images/login_infographics.png')); ?>">
        		  </div>
        		  <div class="modal-body sign_up_btn">
        			<div class="login-msg"></div>
        		    <form name="login" >
        			
        			  <div class="form-group row">
        				
        			  <div class="col-sm-12">
        				  <label class="f-12">Enter User's Mobile</label>
        				  <input type="mobile" class="form-control f-12 login-mobile" id="inputEmail3" placeholder="Enter your mobile">
        				</div>
        			  </div>
        
        			  <div class="form-group row">
        				<div class="col-sm-12">
        				  <label class="f-12">Password</label>
        				  <input type="password" class="form-control f-12 login-password" id="inputPassword3" placeholder="Enter Password">
        				</div>
        			  </div>
        				
        			  <div class="col-sm-12 mt-2 align-center login_btn nopadding">
        					<button type="button" class="btn blue_color_bg" id="login-now">Login Now</button>
        			  </div>
        			  
        			</form>
        			
        		  </div>
        		  
        		  <div class="col-sm-12 mb-4 mt-2 align-center">
        		  <span  class="otpbtn"> <a href="enter-otp.php">Login with OTP</a></span>
        			<button class="btn nobtn blue_color_text "><small>Forgot Paswword? <a class="blue_color_text" href="<?php echo e(route('user-forgot-password')); ?>">Click Now</a></small></button>
        			<button class="btn nobtn blue_color_text "><small>Already a member? <a class="blue_color_text" href="<?php echo e(route('register')); ?>">Register Now</a></small></button>
        			
        		  </div>
        		  <!--Login End-->
                  
              </div>
              <div class="tab-pane fade" id="u2" role="tabpanel" aria-labelledby="nav-profile-tab">
                  
                  <!--Login-->
        		  <div class="login_master_img align-center my-4">
        			<img src="<?php echo e(asset('public/front/images/login_infographics.png')); ?>">
        		  </div>
        		  <div class="modal-body sign_up_btn">
        			<div class="doctor-login-msg"></div>
        		    <form name="login" >
        			
        			  <div class="form-group row">
        				
        			  <div class="col-sm-12">
        				  <label class="f-12">Doctor's Mobile</label>
        				  <input type="mobile" class="form-control f-12 doctor-login-mobile" id="inputEmail3" placeholder="Enter your mobile">
        				</div>
        			  </div>
        
        			  <div class="form-group row">
        				<div class="col-sm-12">
        				  <label class="f-12">Password</label>
        				  <input type="password" class="form-control f-12 doctor-login-password" id="inputPassword3" placeholder="Enter Password">
        				</div>
        			  </div>
        				
        			  <div class="col-sm-12 mt-2 align-center login_btn nopadding">
        					<button type="button" class="btn blue_color_bg" id="doctor-login-now">Login Now</button>
        			  </div>
        			  
        			</form>
        			
        		  </div>
        		  
        		  <div class="col-sm-12 mb-4 mt-2 align-center">
        		      <span  class="otpbtn"> <a href="enter-otp.php">Login with OTP</a></span>
				 
					<button class="btn nobtn blue_color_text "><small>Forgot Paswword? <a class="blue_color_text" href="<?php echo e(route('doctor-forgot-password')); ?>">Click Now</a></small></button>
        			<button class="btn nobtn blue_color_text "><small>Already a member? <a class="blue_color_text" href="<?php echo e(route('doctor-register')); ?>">Register Now</a></small></button>
        			
        		  </div>
        		  <!--Login End-->
                  
              </div>
              
              <div class="tab-pane fade" id="u3" role="tabpanel" aria-labelledby="nav-profile-tab">
                  
                  <!--Login-->
        		  <div class="login_master_img align-center my-4">
        			<img src="<?php echo e(asset('public/front/images/login_infographics.png')); ?>">
        		  </div>
        		  <div class="modal-body sign_up_btn">
        			<div class="store-login-msg"></div>
        		    <form name="login" >
        			
        			  <div class="form-group row">
        				
        			  <div class="col-sm-12">
        				  <label class="f-12">Enter Mobile Number</label>
        				  <input type="mobile" class="form-control f-12 store-login-mobile" id="inputEmail3" placeholder="Enter your mobile">
        				</div>
        			  </div>
        
        			  <div class="form-group row">
        				<div class="col-sm-12">
        				  <label class="f-12">Password</label>
        				  <input type="password" class="form-control f-12 store-login-password" id="inputPassword3" placeholder="Enter Password">
        				</div>
        			  </div>
        				
        			  <div class="col-sm-12 mt-2 align-center login_btn nopadding">
        					<button type="button" class="btn blue_color_bg" id="store-login-now">Login Now</button>
        			  </div>
        			  
        			</form>
        			
        		  </div>
        		  
        		  <div class="col-sm-12 mb-4 mt-2 align-center">
        		      <span  class="otpbtn"> <a href="enter-otp.php">Login with OTP</a></span>
				 
					<button class="btn nobtn blue_color_text "><small>Forgot Paswword? <a class="blue_color_text" href="<?php echo e(route('store-forgot-password')); ?>">Click Now</a></small></button>
        			<button class="btn nobtn blue_color_text "><small>Already a member? <a class="blue_color_text" href="<?php echo e(route('store-register')); ?>">Register Now</a></small></button>
        			
        		  </div>
        		  <!--Login End-->
                  
              </div>
            </div>
		  
		  
		  
		  
		  
		</div>
	  </div>
	</div>
	
	<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  
    <script type="text/javascript">
		
	$(document).ready(function() {
		    
        $('#login-now').on('click',function () {
            
            var mobile = $('.login-mobile').val();
            var password = $('.login-password').val();
			var _token = "<?php echo e(csrf_token()); ?>";
			
			$.ajax({
				type: 'post',
				url: "<?php echo e(route('postlogin')); ?>",
				data: {_token:_token,mobile: mobile,password: password},
				success:function(res){
					if(res == '1')
					{
						location.reload();
					}else
					{
						$('.login-msg').html(res);
					}
				}
			})
			return false;			

          });
          
          // doctor login
          
        $('#doctor-login-now').on('click',function () {
            
            var mobile = $('.doctor-login-mobile').val();
            var password = $('.doctor-login-password').val();
			var _token = "<?php echo e(csrf_token()); ?>";
			
			$.ajax({
				type: 'post',
				url: "<?php echo e(route('postdoctorlogin')); ?>",
				data: {_token:_token,mobile: mobile,password: password},
				success:function(res){
					if(res == '1')
					{
						location.reload();
					}else
					{
						$('.doctor-login-msg').html(res);
					}
				}
			})
			return false;			

          });
          
        $('#store-login-now').on('click',function () {
            
            var mobile = $('.store-login-mobile').val();
            var password = $('.store-login-password').val();
			var _token = "<?php echo e(csrf_token()); ?>";
			
			$.ajax({
				type: 'post',
				url: "<?php echo e(route('poststorelogin')); ?>",
				data: {_token:_token,mobile: mobile,password: password},
				success:function(res){
					if(res == '1')
					{
						location.reload();
					}else
					{
						$('.store-login-msg').html(res);
					}
				}
			})
			return false;			

          });
          
          
          
        
    });
		
		
    </script>
    
    
    
    <script type="text/javascript">
  $(function(){
  // mobile menu slide from the left
  $('[data-toggle="slide-collapse"]').on('click', function() {
    $navMenuCont = $($(this).data('target'));
    $navMenuCont.animate({'width':'toggle'}, 280);
  });
})

function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.body.style.backgroundColor = "white";
}
</script><?php /**PATH C:\xampp\htdocs\diagno\resources\views/front/header.blade.php ENDPATH**/ ?>