

<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!--  HOME SLIDER BLOCK  -->

  
    
     
	<section class="footer-widget-area footer-widget-area-bg section-custom-bg" style="background:linear-gradient( rgba(17,17,17,0.9),  rgba(17,17,17,0.9) ), url(&quot;<?php echo e(asset('public/front/')); ?>/images/section_custom_bg.jpg&quot;); background-position: center center;  
	background-repeat: no-repeat;  background-attachment: inherit; background-size: cover;  overflow: hidden; ">
	<div class="container" >
	<div class="row" style="margin-top:50px;margin-bottom:50px">
	<h1 class="text-center" style="color:#fff" >CAREER</h1>
	</div>
	</div>
	</section>
   
 

  <!--  Category -->

  <section class="section-content-block ">
    <div class="container">
      <div class="row">
           <div class="col-md-8 col-sm-8 col-xs-12 g">
          <h2>Life With Demo</h2>
        
           
                    <div class="special-content mt-80 mt-sm-60 mt-xs-40" style="background-color:#efefef; padding:40px;">
                       <h4>There's more to us than meets the eye!</h4>
						<ul class="list-styled"></ul>
						<li>An equal opportunities employer</li>
						<li>Friendly working environment</li>
						<li>Focus on people, process and passion</li>
						<li>On-the-job learning</li>
						<li>Work life Balance</li>
                    </div>
                    
                    
                    
                    
                   
                    <div class="special-content mt-80" style=" padding:40px;">
                        <h2> Current Opening</h2>
                            <ul class="list-unstyled">
                               <li> Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante non
            lobortis posuere</li/>
                            </ul>
                    </div> 
 				<br>
                        <div class="pb-30">
                          <h4>Job Roles</h4>
                                    <ul>
                                        <li>1.  Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante nonlobortis posuere</li>
                                        <li>2. Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante nonlobortis posuere</li>
                                        <li>3. Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante nonlobortis posuere</li>
										<li>4. Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante nonlobortis posuere</li>
                                        <li>5. Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante nonlobortis posuere</li>
                                        <li>6. Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante nonlobortis posuere</li>
										<li>7. Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante nonlobortis posuere</li>
                                        <li>8. Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante nonlobortis posuere</li>
                                        <li>9. Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante nonlobortis posuere</li>
                                    </ul>
                        </div>
						<br>
						<div class="pb-30">
                           <h4>Eligibility:</h4>
                            <ul class="list-unstyled">
                               <li>Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante nonlobortis posuere</li>
                                        <li>Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante nonlobortis posuere</li>
                            </ul>
                        </div>
						<br>
						<div class=" pb-30">
                           <h4>Salary:</h4>
                            <ul class="list-unstyled">
                               <li>Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante nonlobortis posuere</li>
                            </ul>
                        </div>
                        <br>
                
                </div>
                 <div class="col-md-4 col-sm-4 col-xs-12 g">
                     <h2>Apply For Jobs</h2>
                      <form class="appoinment-form margin-top-42">
                <div class="form-group col-md-12">
                  <input id="your_name" class="form-control" placeholder="Your Name" type="text" required=""
                    data-msg="This field is required." />
                </div>
                <div class="form-group col-md-12">
                  <input id="your_email" class="form-control" placeholder="Your Email" type="email" required=""
                    data-msg="This field is required." />
                </div>
                <div class="form-group col-md-12">
                  <input id="your_phone" class="form-control" placeholder="Your Phone" type="text" required=""
                    data-msg="This field is required." />
                </div>
                <div class="form-group col-md-12">
<select class="form-control valid" name="" required="" style="border-style:solid;border-width: 1px;" aria-invalid="false">
                  <option value="Position">Position</option>
				   <option value="Sr.Position">Sr.Position </option>
				    <option value="Team Leader">Team Leader</option>
					 <option value="Sr. Team Leader">Sr. Team Leader</option>
					  <option value="Asst. Floor Manager">Asst. Floor Manager</option>
					   <option value="Floor Manager">Floor Manager</option>
                </select>
                </div>
                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                  <textarea id="textarea_message" class="form-control" rows="3" placeholder="Your Message..."
                    required="" data-msg="This field is required."></textarea>
                </div>
</br>
                <div class="form-group col-md-12 col-sm-12 col-xs-12 text-left">
                  <button id="btn_submit" class="btn btn-theme btn-square wow zoomIn" type="submit">
                   Send
                  </button>
                </div>
              </form>
                     
                 </div>
            
          </div>
          
        <!-- end .col-sm-12  -->
      </div>
    </div>
    <!--  end .container  -->
  </section>
  <!--  end .section-content-block -->

  

  

 <!-- <section class="section-content-block section-secondary-bg">
    <div class="container">
      <div class="row wow fadeInUp">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="appointment-form-wrapper light-layout margin-bottom-24 clearfix theme-custom-no-box-shadow">
            <div class="col-md-4 col-sm-12">
              <div class="appointment-form-heading text-left">
			  
                <h2 class="form-title text-capitalize margin-top-24">
                  GET A Query
                </h2>

                <p>
                  Please fill out the query form and very soon we will
                  contact with you to schedule .
                </p>
              </div>
            </div>

            <div class="col-md-8 col-sm-12">
              <form class="appoinment-form margin-top-42">
                <div class="form-group col-md-4">
                  <input id="your_name" class="form-control" placeholder="Name" type="text" required=""
                    data-msg="This field is required." />
                </div>
                <div class="form-group col-md-4">
                  <input id="your_email" class="form-control" placeholder="Email" type="email" required=""
                    data-msg="This field is required." />
                </div>
                <div class="form-group col-md-4">
                  <input id="your_phone" class="form-control" placeholder="Phone" type="text" required=""
                    data-msg="This field is required." />
                </div>

                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                  <textarea id="textarea_message" class="form-control" rows="3" placeholder="Your Message..."
                    required="" data-msg="This field is required."></textarea>
                </div>

                <div class="form-group col-md-12 col-sm-12 col-xs-12 text-left">
                  <button id="btn_submit" class="btn btn-theme btn-square wow zoomIn" type="submit">
                   Send
                  </button>
                </div>
              </form>
            </div>
          </div>
          <!-- end .appointment-form-wrapper  -->
       <!--  </div>
        <!--  end .col-lg-6 -->
    <!--   </div>
      <!--  end .row  -->
   <!--  </div>
    <!--  end .container -->
 <!--  </section>-->
  <!--  end .appointment-section  -->
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\dm\resources\views/front/career.blade.php ENDPATH**/ ?>