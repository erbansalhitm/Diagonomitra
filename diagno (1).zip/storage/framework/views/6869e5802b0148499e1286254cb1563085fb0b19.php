
<style>
    .animate__fadeInLeft {
    -webkit-animation-name: fadeInLeft;
    animation-name: fadeInLeft;
}
.animate__animated {
    -webkit-animation-duration: 1s;
    animation-duration: 1s;
    -webkit-animation-duration: var(--animate-duration);
    animation-duration: var(--animate-duration);
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
}

.abt-text {
    background-color: #fff;
    box-shadow: 0px 5px 15px 0px rgba(0,0,0,.15);
    transition: background .3s,border .3s,border-radius .3s,box-shadow .3s;
    margin: -60px 0 -60px -120px;
    padding: 80px 60px 70px;
    height: 580px;
}
.animate__fadeInRight {
    -webkit-animation-name: fadeInRight;
    animation-name: fadeInRight;
}
.animate__animated {
    -webkit-animation-duration: 1s;
    animation-duration: 1s;
    -webkit-animation-duration: var(--animate-duration);
    animation-duration: var(--animate-duration);
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
}
</style>
<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main">
    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>About Us</h2>
          <ol>
            <li><a href="<?php echo e(route('/')); ?>">Home</a></li>
            <li>About Us</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Section-3 ======= -->
     <section style="background:#f8f8fb;margin-top:50px;margin-bottom:100px">
     <div class="container">
          <div class="row">
            <div class="section-title">
          <h2>About Us</h2>
        </div>
       </div>
        <div class="row">

          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="well-left">
              <div class="single-well  animate__animated animate__fadeInLeft">
                <a href="#">
                  <img src="<?php echo e(asset('public/front/about/').'/'.$about->image); ?>" alt="" width="100%">
                </a>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="abt-text  animate__animated animate__fadeInRight" style="height:580px !important">
              <h6 style="color:#3EC1D5;">About us</h6>
              <h1><?php echo e($about->title); ?></h1>
              <?php echo $about->content; ?>

                           
            </div> 
          </div>
          <!-- End col-->
        </div>
      </div>
    </section>
   
   

  </main><!-- End #main -->

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\socid\resources\views/front/about.blade.php ENDPATH**/ ?>