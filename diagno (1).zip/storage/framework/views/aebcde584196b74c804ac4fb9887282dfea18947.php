    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    
    <style>
        .quote-imgs-thumbs {
          background: #eee;
          border: 1px solid #ccc;
          border-radius: 0.25rem;
          margin: 1.5rem 0;
          padding: 0.75rem;
        }
        .quote-imgs-thumbs--hidden {
          display: none;
        }
        .img-preview-thumb {
          background: #fff;
          border: 1px solid #777;
          border-radius: 0.25rem;
          box-shadow: 0.125rem 0.125rem 0.0625rem rgba(0, 0, 0, 0.12);
          margin-right: 1rem;
          max-width: 140px;
          padding: 0.25rem;
        }
    </style>
    
    
	 <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    <h1>
    Add Activities
    </h1>
    <ol class="breadcrumb">
    <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="<?php echo e(url('admin/add-activities')); ?>">Add Activities</a></li>
    <li><a href="<?php echo e(url('admin/add-activities')); ?>">Add Activities</a></li>
    </ol>
    </section>
    
    <!-- Main content -->
    <section class="content">
    <div class="row">
    <!-- left column -->
    <div class="col-md-12">
    <!-- general form elements -->
    <div class="box box-primary">
    <div class="box-header with-border">
	
	<?php if(session('success')): ?>
	<div class="alert alert-success">
	<?php echo e(session('success')); ?>

	</div>
	<?php elseif(session('error')): ?>
	<div class="alert alert-danger">
	<?php echo e(session('error')); ?>

	</div>
	<?php endif; ?>
	
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="alert alert-danger">
	<?php echo e($error); ?>

	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <form role="form" method="POST" action ="<?php echo e(url('admin/add-activities')); ?>" enctype="multipart/form-data">
    <div class="box-body">
	<?php echo e(csrf_field()); ?>

	    
    <div class="form-group">
    <label for="exampleInputEmail1">Title</label>
    <input type="text" class="form-control"  id="exampleInputname" name="title" placeholder="Enter Title" required>
    </div>
    
    <div class="form-group">
    <label for="exampleInputEmail1">Image</label>
    <input type="file" class="form-control"  id="exampleInputname" name="image" placeholder="Enter Image" >
    </div>
	
    <div class="input_imagefields_container">
    <label for="exampleInputEmail1">Extra Image</label>
    <div><input class="form-control"  type="file" name="extra_images[]" required>
    <br>
    </div>
    </div><button class="btn btn-sm btn-primary add_moreimage_button">Add More Image</button>

    
    <!-- /.box-body -->
    
    <div class="box-footer">
    <button type="submit" class="btn btn-primary">Submit</button>
    </div>
    </form>
    </div>
    
    
    </div>
    
    </div>
    <!-- /.row -->
    </section>
    <!-- /.content -->
    </div>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
    <script>
    $(document).ready(function() {
    var max_fields_limit      = 10; //set limit for maximum input fields
    var x = 1; //initialize counter for text box
    $('.add_moreimage_button').click(function(e){ //click event on add more fields button having class add_more_button
    e.preventDefault();
    if(x < max_fields_limit){ //check conditions
    x++; //counter increment
    $('.input_imagefields_container').append('<div><input class="form-control" type="file" name="extra_images[]"/><a href="#" class="remove_field" style="margin-left:10px;">Remove</a></div>'); //add input field
    }
    });  
    $('.input_imagefields_container').on("click",".remove_field", function(e){ //user click on remove text links
    e.preventDefault(); $(this).parent('div').remove(); x--;
    })
    });
    </script>
    


    <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    
<?php /**PATH /home/primewe1/public_html/saromc.com/welfares/resources/views/admin/add-activities.blade.php ENDPATH**/ ?>