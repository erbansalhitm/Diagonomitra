<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->


<!-- Mirrored from www.networkroot.in/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 11 Sep 2020 16:15:38 GMT -->
<head>
  <meta charset="UTF-8">
  <meta name="author" content="xxxx">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Demo</title>

  <!-- Favicons -->
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('public/front/')); ?>/img/favicon/apple-touch-icon.html">
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('public/front/')); ?>/img/favicon/favicon-32x32.html">
  <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('public/front/')); ?>/img/favicon/favicon-16x16.html">
  <link rel="manifest" href="<?php echo e(asset('public/front/')); ?>/img/favicon/site.html">
  <link rel="mask-icon" href="<?php echo e(asset('public/front/')); ?>/img/favicon/safari-pinned-tab.html" color="#5bbad5">
  <meta name="msapplication-TileColor" content="#da532c">
  <meta name="theme-color" content="#ffffff">

  <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

  <!-- The styles -->
  <link href="<?php echo e(asset('public/front/')); ?>/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(asset('public/front/')); ?>/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(asset('public/front/')); ?>/css/owl.carousel.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(asset('public/front/')); ?>/css/owl.theme.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(asset('public/front/')); ?>/css/animate.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(asset('public/front/')); ?>/css/venobox.css" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/normalize.css">
  <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/styles.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/style.css">
</head>
<style>

#search {
   
    margin: 5px;
}
#search_text{
    width: 297px;
    padding: 15px 0 15px 20px;
    font-size: 16px;
    font-family: Montserrat, sans-serif;
    border: 2px solid #ffc300;
    height: 45px;
    margin-right: 0;
    color: white;
    outline: none;
    background: #fff;
    float: left;
    box-sizing: border-box;
    transition: all 0.15s;
}

#search_text:focus {
    background: #f1f1f1;
}
#search_button {
    border: 0 none;
    background: #ffc300 url(search.png) center no-repeat;
    width: 85px;
    float: left;
    padding: 0;
    text-align: center;
    height: 45px;
    cursor: pointer;
	color:#000
}

#options a{
    border-left: 0 none;
}
#options&gt;a {
    background-image: url(triangle.png);
    background-position: 85% center;
    background-repeat: no-repeat;
    padding-right: 42px;
}
.subnav {
    visibility: hidden;
    position: absolute;
    top: 110%;
    right: 0;
    width: 200px;
    height: auto;
    opacity: 0;
    transition: all 0.1s;
    background: #232323;
}
.subnav li {
    float: none;
}
.subnav li a {
    border-bottom: 1px solid #2e2e2e;
}
#options:hover .subnav {
    visibility: visible;
    top: 100%;
    opacity: 1;
}

</style>
<body>
  <div id="preloader">
    <span class="margin-bottom"><img src="<?php echo e(asset('public/front/')); ?>/images/loader.gif" alt="Loading......" /></span>
  </div>

  <!--  HEADER STYLE  03-->

  <header class="main-header-2 clearfix" data-sticky_header="true">
    <section class="header-wrapper navgiation-wrapper">
      <div class="main-top-header hidden-sm hidden-xs clearfix">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 text-left">
              <div class="top-bar-link">
                <strong>Contact Us</strong> : +91-000000000
                
              </div>
            </div>

            <div class="col-lg-6 col-md-6 col-sm-6 text-right">
              <div class="top-bar-link">
              
            
            <div class="navbar-contact">
              <div class="top-bar-social ">
                <a href="#">
                  <i class="fa fa-facebook" style="color:#3b5998"></i>
                </a>
                <a href="#">
                  <i class="fa fa-twitter" style="color: #00acee"></i>
                </a>
                <a href="#">
                  <i class="fa fa-google-plus"  style="color:  #db4a39"></i>
                </a>
                <a href="#">
                  <i class="fa fa-instagram"  style="color: #3f729b"></i>
                </a>
                <a href="#">
                  <i class="fa fa-youtube"  style="color: #FF0000"></i>
                </a>
              
            </div>
         
              </div>
            </div>
          </div>
        </div>
      </div>
</div>
    

      <div class="navbar navbar-default">
        <div class="container clearfix">
          <div class="navbar-collapse collapse pull-left">
		   <div class="header-logo ">
                <a href="<?php echo e(route('/')); ?>">
               
				<img src="<?php echo e(asset('public/front/')); ?>/images/logo_1.jpg" width="200px" >
                </a>
              </div></div>
			  <div class="navbar-collapse collapse ">
			   <ul class="pull-right">
			    
 	   <li id="search">
        <form action="" method="get">
            <input type="text" name="search_text" id="search_text" placeholder="Search"/>
            <input type="button" name="search_button" id="search_button" value="search"></a>
        </form>
    </li>
  
			
			
			</ul>
           <ul class="nav navbar-nav pull-left" style="">
              <li class="drop">
                <a href="<?php echo e(route('/')); ?>" title="Home Layout 01" class="">Home</a>
              </li>
              <li>
                <a href="<?php echo e(route('aboutus')); ?>" title="About Us">About Us</a>
              </li>
              <li class="drop">
                <a href="<?php echo e(route('products')); ?>">Products</a>
              </li>
			  <li class="drop">
                <a href="#">Quality</a>
              </li>
              <li class="drop">
                <a href="<?php echo e(route('blogs')); ?>">Blogs</a>
              </li><li class="drop">
                <a href="<?php echo e(route('careers')); ?>">Careers</a>
              </li>
              <li><a href="<?php echo e(route('contactus')); ?>">Contact Us</a></li>
              
            </ul>
    </li>
            </ul>
            <!-- end .nav .navbar-nav  -->
          </div>
           <div class="navbar-header pull-left hidden-lg ">
             
                
             
           
                
            <img src="<?php echo e(asset('public/front/')); ?>/images/logo_1.jpg" style="float:left;width:150px;height:50px" >
           
            
          </div>
           <div class="navbar-header pull-right">
             
                
             
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            
          </div>
        </div>
        <!-- end .container  -->
      </div>
      <!-- end .navbar .navbar-default  -->
    </section>
  </header>
  <!-- end main-header  --><?php /**PATH C:\xampp\htdocs\dm\resources\views/front/header.blade.php ENDPATH**/ ?>