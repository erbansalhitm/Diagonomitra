<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Blog</h2>
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>Blog</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Contact Us Section ======= -->
    <section id="contact-us" class="contact-us">
      <div class="container">

       <div class="section-title">
          <h2>Blog</h2>
        </div>

        <div class="row mt-5">
		<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-lg-4 mt-5 mt-lg-0 " >
				<div class="info">
				<img src="<?php echo e(asset('public/front/blog/').'/'.$blog->image); ?>" width="100%">
				<h4 style="padding-left:0px"><?php echo e($blog->title); ?></h4>
				<a href="<?php echo e(route('blog-detail',$blog->slug)); ?>">Read More</a>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 

        </div>

      </div>
    </section><!-- End Contact Us Section -->

  </main><!-- End #main -->

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\socid\resources\views/front/blog.blade.php ENDPATH**/ ?>