
<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
  <div class="card mt-3">
    <div class="card-header">
        <h6 class="card-title mb-0">Cart (<?php echo e($totalcart); ?> itmes)</h6>
      </div>
      <div class="card-body">
		<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
          <div class="col-6 col-sm-12 col-md-12 col-lg-2 col-xl-2">
            <div class="card">
              <img class="card-img-popular" src="<?php echo e($cart->attributes->image); ?>" alt="Card image cap">
            </div>
          </div>
          <div class="col-6 col-sm-12 col-md-12 col-lg- 10 col-xl-10">
            <div class="bold_text"><?php echo e($cart->name); ?></div>    
            <div class="">
              <small> <s>₹ <?php echo e($cart->attributes->oldprice); ?></s> </small> <b class="f-14">₹ <?php echo e($cart->price); ?></b>
            </div>
			<div class="unit my-2">
				<div class="number">
				  <small>Unit - </small><span class="minus"><i class="fa fa-minus"></i></span><input type="text" value="<?php echo e($cart->quantity); ?>" name="<?php echo e($cart->id); ?>" ><span class="plus"><i class="fa fa-plus"></i></span>
				</div>
			</div>
            <a href="<?php echo e(route('remove-cart',$cart->id)); ?>">Remove</a>
          </div>
          
        </div>
		<hr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
    </div>
    <div class="card-footer float-right">
	 <div class="float-left">
        <a href="<?php echo e(route('clearcart')); ?>" class="alert alert-danger float-left mt-2">Clear Cart</a>
      </div>
      <div class="float-right">
        <h6 class="card-title mb-0">Payable Amount: ₹<?php echo e($total); ?></h6>
        <a class="blue_color_bg float-right mt-2" href="<?php echo e(route('checkout')); ?>">Checkout</a>
      </div>
    </div>
  </div>
</div>

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
      $('.minus').click(function () {
        var $input = $(this).parent().find('input');
        var count = parseInt($input.val()) - 1;
        count = count < 1 ? 1 : count;
        $input.val(count);
		$input.change();
		
		var cartid = $input.attr('name');
		$.ajax({
				type: 'GET',
				url: "<?php echo e(route('updatecartminus')); ?>",
				data: {cartid: cartid},
				success:function(res){
					location.reload(true);
				}
		})
		
        return false;
      });
      $('.plus').click(function () {
        var $input = $(this).parent().find('input');
        $input.val(parseInt($input.val()) + 1);
		$input.change();
		
        var cartid = $input.attr('name');
		$.ajax({
				type: 'GET',
				url: "<?php echo e(route('updatecartplus')); ?>",
				data: {cartid: cartid},
				success:function(res){
					location.reload(true);
				}
		})
        return false;
      });
    });
</script>
<?php /**PATH /home/u769120014/domains/diagnomitra.com/public_html/resources/views/front/cart.blade.php ENDPATH**/ ?>