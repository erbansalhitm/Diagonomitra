
<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-3">
  <div class="row">
    <?php echo $__env->make('doctor.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-sm-9">
      <div class="card px-3 py-3">
      <div class="tab-content" id="v-pills-tabContent">
        <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
          <div class="row">
            <div class="col-sm-6"><h5><b>Enquiry List</b></h5></div>
                <div class="col-sm-12 col-md-12 col-xl-12 col-lg-12">
                    <?php if(session('msg')): ?>
                        <?php echo session('msg'); ?>

                    <?php endif; ?>
                    
                </div>
                
            </div>
            
             <table class="table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Mobile</th>
                    <th>Consulting Mode</th>
                    <th>Date</th>
                    <th>Time Slot</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $enquiry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                  <tr>
                    <td><?php echo e($enq->name); ?></td>
                    <td><?php echo e($enq->mobile); ?></td>
                    <td><?php echo e($enq->mode); ?></td>
                    <td><?php echo e($enq->date); ?></td>
                    <td><?php echo e($enq->time); ?></td>
                    <td><a href="<?php echo e(route('doctor.enquiry-details',$enq->id)); ?>" class="text-info">Details</a> | <a href="<?php echo e(route('doctor.delete-enquiry',$enq->id)); ?>" class="text-danger">Delete</a></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>    
            
        </div>
        
        </div>
        </div>
      </div>
    </div>
  </div>

  <?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH C:\xampp\htdocs\diagno\resources\views/doctor/enquiry-list.blade.php ENDPATH**/ ?>