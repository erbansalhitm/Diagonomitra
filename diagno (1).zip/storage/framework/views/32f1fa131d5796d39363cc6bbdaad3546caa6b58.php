<!DOCTYPE html>
<html lang="en">
<head>
  <title>Diagonomitra</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="stylesheet.css">  
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</head>
<body>
<header>
  <div class="container-fluid">
    <nav class="navbar navbar-default">
      
        <div class="row" style="width: 100%">
          
           <div class="col-10 col-sm-3 col-md-3 col-lg-3 col-xl-3">
              <div class="navbar-header top_white_line">
                <a class="navbar-brand" href="index.html"><img src="images/logo.png"></a>
            </div>
          </div>
          
          <div class="col-lg-9 col-xl-9 mt-2 d-none d-sm-none d-md-none d-lg-block nopadding float-right">        
            <ul class="nav nav-pills navbar-right">
              <li class="nav-item"><a href="#"><span class=""></span><button class="btn nobtn blue_color_on_hover">Doctor Consultation</button></a></li>
              <li class="nav-item"><a href="#"><span class=""></span><button class="btn nobtn blue_color_on_hover">Lab Test</button></a></li>
              <li class="nav-item"><a href="#"><span class=""></span><button class="btn nobtn blue_color_on_hover">E-Pharmacy</button></a></li>
              <li class="nav-item"><a href="#"><span class=""></span><button class="btn nobtn blue_color_on_hover">Health Store</button></a></li>
              <li class="nav-item dropdown show">
                <a class="nav-item nav-link dropdown-toggle mr-md-2" href="#" id="bd-versions" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                  Jaipur
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="bd-versions">
                  <a class="dropdown-item" href="#">Bikaner</a>
                  <a class="dropdown-item" href="#">Delhi</a>
                  <a class="dropdown-item" href="#">Pune</a>
                </div>
              </li>
              <!-- <li class="nav-item"><a href="#"><span class=""></span><button class="btn nobtn">Login</button></a></li> -->
              <li class="nav-item"><button type="button" data-toggle="modal" data-target="#join_popup" class="mt-2 blue_color_border">Login/Signup</button></li>
            </ul>       
          </div>


      </div>
    </nav>
  </div>
</header>




<!-- Modal -->
<div class="modal fade" id="join_popup" tabindex="-1" role="dialog" aria-labelledby="join_popupTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered width400" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="ModalLongTitle">Join</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body sign_up_btn">
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
          <label class="form-check-label" for="inlineRadio1"><small class="light_color_text">Contributor</small></label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
          <label class="form-check-label" for="inlineRadio2"><small class="light_color_text">Mentor</small></label>
        </div>
        <button type="button" class="btn mt-4 signup_twitter" style="background-color: #00acee; color:#fff"><span><img src="images/twitter.png"></span> Continue With Twitter</button>
        <button type="button" class="btn mt-4 signup_github" style="background-color: #1074e7; color:#fff"><span><img src="images/github.png"></span>Continue With GitHub</button>
        <button type="button" class=" mt-4 light_color_bg signup_google"><span><img src="images/google.png">Continue With Google</button>

        
        <hr class="mt-4">
      
        <form class="mt-4">
          <div class="form-group row">
            
            <div class="col-sm-12">
              <input type="email" class="form-control" id="inputEmail3" placeholder="Email">
            </div>
          </div>
          <div class="form-group row">
            <div class="col-sm-12">
              <input type="password" class="form-control" id="inputPassword3" placeholder="Password">
            </div>
          </div>
          <div class="col-sm-12 nopadding">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" id="autoSizingCheck2">
                <label class="form-check-label" for="autoSizingCheck2">
                  <small class="light_color_text">Remember me</small>
                </label>
              </div>
            </div>         
        </form>
      </div>
      
      
      <div class="col-sm-12 mb-4 mt-4">
        <button class="btn nobtn blue_color_text"><small>Forget Password?</small></button>
        <button type="button" class="btn blue_color_bg float-right">Continue</button>
      </div>
    </div>
  </div>
</div>


  <div class="container-fluid nopadding">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <!-- <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
      </ol> -->

      <!-- Wrapper for slides -->
      <div class="carousel-inner">
        <div class="top_image_item">
          <div class="col-12 nopadding">
            <img class="d-none d-sm-none d-md-block" src="images/master_banner.png" alt="business" style="width:100%;">
            <img class=".d-none d-sm-block d-md-none d-xl-none d-lg-none" src="images/master_banner_mobile.png" alt="business" style="width:100%;">
            
              
              <!-- <img src="images/master_banner.png" alt="" style="width:100%;"> -->
            
          </div>
        </div>
      </div>

      <!-- Left and right controls
      <a class="left carousel-control" href="#myCarousel" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
        <span class="sr-only">Next</span>
      </a> -->
    </div>
  </div>
  <div class="container">
    <div id="video-multi-item" class="video_card" data-ride="carousel" data-interval="false">
      <div class="row mt-5">
        <div class="heading_section mb-4">
          <div class="col-md-12"><h6><b>Top Services</b></h6></div>
          
        </div>
      </div>
      <div class="row">
            <div class="col-md-3">
              <div class="card mb-2">
                <img src="images/categories_1.png">
                <div class="card-body">
                  
                                      
                    <div class="row">
                      <div class="col-12">
                      <small class="card-text gradient_text">Doctor Consultation</small>
                      <button type="button" class="float-right blue_color_border btn-group-sm">Consult Now</button>
                    </div>
                  </div>
                                   
                </div>
              </div>
            </div>

            <div class="col-md-3 clearfix d-none d-md-block">
              <div class="card mb-2">
                <img src="images/categories_2.png">
                <div class="card-body">
                                      
                    <div class="row">
                      <div class="col-12">
                      <small class="card-text gradient_text">Lab Test</small>
                      <button type="button" class="float-right blue_color_border btn-group-sm">Book Now</button>
                    </div>
                  </div>                 
                </div>
              </div>
            </div>

            <div class="col-md-3 clearfix d-none d-md-block">
              <div class="card mb-2">
                <img src="images/categories_3.png">
                <div class="card-body">
                                      
                    <div class="row">
                      <div class="col-12">
                        <small class="card-text gradient_text">E-Pharmacy</small>
                      <button type="button" class="float-right blue_color_border btn-group-sm">Shop Now</button>
                    </div>
                  </div>                 
                </div>
              </div>
            </div>

            <div class="col-md-3 clearfix d-none d-md-block">
              <div class="card mb-2">
                <img src="images/categories_4.png">
                <div class="card-body">
                                      
                    <div class="row">
                      <div class="col-12">
                      <small class="card-text gradient_text">Health Store</small>
                      <button type="button" class="float-right blue_color_border btn-group-sm">Shop Now</button>
                    </div>
                  </div>                 
                </div>
              </div>
            </div>
          </div>
    </div>
  </div>
  

  <div class="container my-4">

    <!--Carousel Wrapper-->
    <div id="product-item" class="carousel slide carousel-multi-item" data-ride="carousel" data-interval="false">

      <!--Controls-->
      <div class="controls-top">
        <a class="btn-floating left" href="#product-item" data-slide="prev"><i class="fa fa-chevron-left"></i></a>
        <a class="btn-floating right" href="#product-item" data-slide="next"><i class="fa fa-chevron-right"></i></a>
      </div>
      <!--/.Controls-->
      <div class="row mt-5">
        <div class="heading_section mb-4">
          <div class="col-md-9"><h6><b>Consult top verified doctors with all specialists </b></h6></div>
          <div class="col-md-3"><a href="spesilities.html" class="float-right blue_color_border">View All</a></div>
        </div>
      </div>

      <!--Slides-->
      <div class="carousel-inner popular" role="listbox">
        

        <!--First slide-->
        <div class="carousel-item active">

          <div class="row">
            <div class="col-md-3 col-8 col-xl-3 col-lg-3">
              <div class="mb-2">
                <img class="card-img-popular" src="images/specialists_1.png" alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dietitian</div>
                  <div class="line_height_1 grey_text"><small>PCOD, Weight Loss, Weight Gain, Diabetes, High BP</small></div>
                </div>
              </div>
            </div>

            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/specialists_2.png"
                  alt="Card image cap">
                <div class="product_text">
                  
                  <div class="bold_text">General Physician</div>
                  <div class="line_height_1 grey_text"><small>Fever, Stomach Issues, Vomiting, ACough, Headache/Migraine</small></div>
                </div>
              </div>
            </div>

            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/specialists_3.png"
                  alt="Card image cap">
                <div class="product_text">
                  
                  <div class="bold_text">Gastroenterologist</div>
                  <div class="line_height_1 grey_text"><small>Constipation, Stomach/Abdominal Pains, Vomiting, Acidity/Gas, Diarrhea</small></div>
                </div>
              </div>
            </div>
            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/specialists_4.png"
                  alt="Card image cap">
                <div class="product_text">
                  
                  <div class="bold_text">Dietitian</div>
                  <div class="line_height_1 grey_text"><small>PCOD, Weight Loss, Weight Gain, Diabetes, High BP</small></div>
                </div>
              </div>
            </div>
          </div>

        </div>
        <!--/.First slide-->
        <!--First slide-->

        <div class="carousel-item">

          <div class="row">
            <div class="col-md-3 col-8 col-xl-3 col-lg-3">
              <div class="mb-2">
                <img class="card-img-popular" src="images/specialists_1.png" alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dietitian</div>
                  <div class="line_height_1 grey_text"><small>PCOD, Weight Loss, Weight Gain, Diabetes, High BP</small></div>
                </div>
              </div>
            </div>

            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/specialists_2.png"
                  alt="Card image cap">
                <div class="product_text">
                  
                  <div class="bold_text">General Physician</div>
                  <div class="line_height_1 grey_text"><small>Fever, Stomach Issues, Vomiting, ACough, Headache/Migraine</small></div>
                </div>
              </div>
            </div>

            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/specialists_3.png"
                  alt="Card image cap">
                <div class="product_text">
                  
                  <div class="bold_text">Gastroenterologist</div>
                  <div class="line_height_1 grey_text"><small>Constipation, Stomach/Abdominal Pains, Vomiting, Acidity/Gas, Diarrhea</small></div>
                </div>
              </div>
            </div>
            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/specialists_4.png"
                  alt="Card image cap">
                <div class="product_text">
                  
                  <div class="bold_text">Dietitian</div>
                  <div class="line_height_1 grey_text"><small>PCOD, Weight Loss, Weight Gain, Diabetes, High BP</small></div>
                </div>
              </div>
            </div>
          </div>

        </div>
        <div class="carousel-item ">

          <div class="row">
            <div class="col-md-3 col-8 col-xl-3 col-lg-3">
              <div class="mb-2">
                <img class="card-img-popular" src="images/specialists_1.png" alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dietitian</div>
                  <div class="line_height_1 grey_text"><small>PCOD, Weight Loss, Weight Gain, Diabetes, High BP</small></div>
                </div>
              </div>
            </div>

            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/specialists_2.png"
                  alt="Card image cap">
                <div class="product_text">
                  
                  <div class="bold_text">General Physician</div>
                  <div class="line_height_1 grey_text"><small>Fever, Stomach Issues, Vomiting, ACough, Headache/Migraine</small></div>
                </div>
              </div>
            </div>

            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/specialists_3.png"
                  alt="Card image cap">
                <div class="product_text">
                  
                  <div class="bold_text">Gastroenterologist</div>
                  <div class="line_height_1 grey_text"><small>Constipation, Stomach/Abdominal Pains, Vomiting, Acidity/Gas, Diarrhea</small></div>
                </div>
              </div>
            </div>
            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/specialists_4.png"
                  alt="Card image cap">
                <div class="product_text">
                  
                  <div class="bold_text">Dietitian</div>
                  <div class="line_height_1 grey_text"><small>PCOD, Weight Loss, Weight Gain, Diabetes, High BP</small></div>
                </div>
              </div>
            </div>
          </div>

        </div>
       

      </div>
      <!--/.Slides-->

    </div>
    <!--/.Carousel Wrapper-->


  </div>

    
<div class="container my-4">
  <div class="row">

    <!--Carousel Wrapper-->
    <div id="doctors" class="carousel slide carousel-multi-item" data-ride="carousel" data-interval="false">

      <!--Controls-->
      <div class="controls-top">
        <a class="btn-floating left" href="#doctors" data-slide="prev"><i class="fa fa-chevron-left"></i></a>
        <a class="btn-floating right" href="#doctors" data-slide="next"><i class="fa fa-chevron-right"></i></a>
      </div>
      <!--/.Controls-->
      <div class="row mt-5">
        <div class="heading_section mb-4">
          <div class="col-md-9"><h6><b>Top Doctors in you City</b></h6></div>
          <div class="col-md-3"><a href="#" class="float-right blue_color_border" href="#">View All</a></div>
        </div>
      </div>

      <!--Slides-->
      <div class="carousel-inner popular" role="listbox">
        

        <!--First slide-->
        <div class="carousel-item active">

          <div class="row">
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_1.png" alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr. Raj Kapoor</div>
                  <div><small>General Physician</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_2.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr. Vidita Swami</div>
                  <div><small>Gastroenterologist</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_3.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr, Rakesh Jain</div>
                  <div><small>General Physician</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_4.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr. Kalpita Rao</div>
                  <div><small>Gastroenterologist</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_5.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr. Dheeaj Kumar</div>
                  <div><small>General Physician</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_1.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr. Dheeaj Kumar</div>
                  <div><small>Gastroenterologist</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>
          </div>

        </div>
        <!--/.First slide-->
        <div class="carousel-item">

          <div class="row">
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_1.png" alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr. Raj Kapoor</div>
                  <div><small>General Physician</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_2.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr. Vidita Swami</div>
                  <div><small>General Physician</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_3.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr, Rakesh Jain</div>
                  <div><small>General Physician</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_4.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr. Kalpita Rao</div>
                  <div><small>General Physician</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_5.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr. Dheeaj Kumar</div>
                  <div><small>General Physician</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_1.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr. Dheeaj Kumar</div>
                  <div><small>General Physician</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>
          </div>

        </div>

        <div class="carousel-item">

          <div class="row">
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_1.png" alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr. Raj Kapoor</div>
                  <div><small>General Physician</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_2.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr. Vidita Swami</div>
                  <div><small>General Physician</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_3.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr, Rakesh Jain</div>
                  <div><small>General Physician</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_4.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr. Kalpita Rao</div>
                  <div><small>General Physician</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_5.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr. Dheeaj Kumar</div>
                  <div><small>General Physician</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/doctors_1.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Dr. Dheeaj Kumar</div>
                  <div><small>General Physician</small></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Consult Now</button>
                </div>
              </div>
            </div>
          </div>

        </div>

       

      </div>
      <!--/.Slides-->

    </div>
    <!--/.Carousel Wrapper-->
  </div>

</div>
    


<div class="container my-4">
  <div class="row">

    <!--Carousel Wrapper-->
    <div id="Lab_test" class="carousel slide carousel-multi-item" data-ride="carousel" data-interval="false">

      <!--Controls-->
      <div class="controls-top">
        <a class="btn-floating left" href="#Lab_test" data-slide="prev"><i class="fa fa-chevron-left"></i></a>
        <a class="btn-floating right" href="#Lab_test" data-slide="next"><i class="fa fa-chevron-right"></i></a>
      </div>
      <!--/.Controls-->
      <div class="row mt-5">
        <div class="heading_section mb-4">
          <div class="col-md-9"><h6><b>Lab Test</b></h6></div>
          <div class="col-md-3"><a href="labtest.html" class="float-right blue_color_border" href="#">View All</a></div>
        </div>
      </div>

      <!--Slides-->
      <div class="carousel-inner popular" role="listbox">
        

        <!--First slide-->
        <div class="carousel-item active">

          <div class="row">
            <div class="col-md-3 col-8 col-xl-3 col-lg-3">
              <div class="mb-2">
                <img class="card-img-popular" src="images/lab_1.png" alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Advance Diabetes Care</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/lab_2.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Basic Allergy</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/lab_3.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Basic Antenatal Care</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/lab_4.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Bone Strength</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
          </div>

        </div>
        <!--/.First slide-->
        <div class="carousel-item ">

          <div class="row">
            <div class="col-md-3 col-8 col-xl-3 col-lg-3">
              <div class="mb-2">
                <img class="card-img-popular" src="images/lab_1.png" alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Advance Diabetes Care</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/lab_2.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Basic Allergy</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/lab_3.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Basic Antenatal Care</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/lab_4.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Bone Strength</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
          </div>

        </div>

        <div class="carousel-item ">

          <div class="row">
            <div class="col-md-3 col-8 col-xl-3 col-lg-3">
              <div class="mb-2">
                <img class="card-img-popular" src="images/lab_1.png" alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Advance Diabetes Care</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/lab_2.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Basic Allergy</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/lab_3.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Basic Antenatal Care</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-md-3 col-8 col-xl-3 col-lg-3 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/lab_4.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Bone Strength</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
          </div>

        </div>

       

      </div>
      <!--/.Slides-->

    </div>
    <!--/.Carousel Wrapper-->
  </div>

</div>

<div class="container my-4">
  <div class="row">

    <!--Carousel Wrapper-->
    <div id="E-Pharmacy" class="carousel slide carousel-multi-item" data-ride="carousel" data-interval="false">

      <!--Controls-->
      <div class="controls-top">
        <a class="btn-floating left" href="#E-Pharmacy" data-slide="prev"><i class="fa fa-chevron-left"></i></a>
        <a class="btn-floating right" href="#E-Pharmacy" data-slide="next"><i class="fa fa-chevron-right"></i></a>
      </div>
      <!--/.Controls-->
      <div class="row mt-5">
        <div class="heading_section mb-4">
          <div class="col-md-9"><h6><b>E-Pharmacy</b></h6></div>
          <div class="col-md-3"><a class="float-right blue_color_border" href="epharmacy.html">View All</a></div>
        </div>
      </div>

      <!--Slides-->
      <div class="carousel-inner popular" role="listbox">
        

        <!--First slide-->
        <div class="carousel-item active">

          <div class="row">
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_1.png" alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_2.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_3.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_4.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_5.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_1.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
          </div>

        </div>
        <!--/.First slide-->
        <div class="carousel-item">

          <div class="row">
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_1.png" alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_2.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_3.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_4.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_5.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_1.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
          </div>

        </div>

        <div class="carousel-item">

          <div class="row">
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_1.png" alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_2.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_3.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_4.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_5.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/pharma_1.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Seroflow Inhailer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
          </div>

        </div>
        

        

       

      </div>
      <!--/.Slides-->

    </div>
    <!--/.Carousel Wrapper-->
  </div>

</div>


<div class="container my-4">
  <div class="row">

    <!--Carousel Wrapper-->
    <div id="health_store" class="carousel slide carousel-multi-item" data-ride="carousel" data-interval="false">

      <!--Controls-->
      <div class="controls-top">
        <a class="btn-floating left" href="#health_store" data-slide="prev"><i class="fa fa-chevron-left"></i></a>
        <a class="btn-floating right" href="#health_store" data-slide="next"><i class="fa fa-chevron-right"></i></a>
      </div>
      <!--/.Controls-->
      <div class="row mt-5">
        <div class="heading_section mb-4">
          <div class="col-md-9"><h6><b>Health Store</b></h6></div>
          <div class="col-md-3"><a class="float-right blue_color_border" href="health_store.html">View All</a></div>
        </div>
      </div>

      <!--Slides-->
      <div class="carousel-inner popular" role="listbox">
        

        <!--First slide-->
        <div class="carousel-item active">

          <div class="row">
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_1.png" alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_2.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_3.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_4.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_5.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_1.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
          </div>

        </div>
        <!--/.First slide-->
        <div class="carousel-item">

          <div class="row">
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_1.png" alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_2.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_3.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_4.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_5.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_1.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
          </div>

        </div>

        <div class="carousel-item">

          <div class="row">
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_1.png" alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_2.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>

            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_3.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_4.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_5.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 clearfix d-none d-md-block">
              <div class="mb-2">
                <img class="card-img-popular" src="images/hs_1.png"
                  alt="Card image cap">
                <div class="product_text">
                  <div class="bold_text">Thermometer</div>
                  <div><small> <s>₹ 299</s> </small> <b class="f-14">499</b></div>
                  <button style="width:100%;" type="button" data-toggle="modal" class="mt-2 blue_color_border">Add to cart</button>
                  
                </div>
              </div>
            </div>
          </div>

        </div>
        

        

       

      </div>
      <!--/.Slides-->

    </div>
    <!--/.Carousel Wrapper-->
  </div>

</div>

<div class="container my-4">
  <div class="row ">

    <!--Carousel Wrapper-->
    <div id="customers" class="carousel slide carousel-multi-item m-auto" data-ride="carousel" data-interval="false">

      <!--Controls-->
      <div class="controls-top">
        <a class="btn-floating left" href="#customers" data-slide="prev"><i class="fa fa-chevron-left"></i></a>
        <a class="btn-floating right" href="#customers" data-slide="next"><i class="fa fa-chevron-right"></i></a>
      </div>
      <!--/.Controls-->
      <div class="row mt-5">
        <div class="heading_section mb-4">
          <div class="col-md-12"><h4 class="align-center mb-5"><b>What Our Customers Say?</b></h4></div>
        </div>
      </div>

      <!--Slides-->
      <div class="carousel-inner popular" role="listbox">
        

        <!--First slide-->
        <div class="carousel-item active">

          <div class="row">
            <div class="col-md-4 col-8 col-xl-4 col-lg-4">
              <div class="mb-2 align-center"><img class="customer_profile" src="images/profile_1.png"></div>
              <div class="mb-2 align-center">
                
                <div class="">
                  
                  <div class="rating">
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star"></span>
                    <span class="fa fa-star"></span>
                  </div>
                <div class="product_text">
                  <div><small>Diagnomitra give the qualitative  doctor consultancy with doctors  online and the doctors are the  best they give valuable advice.</small></div>
                  <h6 class="mt-3"><b>Tushar Taneja</b></h6>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-8 col-xl-4 col-lg-4 clearfix d-none d-md-block">
              <div class="mb-2 align-center"><img class="customer_profile" src="images/profile_2.png"></div>
              <div class="mb-2 align-center">
                
                <div class="">
                  
                  <div class="rating">
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star"></span>
                    <span class="fa fa-star"></span>
                  </div>
                <div class="product_text">
                  
                  <div><small>Diagnomitra give the qualitative  doctor consultancy with doctors  online and the doctors are the  best they give valuable advice.</small></div>
                  <h6 class="mt-3"><b>Tushar Taneja</b></h6>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-8 col-xl-4 col-lg-4 clearfix d-none d-md-block">
              <div class="mb-2 align-center"><img class="customer_profile" src="images/profile_3.png"></div>
              <div class="mb-2 align-center">
                
                <div class="">
                  
                  <div class="rating">
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star"></span>
                    <span class="fa fa-star"></span>
                  </div>
                <div class="product_text">
                  <div><small>Diagnomitra give the qualitative  doctor consultancy with doctors  online and the doctors are the  best they give valuable advice.</small></div>
                  <h6 class="mt-3"><b>Tushar Taneja</b></h6>
                  </div>
                </div>
              </div>
            </div>
            
          </div>

        </div>
        <!--/.First slide-->
       <div class="carousel-item">

          <div class="row">
            <div class="col-md-4 col-8 col-xl-4 col-lg-4">
              <div class="mb-2 align-center"><img class="customer_profile" src="images/profile_1.png"></div>
              <div class="mb-2 align-center">
                
                <div class="">
                  
                  <div class="rating">
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star"></span>
                    <span class="fa fa-star"></span>
                  </div>
                <div class="product_text">
                  <div><small>Diagnomitra give the qualitative  doctor consultancy with doctors  online and the doctors are the  best they give valuable advice.</small></div>
                  <h6 class="mt-3"><b>Tushar Taneja</b></h6>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-8 col-xl-4 col-lg-4 clearfix d-none d-md-block">
              <div class="mb-2 align-center"><img class="customer_profile" src="images/profile_2.png"></div>
              <div class="mb-2 align-center">
                
                <div class="">
                  
                  <div class="rating">
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star"></span>
                    <span class="fa fa-star"></span>
                  </div>
                <div class="product_text">
                  
                  <div><small>Diagnomitra give the qualitative  doctor consultancy with doctors  online and the doctors are the  best they give valuable advice.</small></div>
                  <h6 class="mt-3"><b>Tushar Taneja</b></h6>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-8 col-xl-4 col-lg-4 clearfix d-none d-md-block">
              <div class="mb-2 align-center"><img class="customer_profile" src="images/profile_3.png"></div>
              <div class="mb-2 align-center">
                
                <div class="">
                  
                  <div class="rating">
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star"></span>
                    <span class="fa fa-star"></span>
                  </div>
                <div class="product_text">
                  <div><small>Diagnomitra give the qualitative  doctor consultancy with doctors  online and the doctors are the  best they give valuable advice.</small></div>
                  <h6 class="mt-3"><b>Tushar Taneja</b></h6>
                  </div>
                </div>
              </div>
            </div>
            
          </div>

        </div>
        <div class="carousel-item">

          <div class="row">
            <div class="col-md-4 col-8 col-xl-4 col-lg-4">
              <div class="mb-2 align-center"><img class="customer_profile" src="images/profile_1.png"></div>
              <div class="mb-2 align-center">
                
                <div class="">
                  
                  <div class="rating">
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star"></span>
                    <span class="fa fa-star"></span>
                  </div>
                <div class="product_text">
                  <div><small>Diagnomitra give the qualitative  doctor consultancy with doctors  online and the doctors are the  best they give valuable advice.</small></div>
                  <h6 class="mt-3"><b>Tushar Taneja</b></h6>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-8 col-xl-4 col-lg-4 clearfix d-none d-md-block">
              <div class="mb-2 align-center"><img class="customer_profile" src="images/profile_2.png"></div>
              <div class="mb-2 align-center">
                
                <div class="">
                  
                  <div class="rating">
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star"></span>
                    <span class="fa fa-star"></span>
                  </div>
                <div class="product_text">
                  
                  <div><small>Diagnomitra give the qualitative  doctor consultancy with doctors  online and the doctors are the  best they give valuable advice.</small></div>
                  <h6 class="mt-3"><b>Tushar Taneja</b></h6>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-8 col-xl-4 col-lg-4 clearfix d-none d-md-block">
              <div class="mb-2 align-center"><img class="customer_profile" src="images/profile_3.png"></div>
              <div class="mb-2 align-center">
                
                <div class="">
                  
                  <div class="rating">
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star"></span>
                    <span class="fa fa-star"></span>
                  </div>
                <div class="product_text">
                  <div><small>Diagnomitra give the qualitative  doctor consultancy with doctors  online and the doctors are the  best they give valuable advice.</small></div>
                  <h6 class="mt-3"><b>Tushar Taneja</b></h6>
                  </div>
                </div>
              </div>
            </div>
            
          </div>

        </div>

       

      </div>
      <!--/.Slides-->

    </div>
    <!--/.Carousel Wrapper-->
  </div>

</div>

  <footer class="mt-4 d-none d-sm-none d-md-block">
    <div class="container">
      <div class="row">
        <div class="footer_link">
        <div class="col-sm-3">
          <h4>SPECIALISATIONS</h4>
          <ul>
            <li><a href="#">Orthopedician</a></li>
            <li><a href="#">Dermatologist</a></li>
            <li><a href="#">Pediatrician</a></li>
            <li><a href="#">General Physician</a></li>
            <li><a href="#">General Surgeon</a></li>
            <li><a href="#">Cardiologist</a></li>
            <li><a href="">Dietitian</a></li>
            <li><a href="">Pulmonologist</a></li>
            <li><a href="">Gynecologist</a></li>
            <li><a href="">View All ></a></li> 
          </ul>
        </div>
        <div class="col-sm-3">
          <h4>ABOUT</h4>
          <ul>
            <li><a href="#"> How it Works</a></li>
            <li><a href="#"> Press & News</a></li>
            <li><a href="#"> Privacy Policy</a></li>
            <li><a href="#"> Terms of Service</a></li>
          </ul>
        </div>
        <div class="col-sm-3">
          <h4>SUPPORT</h4>
          <ul>
            <li><a href="#"> Support</a></li>
            <li><a href="#"> Help & Support</a></li>
            <li><a href="#"> Trust & Safety</a></li>
          </ul>
        </div>
        <div class="col-sm-3">
          <h4>Community</h4>
          <ul>
            <li><a href="#"> Blog</a></li>
            <li><a href="#"> Forum</a></li>
            <li><a href="#"> Community Standards</a></li>
            <li><a href="#"> Invite a Friend</a></li>
            <li><a href="#"> Become a Seller</a></li>
          </ul>
        </div>
        </div>
      </div>

      <hr class="mt-4">
      <div class="row">
        <div class="footer_logo col-12 col-sm-6">
          <div class="col col-sm-4 nopadding">
            <img src="images/logo_grey.png">                        
          </div>
          <div class="copy_right col col-sm-8  mt-3">
            <small>© Diagonomitra Ltd. 2020</small>
          </div>
        </div>
        <div class="col-12 col-sm-6">
          <div class="footer_sm_links float-right">
            <ul>
              <li><a href="#"><img src="images/tiktok.png"></a></li>
              <li><a href="#"><img src="images/youtube.png"></a></li>
              <li><a href="#"><img src="images/twitter.png"></a></li>
              <li><a href="#"><img src="images/fb.png"></a></li>
              <li><a href="#"><img src="images/insta.png"></a></li>
              <li><a href="#"><img src="images/linkedin.png"></a></li>
            </ul>
          
          </div>
        </div>

      </div>
    </div>
  </footer>

  
</body>
</html>
<script type="text/javascript">
  $('#product-item').carousel({
  interval: 3000,
  cycle: true
}); 
  $('#doctors').carousel({
  interval: 4000,
  cycle: true
}); 
  $('#Lab_test').carousel({
  interval: 5000,
  cycle: true
});
  $('#E-Pharmacy').carousel({
  interval: 3500,
  cycle: true
});
  $('#health_store').carousel({
  interval: 3600,
  cycle: true
});
  $('#customers').carousel({
  interval: 2500,
  cycle: true
});
  
                
</script><?php /**PATH C:\xampp\htdocs\html\resources\views/front/index.blade.php ENDPATH**/ ?>