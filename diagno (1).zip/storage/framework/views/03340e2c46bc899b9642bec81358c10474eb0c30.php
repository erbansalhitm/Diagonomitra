
<style>
    
   
    .plus-minus-input {
  align-items: center;

  .input-group-field {
    text-align: center;
    margin-left: 0.5rem;
    margin-right: 0.5rem;
    padding: 1rem;

    &::-webkit-inner-spin-button,
    ::-webkit-outer-spin-button {
      appearance: none;
    }
  }

  .input-group-button {
    .circle {
      border-radius: 50%;
      padding: 0.25em 0.8em;
    }
  }
}

.plus-minus-input {
  -webkit-align-items: center;
      -ms-flex-align: center;
          align-items: center;
}

.plus-minus-input .input-group-field {
  text-align: center;
  margin-left: 0.5rem;
  margin-right: 0.5rem;
  padding: 1rem;
}

.plus-minus-input .input-group-field::-webkit-inner-spin-button,
.plus-minus-input .input-group-field ::-webkit-outer-spin-button {
  -webkit-appearance: none;
          appearance: none;
}

.plus-minus-input .input-group-button .circle {
  border-radius: 50%;
  padding: 0.25em 0.8em;
}



</style>

<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <section class="page-title" style="background-image:url(<?php echo e(asset('public/front/')); ?>/images/background/bg-page-title-1.jpg);">
        <div class="auto-container">
            <h1>Shop</h1>
            <div class="bread-crumb-outer">
                <ul class="bread-crumb clearfix">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="active">Cart</li>
                </ul>
            </div>
        </div>
    </section>
    
    <section>
        
        <main class="ps-main">
            
            
      <div class="container-fluid">
		        <div class="ps-cart-listing">
		
          <div class="table-responsive">
              
              
            <table class="table ps-table ps-table--listing">
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Price</th>
                  <th>Quantity</th>
                  <th>Total</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
			   <?php $__currentLoopData = \Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  	<tr>
                  <td><a class="ps-product--table" href="#"><img class="mr-15" src="<?php echo e(asset('public/front/product/').'/'.$item->attributes->image); ?>" alt=""><?php echo e($item->name); ?></a>
				  </td>
                  <td><i class="fa fa-inr"></i><?php echo e($item->price); ?></td>
                  
                  
                  <td>
                    <div class="form-group--number">
						<button type="button" class="minus subtracking" data-quantity="minus" data-field="quantity">
						<i class="fa fa-minus" aria-hidden="true"></i>
						</button>

						<input class="form-control" title="217" type="text"  name="quantity" value="<?php echo e($item->quantity); ?>">

						<button type="button" class="plus adding" data-quantity="plus" data-field="quantity">
						<i class="fa fa-plus" aria-hidden="true"></i>
						</button>
                     
                    </div>
                  </td>
                  <td><strong> <i class="fa fa-inr"></i>  <?php echo e($item->price*$item->quantity); ?></strong></td>
                  <td>
                    <a href="<?php echo e(route('cartremove',$item->id)); ?>">X<div class="ps-remove"></div>
                  </a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>				   
              </tbody>
            </table>
          </div>
		 
          <div class="ps-cart__actions">
            <div class="ps-cart__total">
                <h3>Total Price: <span> <i class="fa fa-inr"></i><?php echo e(\Cart::getSubTotal()); ?></span></h3>
              
                <a class="ps-btn" href="<?php echo e(route('checkout')); ?>" >Process to checkout</a>
                              
              <a class="ps-btn" href="<?php echo e(route('clearcart')); ?>">Clear Cart</a>
            </div>
          </div>
          
        </div>
			
      </div>
    </main>
    </section>
    
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
<script>jQuery(document).ready(function(){
    // This button will increment the value
    $('[data-quantity="plus"]').click(function(e){
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        fieldName = $(this).attr('data-field');
        // Get its current value
        var currentVal = parseInt($('input[name='+fieldName+']').val());
        // If is not undefined
        if (!isNaN(currentVal)) {
            // Increment
            $('input[name='+fieldName+']').val(currentVal + 1);
        } else {
            // Otherwise put a 0 there
            $('input[name='+fieldName+']').val(0);
        }
    });
    // This button will decrement the value till 0
    $('[data-quantity="minus"]').click(function(e) {
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        fieldName = $(this).attr('data-field');
        // Get its current value
        var currentVal = parseInt($('input[name='+fieldName+']').val());
        // If it isn't undefined or its greater than 0
        if (!isNaN(currentVal) && currentVal > 0) {
            // Decrement one
            $('input[name='+fieldName+']').val(currentVal - 1);
        } else {
            // Otherwise put a 0 there
            $('input[name='+fieldName+']').val(0);
        }
    });
});

</script>
<?php /**PATH C:\xampp\htdocs\welfair\resources\views/front/cart.blade.php ENDPATH**/ ?>