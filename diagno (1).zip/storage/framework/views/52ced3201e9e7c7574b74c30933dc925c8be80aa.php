

<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!--  HOME SLIDER BLOCK  -->

  
    
     
     <section class="footer-widget-area footer-widget-area-bg section-custom-bg" style="background:linear-gradient( rgba(17,17,17,0.9),  rgba(17,17,17,0.9) ), url(&quot;<?php echo e(asset('public/front/')); ?>/images/section_custom_bg.jpg&quot;); background-position: center center;  
	 background-repeat: no-repeat;  background-attachment: inherit; background-size: cover;  overflow: hidden; ">
    <div class="container" >
	<div class="row" style="margin-top:50px;margin-bottom:50px">
	<h1 class="text-center" style="color:#fff" >Contact Us</h1>
	</div>
</div>
     </section>
   


  <!--  ABOUT US -->

  <section class="section-content-block">
    <div class="container">
      <div class="row">
        <div class="col-md-7 col-sm-12 col-xs-12 " >
          
            <div class="appointment-form-wrapper light-layout margin-bottom-24 clearfix ">
            <div class="col-md-12 col-sm-12">
              <div class="appointment-form-heading text-left">
			  
                <h2 class="form-title text-capitalize margin-top-24">
                  GET A Query
                </h2>

                <p>
                  Please fill out the query form and very soon we will
                  contact with you to schedule .
                </p>
              </div>
            </div>

            <div class="col-md-12 col-sm-12">
              <form class="appoinment-form margin-top-42">
                <div class="form-group col-md-4">
                  <input id="your_name" class="form-control" placeholder="Name" type="text" required=""
                    data-msg="This field is required." />
                </div>
                <div class="form-group col-md-4">
                  <input id="your_email" class="form-control" placeholder="Email" type="email" required=""
                    data-msg="This field is required." />
                </div>
                <div class="form-group col-md-4">
                  <input id="your_phone" class="form-control" placeholder="Phone" type="text" required=""
                    data-msg="This field is required." />
                </div>

                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                  <textarea id="textarea_message" class="form-control" rows="3" placeholder="Your Message..."
                    required="" data-msg="This field is required."></textarea>
                </div>

                <div class="form-group col-md-12 col-sm-12 col-xs-12 text-left">
                  <button id="btn_submit" class="btn btn-theme btn-square wow zoomIn" type="submit">
                   Send
                  </button>
                </div>
              </form>
            </div>
          </div>
        <!--  end col-sm-6  -->
         
        </div>

        <div class="col-md-5 col-sm-12 col-xs-12 " >
          <div class=" theme-custom-box-shadow" style="padding:30px">
           
          <h2 class="contact-title">Our Location</h2>

         <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d224346.48130213915!2d77.06889602222955!3d28.527280340133224!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cfd5b347eb62d%3A0x52c2b7494e204dce!2sNew%20Delhi%2C%20Delhi!5e0!3m2!1sen!2sin!4v1601358541290!5m2!1sen!2sin" 
		 width="400" height="410" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            <!-- <div id="map_canvas"></div> -->
         
          <!-- end .section-content-block  -->
        </div>
        <!--  end col-sm-6  -->
          </div>
        </div>
        <!-- end .col-sm-12  -->
      </div>
    </div>
    <!--  end .container  -->
  </section>
  <!--  end .section-content-block -->

  

  

  
  <!--  end .appointment-section  -->
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\dm\resources\views/front/contact.blade.php ENDPATH**/ ?>