

<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 

 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Doctors List
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo e(url('admin/doctors-list')); ?>">Doctors List</a></li>
     <li><a href="<?php echo e(url('admin/doctors-list')); ?>">Doctors List</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">


          <div class="box">
            <div class="box-header">
              <h3 class="box-title">
				<?php if(session('success')): ?>
				<div class="alert alert-success">
				<?php echo e(session('success')); ?>

				</div>
				<?php elseif(session('error')): ?>
				<div class="alert alert-danger">
				<?php echo e(session('error')); ?>

				</div>
				<?php endif; ?>
              </h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Image</th>
                  <th>Name</th>
                  <th>Specialists</th>
                  <th>Status</th>
                  <th>Action</th>

                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><img src="<?php echo e(asset('public/front/doctors/').'/'.$doctor->image); ?>" width="100px"></td>
                    <td><?php echo e($doctor->name); ?></td>
                    <td><?php echo e($doctor->specialists); ?></td>
                    <td>
                        <input type="hidden" name="doctor_id" class="doctor_id" value="<?php echo e($doctor->id); ?>">
                        <select class="form-control status" name="status">
                        <option value="0" <?php echo e(($doctor->status=='0')?'selected':''); ?>>Unapproved</option>
                        <option value="1" <?php echo e(($doctor->status=='1')?'selected':''); ?>>Approved</option>
                        </select>
                    </td>
                  <td>
                      <a href="<?php echo e(url('admin/doctors-edit/').'/'.$doctor->id."/"); ?>">Edit</a> |
                      <a href="<?php echo e(url('admin/doctors-delete/').'/'.$doctor->id."/"); ?>">Delete</a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
    <script type="text/javascript">
        $(document).ready(function(){
            $('.status').on('change',function(){
                var status = $(this).val();
                var self= $(this);
                var doctor_id = self.closest('td').find('.doctor_id').val();
                    
                $.ajax({
                    type: 'GET',
                    url: "<?php echo e(route('admin.update-doctor-status')); ?>",
                    data: {"status": status,"doctor_id":doctor_id},
                    success:function(res){
                    if(res) {
                            alert('done');
                        }
                    }
                })
            })
        })
    </script>

 <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 
<?php /**PATH /home/u769120014/domains/diagnomitra.com/public_html/resources/views/admin/doctors-list.blade.php ENDPATH**/ ?>