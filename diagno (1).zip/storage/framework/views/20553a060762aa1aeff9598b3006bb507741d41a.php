<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <section class="page-title" style="background-image:url(images/background/bg-page-title-1.jpg);">
        <div class="auto-container">
            <h1>Shop</h1>
            <div class="bread-crumb-outer">
                <ul class="bread-crumb clearfix">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="active">Checkout</li>
                </ul>
            </div>
        </div>
    </section>
    
    <section>
        <div class="ps-checkout pt-40 pb-40">
      <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <h3>Checkout Details</h3>
            </div>
             <div class="col-sm-6">
                <a href="javascript:void(0)" id="editaddress" class="buttn btn btn-succes">Edit</a>
            </div>
        </div>
	  
			  
				
          <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 ">
               
                <div class="ps-checkout__billing billing">
                    <div class="form-group form-group--inline">
                        <div class="form-group form-group__content ">
                            <div class="My_cart">Billing Address</div>
                            <p class="container">Anuj Rana</p>
                            <p class="container">indian191989@gmail.com</p>
                            <p class="container"></p>
                            <p class="container">,</p>
                            <p class="container">-</p>
                        </div>
                    </div>
                </div>
                
                <div class="ps-checkout__billing billing">
                    <div class="form-group form-group--inline">
                        <div class="form-group form-group__content ">
                            <div class="My_cart">Billing Address</div>
                            <p class="container">Anuj Rana</p>
                            <p class="container">indian191989@gmail.com</p>
                            <p class="container"></p>
                            <p class="container">,</p>
                            <p class="container">-</p>
                        </div>
                    </div>
                </div>
                
                <div class="ps-checkout__billing billing">
               
					<div class="form-group form-group--inline">

						<div class="form-group form-group__content ">
						<div class="My_cart">My Cart (<?php echo e(Cart::getContent()->count()); ?>)</div>
						</div>
						<?php $__currentLoopData = \Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="form-group__content">
								<div class="col-sm-2 col-lg-4 col-md-2">
								<img src="<?php echo e(asset('public/front/product/').'/'.$item->attributes->image); ?>" alt="<?php echo e($item->name); ?>">
								</div>
								<div class="col-sm-4 col-lg-8 col-md-4">
								<label><?php echo e($item->name); ?></label><br>

								<h6>Price: <?php echo e($item->price); ?></h6>
								<h6>Quantity: <?php echo e($item->quantity); ?></h6>
								<h6>Sub Total: <?php echo e($item->price*$item->quantity); ?></h6>

								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
						


					</div>
              </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 ">
           
                
              <div class="ps-checkout__order">
                <header>
                  <h3>Your Order</h3>
                </header>
                <div class="content">
                  <table class="table ps-checkout__products">
                    <thead>
                      <tr>
                        <th class="text-uppercase">Product</th>
                        <th class="text-uppercase">Total</th>
                      </tr>
                        
                    </thead>
                    <tbody>
                      <tr>
                        <td>Order Total</td>
                        <td><i class="fa fa-inr"></i><?php echo e(\Cart::getSubTotal()); ?></td>
                        
                      </tr>
                      
                      
                    
                        <tr>
                        <td>Shipping Charge</td>
                        <td><i class="fa fa-inr"></i>0</td>
                        </tr>
                                                
                       
                        
                        <tr>
                        <td id="paymenttype">Cards Payment Charge</td>
                        <td id="payment-amount"><i class="fa fa-inr"></i>0</td>
                        </tr>
                        
                        <tr>
                        <td>Grant Total</td>
                        <td id="grant-amount"><i class="fa fa-inr"></i><?php echo e(\Cart::getSubTotal()); ?></td>
                        </tr>
                      
                    </tbody>
                  </table>
                </div>
					<footer>
						<h3>Payment Method</h3>
						<form class="ps-form-checkout" action="#" method="post">
						
						<div class="form-group paypal">
							<div class="ps-radio ps-radio--small">
							  <input class="form-control paymentmethod" type="radio" name="payment_method" id="rdo02" value="Cards Payment" checked="">
							  <label for="rdo02" style="margin: 5px 6px 5px 35px;">Cards Payment</label>
							</div>
					
						<button class="ps-btn ps-btn--fullwidth ps-btn--yellow" style="margin: 5px 10px 15px 50px;">Place Now</button>
						</div>
						</form>
					</footer>
				</div>
              
              
              
              
              
            </div>
          </div>
        
		      </div>
    </div>
    </section>
    
    
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\welfair\resources\views/front/checkout.blade.php ENDPATH**/ ?>