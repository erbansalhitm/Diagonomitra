<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="author" content="Rahul Gauniyal">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Redwingsolutions | It solutions for all your needs. </title>

    <!-- Favicons -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('public/front/')); ?>/img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('public/front/')); ?>/img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('public/front/')); ?>/img/favicon/favicon-16x16.png">
    <link rel="manifest" href="<?php echo e(asset('public/front/')); ?>/img/favicon/site.webmanifest">
    <link rel="mask-icon" href="<?php echo e(asset('public/front/')); ?>/img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">


    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=PT+Sans:ital,wght@0,400;0,700;1,400;1,700&display=swap"
        rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/slick.css">
    <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/normalize.css">
    <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/aos.css">
    <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/flexboxgrid.css">

    <!-- Main CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('public/front/')); ?>/css/style.css">

</head>

<!-- Body Tag Starts -->

<body id="cntctpg-tag" class="custom-cntctpg-tag">

    <!-- Header Starts -->
    <header id="header-tag" class="custom-header-tag">
        <div class="custom-header">
            <div class="custom-top-header">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                            <div class="custom-header-info">
                                <ul>
                                    <li><i class="fas fa-phone-volume"></i>
                                        <a href="tel:+91-9866028012">+91-9866028012</a></li>
                                    <li><i class="fas fa-envelope-open-text"></i>
                                        <a href="ktrao@redsol.in">ktrao@redsol.in</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                            <div class="custom-header-sociallinks">
                                <ul>
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                    <li> <a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-bottom-header">
                <div class="container">
                    <div class="row">
                        <!-- Header Logo -->
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <div class="custom-header-logo">
                                <a href="<?php echo e(route('/')); ?>"><img src="<?php echo e(asset('public/front/')); ?>/img/logo.png "
                                        alt="Redwingsolutions Logo"></a>
                            </div>
                        </div>
                        <div class="mobileicon"><i class="fas fa-bars"></i></div>
                        <!-- Header Menu -->
                        <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                            <nav class="custom-header-menu">
                                <ul>
                                    <li><a href="<?php echo e(route('/')); ?>">Home</a></li>
									<li><a href="<?php echo e(route('service')); ?>">Services</a></li>
									<li><a href="<?php echo e(route('about')); ?>">About</a></li>
									<li><a href="<?php echo e(route('products')); ?>">Products</a></li>
									<li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Ends -->

    <!-- Banner Starts -->
    <section id="banner-tag cntctpg-bnnrtag" class="custom-banner-tag page-section">
        <div class="custom-banner cntctpg-bnnr">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 center-align">
                        <div class="custom-banner-content cntctpg-bnnrcntn" data-aos="fade-up">
                            <h1>Contact us</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Banner End -->


    <!-- Main Section Content -->
    <main id="cntnsctns" class="csmt-cntnsctns">

        <!--================Get in Touch Area =================-->
        <section id="cntctpgsctn" class="cstm-cntctpg sctnblck">
            <div class="custom-cntctpgcntn">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                            <div class="cstmform" data-aos="fade-right">
                                <form action="contact-form.php" method="Post" id="pgeform" class="cstm-form">
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                            <div class="form-group in_name">
                                                <input type="text" name="name" id="name" class="form-fname-input"
                                                    placeholder="Enter Your Name" required>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                            <div class="form-group in_email">
                                                <input type="email" name="email" id="email" class="form-email-input"
                                                    placeholder="abc@gmail.com"
                                                    title="Correct e-mail format e.g. abc@gmail.com">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                            <div class="form-group in_email">
                                                <input type="tel" minlength="10" maxlength="10" id="phone" name="phone"
                                                    class="form-phone-input" placeholder="Enter Your Number"
                                                    title="Put 10 digit mobile number" required>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                            <div class="form-group in_email">
                                                <input type="text" class="form-control" id="subject"
                                                    placeholder="Subject" required="required">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                            <div class="form-group in_message">
                                                <textarea name="message" id="message" class="form-message-input"
                                                    cols="30" rows="7" pattern="[A-Za-z]" placeholder="Your Message"
                                                    required></textarea>
                                            </div>
                                            <div class="center-align">
                                                <input type="submit" value="submit" id="submit" class="btn"
                                                    title="Submit Your Message!">
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <div class="touch_details" data-aos="fade-left">
                                <div class="l_title">
                                    <img src="img/contact.png" alt="">
                                    <h6>Say hello</h6>
                                    <h2>Get in touch, send us an e-mail or call us</h2>
                                </div>
                                <p>To get the best of our solutions and products connect with us in real-time. To
                                    communicate your feedback to help solve problems, please use the Contact Us form or
                                    link at this page.</p>
                                <a href="tel:+91-9866028012">
                                    <h5>Call us now</h5>
                                </a>
                                <a href="tel:+91-9866028012">
                                    <h4>+91-9866028012</h4>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--================End Get in Touch Area =================-->

    </main>

    <!-- Footer Starts -->
    <footer id="ftrbtmtag" class="custom-ftrbtmtag">
        <div class="custom-footerbtm">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                        <div class="cstmcpyrght">
                            <p>&copy;<script>
                                    document.write(new Date().getFullYear());
                                </script> All rights reserved Made by <a href="https://digioodles.com"
                                    target="_blank">Digioodles.</a></p>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                        <div class="ftr-sociallinks">
                            <ul>
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                <li> <a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer><!-- Footer Ends -->

    <!-- Backto-top -->
    <a href="javascript:void();" id="back-to-top"><i class="fas fa-level-up-alt"></i></a>


    <!-- Vendor JS Files -->
    <script src="<?php echo e(asset('public/front/')); ?>/js/jquery-3.5.1.min.js"></script>
    <script src="<?php echo e(asset('public/front/')); ?>/js/easing.js"></script>
    <script src="<?php echo e(asset('public/front/')); ?>/js/jquery-migrate-3.3.0.min.js"></script>
    <script src="<?php echo e(asset('public/front/')); ?>/js/slick.min.js"></script>
    <script src="<?php echo e(asset('public/front/')); ?>/js/aos.js"></script>
    <script src="<?php echo e(asset('public/front/')); ?>/js/owl.carousel.min.js"></script>

    <!-- Template Main JS File -->
    <script src="<?php echo e(asset('public/front/')); ?>/js/custom.js"></script>


</body>

</html><?php /**PATH C:\xampp\htdocs\hp\resources\views/front/contact.blade.php ENDPATH**/ ?>