<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/bg-page-title-1.jpg);">
        <div class="auto-container">
            <h1>Response</h1>
            <div class="bread-crumb-outer">
                <ul class="bread-crumb clearfix">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    
                    <li class="active">Response</li>
                </ul>
            </div>
        </div>
    </section>
    
    
    <!--Donate Section-->
    
	<div class="section-full content-inner shop-account" style="background:url('https://wp.envatoextensions.com/kit-75/wp-content/uploads/sites/78/2018/09/wavy-dots.png')">
            <!-- Product -->
            <div class="container" style="padding-top: 30px;">
                <div class="row">
					<div class="col-lg-12 text-center">
						<h2 class="font-weight-700 m-t0 m-b40"></h2>
					</div>
				</div>
				<?php if(session('success')): ?>
					<div class="alert alert-success">
					<?php echo e(session('success')); ?>

					</div>
				<?php endif; ?>
				
                <div class="row dzseth">
					<div class="col-lg-12 col-md-12 m-b30" style="height: 346px;">
						<div class="p-a30 border-1 seth" style="height: 346px;">
							<div class="tab-content">
									<div class="default-title"><h1>payment Response</h1></div>
									
							</div>
						</div>
					</div>
					
				</div>
			</div>
            <!-- Product END -->
		</div>
	
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\socid\resources\views/front/response.blade.php ENDPATH**/ ?>