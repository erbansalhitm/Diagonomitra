

<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 

 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Coupon List
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo e(url('admin/coupon-list')); ?>">Coupon List</a></li>
     <li><a href="<?php echo e(url('admin/coupon-list')); ?>">Coupon List</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">


          <div class="box">
            <div class="box-header">
              <h3 class="box-title">
				<?php if(session('success')): ?>
				<div class="alert alert-success">
				<?php echo e(session('success')); ?>

				</div>
				<?php elseif(session('error')): ?>
				<div class="alert alert-danger">
				<?php echo e(session('error')); ?>

				</div>
				<?php endif; ?>
              </h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Code</th>
                  <th>Discount Amount</th>
                  <th>Status</th>
                  <th>Action</th>

                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($coupon->code); ?></td>
                  <td><?php echo e($coupon->amount); ?></td>
                  <td><?php if($coupon->status == '1'): ?><?php echo e('Active'); ?><?php elseif($coupon->status == '2'): ?><?php echo e('Deactive'); ?><?php elseif($coupon->status == '3'): ?><?php echo e('Used'); ?><?php endif; ?></td>
                  <td>
                      <a href="<?php echo e(url('admin/coupon-edit/').'/'.$coupon->id."/"); ?>">Edit</a> | 
                      <a href="<?php echo e(url('admin/coupon-delete/').'/'.$coupon->id."/"); ?>">Delete</a> |
                      <a href="<?php echo e(url('admin/coupon-active/').'/'.$coupon->id."/"); ?>">Actice</a> |
                      <a href="<?php echo e(url('admin/coupon-deactive/').'/'.$coupon->id."/"); ?>">Deactive</a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

 <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 
<?php /**PATH /home/primewe1/public_html/saromc.com/diagno/resources/views/admin/coupon-list.blade.php ENDPATH**/ ?>