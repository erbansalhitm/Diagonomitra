
<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-3">
  <div class="row">
    <?php echo $__env->make('doctor.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-sm-9">
      <div class="card px-3 py-3">
      <div class="tab-content" id="v-pills-tabContent">
        <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
          <div class="row">
            <div class="col-sm-6"><h5><b>Add Slot</b></h5></div>
                <div class="col-sm-12 col-md-12 col-xl-12 col-lg-12">
                    <?php if(session('msg')): ?>
                        <?php echo session('msg'); ?>

                    <?php endif; ?>
                    
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
                
                
            </div>
            <form name="edit-profile" method="POST" action="<?php echo e(route('doctor.add-slot')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-row mt-2">
                
                <div class="form-group col-sm-12 col-md-12 col-xl-12 col-lg-12">
                    <label for="inputEmail4">Slot Time</label>
                    <input type="text" class="form-control" id="inputEmail4"  name="slot" required >
                </div>

                <div class="col-sm-12 col-md-12 col-xl-12 col-lg-12">
                <input type="submit" name="submit" value="Submit"class="btn blue_color_bg" >
                </div>
                </div> 
            </form>
        </div>
        
        </div>
        </div>
      </div>
    </div>
  </div>

  <?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH /home/primewe1/public_html/saromc.com/diagno/resources/views/doctor/add-slot.blade.php ENDPATH**/ ?>