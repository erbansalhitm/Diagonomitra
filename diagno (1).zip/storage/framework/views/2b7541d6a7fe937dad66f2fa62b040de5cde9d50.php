<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--Page Title-->
    <section class="page-title" style="background-image:url(<?php echo e(asset('public/front/images/background/About-Us-Banner.png')); ?>);">
        <div class="auto-container">
            <h1>About Us</h1>
            <div class="bread-crumb-outer">
                <ul class="bread-crumb clearfix">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="active">About Us</li>
                </ul>
            </div>
        </div>
    </section>
    
    
    <!--About Us-->
    <?php if($aboutus): ?>
    <section class="about-us-section">
    	<div class="auto-container">
        	
            <!--Section Title-->
            <div class="sec-title centered">
            	<h2>ABOUT US</h2>
                <div class="separator"></div>
              
            <!--Content Box-->
            <div class="content-box">
            	<div class="row clearfix">
                	<!--Content Column-->
                    <div class="content-column col-lg-7 col-md-6 col-sm-12 col-xs-12">
                    	<div class="inner-box">
                        	<div class="text-content">
                               <?php echo $aboutus->content; ?>

                            </div>
                        </div>
                    </div>
                    
                    <!--Image Column-->
                    <div class="image-column col-lg-5 col-md-6 col-sm-12 col-xs-12">
                    	<figure class="image wow fadeInRight" data-wow-duration="1500ms" data-wow-delay="0ms"><img src="<?php echo e(asset('public/front/about').'/'.$aboutus->image); ?>" style="height: 305px;" alt=""></figure>
                    </div>
                    
                </div>
            </div>
            
            <div class="row clearfix">
            	
                <!--Default Icon Column-->
                <div class="default-icon-column col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="icon-box"><span class="flaticon-target"></span></div>
                        <h3>Our Mission</h3>
                        <div class="separator"></div>
                        <div class="text"><?php echo e($aboutus->widget1); ?></div>
                    </div>
                </div>
                
                <!--Default Icon Column-->
                <div class="default-icon-column col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="icon-box"><span class="flaticon-binoculars"></span></div>
                        <h3>Our Vision</h3>
                        <div class="separator"></div>
                        <div class="text"><?php echo e($aboutus->widget2); ?></div>
                    </div>
                </div>
                
                <!--Default Icon Column-->
                <div class="default-icon-column col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="icon-box"><span class="flaticon-envelope"></span></div>
                        <h3>Our Message</h3>
                        <div class="separator"></div>
                        <div class="text"><?php echo e($aboutus->widget3); ?></div>
                    </div>
                </div>
                
            </div>
            
        </div>
    </section>
    
    <?php endif; ?>
    
    <!--Sponsors Section-->
    <?php if($sponsors): ?>
    <section class="sponsors-section-two">
    	<div class="auto-container">
        	<!--Section Title-->
            <div class="sec-title centered">
            	<h2>OUR SPONSORS</h2>
                <div class="separator"></div>
            </div>
            
            <div class="sponsors-outer">
                <!--Sponsors Carousel Two-->
                <ul class="sponsors-carousel-two">
                    <?php $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo e(asset('public/front/sponsors/').'/'.$sponsor->image); ?>" alt=""></a></figure></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            
        </div>
    </section>
    <?php endif; ?>
	
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\welfair\resources\views/front/about.blade.php ENDPATH**/ ?>