<style>


/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other */
@media  screen and (max-width: 800px) {
  .leftcolumn, .rightcolumn {   
    width: 100%;
    padding: 0;
  }
}
</style>

<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!--  HOME SLIDER BLOCK  -->

  
    
     
     <section class="footer-widget-area footer-widget-area-bg section-custom-bg" style="background:linear-gradient( rgba(17,17,17,0.9),  rgba(17,17,17,0.9) ), url(&quot;images/section_custom_bg.jpg&quot;); background-position: center center;  
	 background-repeat: no-repeat;  background-attachment: inherit; background-size: cover;  overflow: hidden; ">
    <div class="container" >
	<div class="row" style="margin-top:50px;margin-bottom:50px">
	<h1 class="text-center" style="color:#fff" >Blogs</h1>
	</div>
</div>
     </section>
   
 

  <!--  ABOUT US -->

  <section class="section-content-block">
    <div class="container">
      <div class="row">
<div class="col-md-4 col-sm-6  col-xs-10 col-xs-offset-1 col-sm-offset-0 col-md-offset-0">
          <div class="team-layout-1 ">
            <figure class="team-member">
              <a href="#" title="blog">
                <img src="<?php echo e(asset('public/front/')); ?>/images/blog.jpg" alt="blog" />
              </a>
            </figure>
            <!-- end. team-member  -->

            <article class="team-info">
              <h2>TITLE HEADING</h2>
      <h5>Title description, Sep 2, 2020</h5>
              <p class="subheading-alt-style">
            Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante non
            lobortis posuere
          </p>
          <a href="#" style="color:#ffc300 ">Read More</a>

             
              <!-- end .author-social-box  -->
            </article>
          </div>
          <!--  end team layout-1 -->
        </div>
        <div class="col-md-4 col-sm-6 col-xs-10 col-xs-offset-1 col-sm-offset-0 col-md-offset-0">
          <div class="team-layout-1 ">
            <figure class="team-member">
              <a href="#" title="MELISSA MUNOZ">
                <img src="<?php echo e(asset('public/front/')); ?>/images/blog2.jpg" alt="MELISSA MUNOZ" />
              </a>
            </figure>
            <!-- end. team-member  -->

            <article class="team-info">
              <h2>TITLE HEADING</h2>
      <h5>Title description, Sep 2, 2020</h5>
              <p class="subheading-alt-style">
            Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante non
            lobortis posuere
          </p>
<a href="#" style="color:#ffc300 ">Read More</a>
             
              <!-- end .author-social-box  -->
            </article>
          </div>
          <!--  end team layout-1 -->
        </div>
        <div class="col-md-4 col-sm-6 col-xs-10 col-xs-offset-1 col-sm-offset-0 col-md-offset-0">
          <div class="team-layout-1">
            <figure class="team-member">
              <a href="#" title="MELISSA MUNOZ">
                <img src="<?php echo e(asset('public/front/')); ?>/images/blog3.jpg" alt="MELISSA MUNOZ" />
              </a>
            </figure>
            <!-- end. team-member  -->

            <article class="team-info">
              <h2>TITLE HEADING</h2>
      <h5>Title description, Sep 2, 2017</h5>
              <p class="subheading-alt-style">
            Lorem ipsum dolor sit amet adipiscing elit curabitur eu ante non
            lobortis posuere
          </p>
<a href="#" style="color:#ffc300 ">Read More</a>
             
              <!-- end .author-social-box  -->
            </article>
          </div>
          <!--  end team layout-1 -->
        </div>

  

</div>

       
        <!-- end .col-sm-12  -->
      
    </div>
    <!--  end .container  -->
  </section>
  <!--  end .section-content-block -->

  

  

  
  <!--  end .appointment-section  -->
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\dm\resources\views/front/blogs.blade.php ENDPATH**/ ?>