<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--Page Title-->
    <section class="page-title" style="background-image:url(<?php echo e(asset('public/front/')); ?>/images/background/bg-page-title-1.jpg);">
        <div class="auto-container">
            <h1>Our Blogs</h1>
            <div class="bread-crumb-outer">
                <ul class="bread-crumb clearfix">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="active">Our Blogs</li>
                </ul>
            </div>
        </div>
    </section>
    
    
     <!--News Section-->
    <section class="news-section">
    	<div class="auto-container">
        	<!--Section Title-->
            <div class="sec-title centered">
            	<h2>OUR BLOG</h2>
                <div class="separator"></div>
                
            </div>
            
        	<div class="">
				<div class="container">
					
					<div class="row">
						<div class="col-md-12">
							<div id="news-slider2" class="owl-carousel">
								 <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="post-slide2">
                                    <div class="post-img">
                                        <a href="#"><img src="<?php echo e(asset('public/front/blog').'/'.$blog->image); ?>" alt=""></a>
                                    </div>
                                    <div class="post-content">
                                        <h3 class="post-title"><a href="javascript:void(0)"><?php echo e($blog->title); ?></a></h3>
                                        <p class="post-description">
                                            <?php echo e(strip_tags($blog->content)); ?>

                                        </p>
                                        
                                        <a href="javascript:void(0)" class="theme-btn btn-style-three">read more</a>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</div>
						</div>
					</div>
				</div>
			</div>
        </div>
    </section>
	
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/primewe1/public_html/saromc.com/welfares/resources/views/front/blogs.blade.php ENDPATH**/ ?>