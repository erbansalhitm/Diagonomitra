    <?php
	
		$store_detail = DB::table('stores')->where('id',$enquiry->store_id)->first();
	?>
	
	
	<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
	 <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    <h1>
    Store Enquiry Details
    </h1>
    <ol class="breadcrumb">
    <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="#">Store Enquiry Details</a></li>
    <li><a href="#">Store Enquiry Details</a></li>
    </ol>
    </section>
    
    <!-- Main content -->
    <section class="content">
    <div class="row">
    <!-- left column -->
    <div class="col-md-12">
    <!-- general form elements -->
    <div class="box box-primary">
    <div class="box-header with-border">
	
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <table class="table">
            <tr>

                <th>Store Name</th>
                <th>Customer Name</th>
                <th>Customer Email</th>
                <th>Customer Contact</th>
            </tr>
            <tr>
                <td><?php echo e($store_detail->name ?? ''); ?></td>
                <td><?php echo e($enquiry->name); ?></td>
                <td><?php echo e($enquiry->email); ?></td>
                <td><?php echo e($enquiry->contact); ?></td>
                
            </tr>
			
			<tr>

                <th>Alternate Contact</th>
                <th>Customer Address</th>
                <th>Date</th>
            </tr>
            <tr>
                <td><?php echo e($enquiry->alternate_contact); ?></td>
                <td><?php echo e($enquiry->address); ?></td>
                <td><?php echo e($enquiry->created_at); ?></td>
                
            </tr>
			
			
            
        </table>
		<br/>
        <?php if($enquiry->prescription): ?>
			<b>Prescription</b>
			<a href="<?php echo e(asset('public/front/prescription').'/'.$enquiry->prescription); ?>" target="_blank" class="alert text-danger">View Now</a>
	   <?php endif; ?>
    </div>
    
    
    </div>
    
    </div>
    <!-- /.row -->
    </section>
    <!-- /.content -->
    </div>
    
   
    

    <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    
<?php /**PATH /home/u769120014/domains/diagnomitra.com/public_html/resources/views/admin/stores-enquiry-details.blade.php ENDPATH**/ ?>