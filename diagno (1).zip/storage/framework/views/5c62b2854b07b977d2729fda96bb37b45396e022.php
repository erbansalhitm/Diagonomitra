    <?php
	
		$doctor_detail = DB::table('doctors')->where('id',$enquiry->doctor_id)->first();
	?>
	
	
	<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
	 <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    <h1>
    Enquiry Details
    </h1>
    <ol class="breadcrumb">
    <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="#">Enquiry Details</a></li>
    <li><a href="#">Enquiry Details</a></li>
    </ol>
    </section>
    
    <!-- Main content -->
    <section class="content">
    <div class="row">
    <!-- left column -->
    <div class="col-md-12">
    <!-- general form elements -->
    <div class="box box-primary">
    <div class="box-header with-border">
	
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <table class="table">
            <tr>
                <th>Booking Id</th>
                <th>Doctor Name</th>
                <th>Customer Name</th>
                <th>Customer Email</th>
                <th>Customer Mobile</th>
            </tr>
            <tr>
                <td><?php echo e($enquiry->booking_id); ?></td>
                <td><?php echo e($doctor_detail->name ?? ''); ?></td>
                <td><?php echo e($enquiry->name); ?></td>
                <td><?php echo e($enquiry->email); ?></td>
                <td><?php echo e($enquiry->mobile); ?></td>
                
            </tr>
			
			<tr>
                <th>Consulting Mode </th>
                <th>Booking Date</th>
                <th>Booking Time</th>
                <th>Doctor Fee</th>
                <th>Payment Status</th>
            </tr>
            <tr>
                <td><?php echo e($enquiry->mode); ?></td>
                <td><?php echo e($enquiry->date); ?></td>
                <td><?php echo e($enquiry->time); ?></td>
                <td><?php echo e($enquiry->fee); ?></td>
                <td><?php echo e($enquiry->payment_status); ?></td>
            </tr>
            
        </table>
		<br/>
        <?php if($enquiry->prescription): ?>
			<b>Prescription</b>
			<a href="<?php echo e(asset('public/front/prescription').'/'.$enquiry->prescription); ?>" target="_blank" class="alert text-danger">View Now</a>
	   <?php endif; ?>
    </div>
    
    
    </div>
    
    </div>
    <!-- /.row -->
    </section>
    <!-- /.content -->
    </div>
    
   
    

    <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    
<?php /**PATH C:\xampp\htdocs\diagno\resources\views/admin/enquiry-details.blade.php ENDPATH**/ ?>