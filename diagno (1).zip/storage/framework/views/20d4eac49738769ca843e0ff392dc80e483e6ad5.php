<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--Page Title-->
    <section class="page-title" style="background-image:url(<?php echo e(asset('public/front/')); ?>/images/background/unnamed.jpg);">
        <div class="auto-container">
            <h1>Matrimonial</h1>
            <div class="bread-crumb-outer">
                <ul class="bread-crumb clearfix">
                    <li><a href="index.php">Home</a></li>
                    <li class="active">Matrimonial</li>
                </ul>
            </div>
        </div>
    </section>
    
    
<section class="recent-causes-section" style="background:url('https://wp.envatoextensions.com/kit-75/wp-content/uploads/sites/78/2018/09/wavy-dots.png')">
    	<div class="auto-container">
        	<!--Section Title-->
            <div class="sec-title centered">
            	<h2>MATRIMONIAL</h2>
                <div class="separator"></div>
                
            </div>
			
        	<div class="row clearfix">
            	<!--Default Cause Box-->
            	<div class="col-md-12 ">
            	
				<div class="slide-item">
				    
                <div class="default-cause-box col-sm-2 col-sm-6 col-xs-12 col-md-offset-1">
                	<div class="inner-box wow fadeIn" data-wow-duration="1500ms" data-wow-delay="0ms">
                    	<div class="image-box">
                        	<figure class="image"><a href="single-cause.php"><img src="<?php echo e(asset('public/front/')); ?>/images/resource/male-icon.jpg" style="height: 170px;" alt=""></a></figure>
                            
                        </div>
                        <div class="lower-content">
                        	
                            <h3 style="text-align: left;"><a href="matrimonial-detail.php"><strong>XXXX Rana</strong></a></h3>
                            <h3 style="text-align: left;"><a href="matrimonial-detail.php"><strong>Age, Height, City</strong></a></h3>
                            <h3 style="text-align: left;"><a href="matrimonial-detail.php">MCA,BCA</a></h3>
                            <h3 style="text-align: left;"><a href="matrimonial-detail.php">Annual Income, IT Engg</a></h3>
                        </div>
                    </div>
                </div>
                </div>
                <!--Default Cause Box-->
				<div class="slide-item">
                <div class="default-cause-box col-sm-2 col-sm-6 col-xs-12">
                	<div class="inner-box wow fadeIn" data-wow-duration="1500ms" data-wow-delay="300ms">
                    	<div class="image-box">
                        	<figure class="image"><a href="single-cause.php"><img src="<?php echo e(asset('public/front/')); ?>/images/resource/female.jpg" style="height: 170px;" alt=""></a></figure>
                            
                        </div>
                        <div class="lower-content">
                        	
                            
                            <h3 style="text-align: left;"><a href="#"><strong>XXXX Rana</strong></a></h3>
                            <h3 style="text-align: left;"><a href="#"><strong>Age, Height, City</strong></a></h3>
                            <h3 style="text-align: left;"><a href="#">MCA,BCA</a></h3>
                            <h3 style="text-align: left;"><a href="#">Annual Income, IT Engg</a></h3>
                        </div>
                    </div>
                </div>
                </div>
                <!--Default Cause Box-->
				<div class="slide-item">
                <div class="default-cause-box col-sm-2 col-sm-6 col-xs-12">
                	<div class="inner-box wow fadeIn" data-wow-duration="1500ms" data-wow-delay="600ms">
                    	<div class="image-box">
                        	<figure class="image"><a href="single-cause.php"><img src="<?php echo e(asset('public/front/')); ?>/images/resource/male-icon.jpg" style="height: 170px;" alt=""></a></figure>
                            
                        </div>
                        <div class="lower-content">
                        	
                            <h3 style="text-align: left;"><a href="#"><strong>XXXX Rana</strong></a></h3>
                            <h3 style="text-align: left;"><a href="#"><strong>Age, Height, City</strong></a></h3>
                            <h3 style="text-align: left;"><a href="#">MCA,BCA</a></h3>
                            <h3 style="text-align: left;"><a href="#">Annual Income, IT Engg</a></h3>
                        </div>
                    </div>
                </div>
                </div>
                <div class="slide-item">
                <div class="default-cause-box col-sm-2 col-sm-6 col-xs-12">
                	<div class="inner-box wow fadeIn" data-wow-duration="1500ms" data-wow-delay="600ms">
                    	<div class="image-box">
                        	<figure class="image"><a href="single-cause.php"><img src="<?php echo e(asset('public/front/')); ?>/images/resource/male-icon.jpg" style="height: 170px;" alt=""></a></figure>
                            
                        </div>
                        <div class="lower-content">
                        	<h3 style="text-align: left;"><a href="#"><strong>XXXX Rana</strong></a></h3>
                            <h3 style="text-align: left;"><a href="#"><strong>Age, Height, City</strong></a></h3>
                            <h3 style="text-align: left;"><a href="#">MCA,BCA</a></h3>
                            <h3 style="text-align: left;"><a href="#">Annual Income, IT Engg</a></h3>
                        </div>
                    </div>
                </div>
                </div>
                <div class="slide-item">
                <div class="default-cause-box col-sm-2 col-sm-6 col-xs-12 col-md-offset-1right">
                	<div class="inner-box wow fadeIn" data-wow-duration="1500ms" data-wow-delay="600ms">
                    	<div class="image-box">
                        	<figure class="image"><a href="single-cause.php"><img src="<?php echo e(asset('public/front/')); ?>/images/resource/male-icon.jpg" style="height: 170px;" alt=""></a></figure>
                            
                        </div>
                        <div class="lower-content">
                        	<h3 style="text-align: left;"><a href="#"><strong>XXXX Rana</strong></a></h3>
                            <h3 style="text-align: left;"><a href="#"><strong>Age, Height, City</strong></a></h3>
                            <h3 style="text-align: left;"><a href="#">MCA,BCA</a></h3>
                            <h3 style="text-align: left;"><a href="#">Annual Income, IT Engg</a></h3>
                        </div>
                    </div>
                </div>
                </div>
                </div>
                <!--<div class="col-md-2">
                    <div class="back">
                        <h4>See All List</h4>
                    </div>
                        <ul>
                            <li>XXXX Rana</li>
                            <li>XXXX Rana</li>
                            <li>XXXX Rana</li>
                            <li>XXXX Rana</li>
                            <li>XXXX Rana</li>
                            <li>XXXX Rana</li>
                        </ul>
                </div>-->
                   
                
            </div>
        </div>
    </section>
	
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/primewe1/public_html/saromc.com/welfares/resources/views/front/matrimonial.blade.php ENDPATH**/ ?>