<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="page-title" style="background-image:url(<?php echo e(asset('public/front/')); ?>/images/background/bg-page-title-1.jpg);">
        <div class="auto-container">
            <h1>Product</h1>
            <div class="bread-crumb-outer">
                <ul class="bread-crumb clearfix">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="active">Product</li>
                </ul>
            </div>
        </div>
    </section>
    
    
    <!--Shop Section-->
    <section class="shop-section">
    	<div class="auto-container">
        	<!--Section Title-->
            <div class="sec-title centered">
            	<h2>OUR PRODUCTS</h2>
                <div class="separator"></div>
            </div>
           

            <div class="row clearfix">
            	<!--Default Shop Item-->
            	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="default-shop-item col-lg-3 col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image-box">
                        	<figure class="image"><a href="<?php echo e(route('product.product-detail',$product->slug)); ?>"><img src="<?php echo e(asset('public/front/product/').'/'.$product->image); ?>" alt=""></a></figure>
                            <div class="prod-options">
                            	<a class="lightbox-image option-btn" href="<?php echo e(asset('public/front/product/').'/'.$product->image); ?>" title="Image Caption Here" data-fancybox-group="example-gallery"><span class="fa fa-search"></span></a>
                                <a class="option-btn" href="<?php echo e(route('product.product-detail',$product->slug)); ?>"><span class="fa fa-shopping-cart"></span></a>
                            </div>
                        </div>
                        <div class="lower-content">
                        	<h3><a href="<?php echo e(route('product.product-detail',$product->slug)); ?>"><?php echo e($product->name); ?></a></h3>
                            <div class="price"><span class="price-txt">Rs <?php echo e($product->price); ?></span></div>
                           
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
            
            <!-- Styled Pagination -->
            <div class="styled-pagination">
                <?php echo e($products->links()); ?>

            </div>
                    
        </div>
    </section>
    
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/primewe1/public_html/saromc.com/welfares/resources/views/front/product.blade.php ENDPATH**/ ?>