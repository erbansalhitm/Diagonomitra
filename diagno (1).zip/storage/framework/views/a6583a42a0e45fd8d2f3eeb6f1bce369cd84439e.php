<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="page-title" style="background-image:url(<?php echo e(asset('public/front/')); ?>/images/background/bg-page-title-1.jpg);">
        <div class="auto-container">
            <h1>Product</h1>
            <div class="bread-crumb-outer">
                <ul class="bread-crumb clearfix">
                    <li><a href="index.php">Home</a></li>
                    <li class="active">Product</li>
                </ul>
            </div>
        </div>
    </section>
    
    
    <!--Shop Section-->
    <section class="shop-section">
    	<div class="auto-container">
        	<!--Section Title-->
            <div class="sec-title centered">
            	<h2>OUR PRODUCTS</h2>
                <div class="separator"></div>
            </div>
           
            <!--Sort By-->
            <!---
            <div class="items-sorting">
                <div class="row clearfix">
                    
                    <div class="select-column pull-right col-md-3 col-sm-12 col-xs-12">
                        <div class="form-group">
                            <select name="sort-by">
                                <option>Sort by: Default Order</option>
                                <option>Sort by: Ascending Order</option>
                                <option>Sort by: Descending Order</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            ----->
            <div class="row clearfix">
            	<!--Default Shop Item-->
                <div class="default-shop-item col-lg-3 col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image-box">
                        	<figure class="image"><a href="product-detail.php"><img src="<?php echo e(asset('public/front/')); ?>/images/resource/products/image-1.jpg" alt=""></a></figure>
                            <div class="prod-options">
                            	<a class="lightbox-image option-btn" href="images/resource/products/image-1.jpg" title="Image Caption Here" data-fancybox-group="example-gallery"><span class="fa fa-search"></span></a>
                                <a class="option-btn" href="product-detail.php"><span class="fa fa-shopping-cart"></span></a>
                            </div>
                        </div>
                        <div class="lower-content">
                        	<h3><a href="product-detail.php">PRODUCT TITLE</a></h3>
                            <div class="price"><span class="price-txt">Rs 24.00</span></div>
                           
                        </div>
                    </div>
                </div>
                
                <!--Default Shop Item-->
                <div class="default-shop-item col-lg-3 col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image-box">
                        	<figure class="image"><a href="product-detail.php"><img src="<?php echo e(asset('public/front/')); ?>/images/resource/products/image-2.jpg" alt=""></a></figure>
                            <div class="prod-options">
                            	<a class="lightbox-image option-btn" href="images/resource/products/image-2.jpg" title="Image Caption Here" data-fancybox-group="example-gallery"><span class="fa fa-search"></span></a>
                                <a class="option-btn" href="product-detail.php"><span class="fa fa-shopping-cart"></span></a>
                            </div>
                        </div>
                        <div class="lower-content">
                        	<h3><a href="product-detail.php">PRODUCT TITLE</a></h3>
                            <div class="price"><span class="price-txt">Rs 36.00</span></div>
                            
                        </div>
                    </div>
                </div>
                
                <!--Default Shop Item-->
                <div class="default-shop-item col-lg-3 col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image-box">
                        	<figure class="image"><a href="product-detail.php"><img src="<?php echo e(asset('public/front/')); ?>/images/resource/products/image-3.jpg" alt=""></a></figure>
                            <div class="prod-options">
                            	<a class="lightbox-image option-btn" href="images/resource/products/image-3.jpg" title="Image Caption Here" data-fancybox-group="example-gallery"><span class="fa fa-search"></span></a>
                                <a class="option-btn" href="product-detail.php"><span class="fa fa-shopping-cart"></span></a>
                            </div>
                        </div>
                        <div class="lower-content">
                        	<h3><a href="product-detail.php">PRODUCT TITLE</a></h3>
                            <div class="price"><span class="price-txt">Rs 245.00</span></div>
                            
                        </div>
                    </div>
                </div>
                
                <!--Default Shop Item-->
                <div class="default-shop-item col-lg-3 col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image-box">
                        	<figure class="image"><a href="product-detail.php"><img src="<?php echo e(asset('public/front/')); ?>/images/resource/products/image-4.jpg" alt=""></a></figure>
                            <div class="prod-options">
                            	<a class="lightbox-image option-btn" href="images/resource/products/image-4.jpg" title="Image Caption Here" data-fancybox-group="example-gallery"><span class="fa fa-search"></span></a>
                                <a class="option-btn" href="product-detail.php"><span class="fa fa-shopping-cart"></span></a>
                            </div>
                        </div>
                        <div class="lower-content">
                        	<h3><a href="product-detail.php">PRODUCT TITLE</a></h3>
                            <div class="price"><span class="price-txt">Rs 54.00</span></div>
                            
                        </div>
                    </div>
                </div>
                
                <!--Default Shop Item-->
                <div class="default-shop-item col-lg-3 col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image-box">
                        	<figure class="image"><a href="product-detail.php"><img src="<?php echo e(asset('public/front/')); ?>/images/resource/products/image-5.jpg" alt=""></a></figure>
                            <div class="prod-options">
                            	<a class="lightbox-image option-btn" href="images/resource/products/image-5.jpg" title="Image Caption Here" data-fancybox-group="example-gallery"><span class="fa fa-search"></span></a>
                                <a class="option-btn" href="product-detail.php"><span class="fa fa-shopping-cart"></span></a>
                            </div>
                        </div>
                        <div class="lower-content">
                        	<h3><a href="product-detail.php">PRODUCT TITLE</a></h3>
                            <div class="price"><span class="price-txt">Rs 24.00</span></div>
                            
                        </div>
                    </div>
                </div>
                
                <!--Default Shop Item-->
                <div class="default-shop-item col-lg-3 col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image-box">
                        	<figure class="image"><a href="product-detail.php"><img src="<?php echo e(asset('public/front/')); ?>/images/resource/products/image-6.jpg" alt=""></a></figure>
                            <div class="prod-options">
                            	<a class="lightbox-image option-btn" href="images/resource/products/image-6.jpg" title="Image Caption Here" data-fancybox-group="example-gallery"><span class="fa fa-search"></span></a>
                                <a class="option-btn" href="product-detail.php"><span class="fa fa-shopping-cart"></span></a>
                            </div>
                        </div>
                        <div class="lower-content">
                        	<h3><a href="product-detail.php">PRODUCT TITLE</a></h3>
                            <div class="price"><span class="price-txt">Rs 36.00</span></div>
                            
                        </div>
                    </div>
                </div>
                
                <!--Default Shop Item-->
                <div class="default-shop-item col-lg-3 col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image-box">
                        	<figure class="image"><a href="product-detail.php"><img src="<?php echo e(asset('public/front/')); ?>/images/resource/products/image-7.jpg" alt=""></a></figure>
                            <div class="prod-options">
                            	<a class="lightbox-image option-btn" href="images/resource/products/image-7.jpg" title="Image Caption Here" data-fancybox-group="example-gallery"><span class="fa fa-search"></span></a>
                                <a class="option-btn" href="product-detail.php"><span class="fa fa-shopping-cart"></span></a>
                            </div>
                        </div>
                        <div class="lower-content">
                        	<h3><a href="product-detail.php">PRODUCT TITLE</a></h3>
                            <div class="price"><span class="price-txt">Rs 245.00</span></div>

                        </div>
                    </div>
                </div>
                
                <!--Default Shop Item-->
                <div class="default-shop-item col-lg-3 col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image-box">
                        	<figure class="image"><a href="product-detail.php"><img src="<?php echo e(asset('public/front/')); ?>/images/resource/products/image-8.jpg" alt=""></a></figure>
                            <div class="prod-options">
                            	<a class="lightbox-image option-btn" href="images/resource/products/image-8.jpg" title="Image Caption Here" data-fancybox-group="example-gallery"><span class="fa fa-search"></span></a>
                                <a class="option-btn" href="product-detail.php"><span class="fa fa-shopping-cart"></span></a>
                            </div>
                        </div>
                        <div class="lower-content">
                        	<h3><a href="product-detail.php">PRODUCT TITLE</a></h3>
                            <div class="price"><span class="price-txt">Rs 54.00</span></div>
                            
                        </div>
                    </div>
                </div>
                
            </div>
            
            <!-- Styled Pagination -->
            <div class="styled-pagination">
                <ul>
                    <li><a class="prev" href="#"><span class="fa fa-angle-double-left"></span></a></li>
                    <li><a href="#" class="active">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a class="next" href="#"><span class="fa fa-angle-double-right"></span></a></li>
                </ul>
            </div>
                    
        </div>
    </section>
    
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/welfare/resources/views/front/product.blade.php ENDPATH**/ ?>