<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/bg-page-title-1.jpg);">
        <div class="auto-container">
            <h1>Login</h1>
            <div class="bread-crumb-outer">
                <ul class="bread-crumb clearfix">
                    <li><a href="index.php">Home</a></li>
                    
                    <li class="active">Login</li>
                </ul>
            </div>
        </div>
    </section>
    
    
    <!--Donate Section-->
    
	<div class="section-full content-inner shop-account" style="background:url('https://wp.envatoextensions.com/kit-75/wp-content/uploads/sites/78/2018/09/wavy-dots.png')">
            <!-- Product -->
            <div class="container" style="padding-top: 30px;">
                <div class="row">
					<div class="col-lg-12 text-center">
						<h2 class="font-weight-700 m-t0 m-b40"></h2>
					</div>
				</div>
                <div class="row dzseth">
					<div class="col-lg-6 col-md-6 m-b30" style="height: 346px;">
						<div class="p-a30 border-1 seth" style="height: 346px;">
							<div class="tab-content">
									<div class="default-title"><h3>New Member</h3></div>
									<p class="font-weight-600">If You are new user please create your account</p>
									<div class="links"><a href="registration.php" class="theme-btn btn-style-three">Create An Account</a></div>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 m-b30" style="height: 346px;">
						<div class="p-a30 border-1 seth" style="height: 346px;">
							<div class="tab-content nav">
								<form id="login" class="tab-pane active col-12 p-a0 ">
									<div class="default-title"><h3>Login</h3></div>
									<div class="userloginmmsg"></div>
									<div class="form-group">
										<label class="font-weight-700">E-MAIL *</label>
										<input name="email" class="form-control email" placeholder="Your Email Id" type="email">
									</div>
									<div class="form-group">
										<label class="font-weight-700">PASSWORD *</label>
										<input name="password" class="form-control password" placeholder="Type Password" type="password">
									</div>
									<div class="text-left">
										<button type="submit" class="theme-btn btn-style-three">Login</button>
										<a data-toggle="tab" href="#forgot-password" class="m-l5"><i class="fa fa-unlock-alt"></i> Forgot Password</a> 
									</div>
								</form>
								<form id="forgot-password" class="tab-pane fade  col-12 p-a0">
									<h4 class="font-weight-700">FORGET PASSWORD ?</h4>
									<p class="font-weight-600">We will send you an email to reset your password. </p>
									<div class="form-group">
										<label class="font-weight-700">E-MAIL *</label>
										<input name="dzName" required="" class="form-control" placeholder="Your Email Id" type="email">
									</div>
									<div class="text-left"> 
										<a class="site-button outline gray button-lg radius-no" data-toggle="tab" href="#login">Back</a>
										<button class="site-button pull-right button-lg radius-no">Submit</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
            <!-- Product END -->
		</div>
	
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/welfare/resources/views/front/login.blade.php ENDPATH**/ ?>