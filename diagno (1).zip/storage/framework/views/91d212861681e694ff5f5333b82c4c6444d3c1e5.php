

  <script type="text/javascript">
    $(document).ready(function(){
        $("#payment_test").submit();
    })
    
</script>

<div class="card-body text-center">
	<form action="<?php echo e(route('responce')); ?>" method="POST" id="payment_test" >
		<?php echo csrf_field(); ?>
		<script src="https://checkout.razorpay.com/v1/checkout.js"
				data-key="<?php echo e(env('RAZOR_KEY')); ?>"
				data-amount="<?php echo e($total_amount); ?>"
				data-order_id = "<?php echo e($order['id']); ?>"
				data-buttontext="Pay Now"
				data-name="Order Name"
				data-description="Rozerpay"
				data-image="<?php echo e(asset('/image/nice.png')); ?>"
				data-prefill.name="<?php echo e($name); ?>"
				data-prefill.email="<?php echo e($email); ?>"
				data-theme.color="#ff7529">
		</script>
		</form>
</div>
                <?php /**PATH C:\xampp\htdocs\diagno\resources\views/front/payWithRazorpay.blade.php ENDPATH**/ ?>