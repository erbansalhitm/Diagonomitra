    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
	 <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    <h1>
    Edit Product
    </h1>
    <ol class="breadcrumb">
    <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="javascript:void(0)">Edit Product</a></li>
    <li><a href="javascript:void(0)">Edit Product</a></li>
    </ol>
    </section>
    
    <!-- Main content -->
    <section class="content">
    <div class="row">
    <!-- left column -->
    <div class="col-md-12">
    <!-- general form elements -->
    <div class="box box-primary">
    <div class="box-header with-border">
	
	<?php if(session('success')): ?>
	<div class="alert alert-success">
	<?php echo e(session('success')); ?>

	</div>
	<?php elseif(session('error')): ?>
	<div class="alert alert-danger">
	<?php echo e(session('error')); ?>

	</div>
	<?php endif; ?>
	
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="alert alert-danger">
	<?php echo e($error); ?>

	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <form role="form" method="POST" action ="<?php echo e(route('admin.edit-product',$product->id)); ?>" enctype="multipart/form-data">
    <div class="box-body">
	<?php echo e(csrf_field()); ?>



	    
    <div class="form-group">
    <label for="exampleInputEmail1">Product Name</label>
    <input type="text" class="form-control"  id="exampleInputname" name="productname" placeholder="Enter Product Name" value="<?php echo e($product->name); ?>" required>
    </div>
    
    <div class="form-group">
    <label for="exampleInputEmail1">Price</label>
    <input type="text" class="form-control"  id="exampleInputname" name="price" placeholder="Enter Price" value="<?php echo e($product->price); ?>"  required>
    </div>

    <div class="form-group">
    <label for="exampleInputEmail1">Old Price</label>
    <input type="text" class="form-control"  id="exampleInputname" name="oldprice" placeholder="Enter Old Price" value="<?php echo e($product->oldprice); ?>"  required>
    </div>

    <div class="form-group">
    <label for="exampleInputPassword1">Stock</label>
    <select class="form-control" id="stock" name="stock" required>
    <option value="<?php echo e($product->stock); ?>" ><?php if($product->stock): ?><?php echo e('In Stock'); ?><?php else: ?><?php echo e('Out Stock'); ?><?php endif; ?></option>
    <option value = "1">In Stock</option>
    <option value = "0">Out Stock</option>
    </select>
    </div>    


    <div class="form-group">
    <label for="exampleInputEmail1">Quantity</label>
    <input type="text" class="form-control"  id="exampleInputname" name="quantity" placeholder="Enter Quantity" value="<?php echo e($product->quantity); ?>"  required>
    </div>

    <div class="form-group">
    <label for="exampleInputEmail1">Short Detail</label>
    <textarea class="textarea"   name="shortDetail" placeholder="Enter Short Detail"
    style="width: 100%; height: 108px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo e($product->shortDetail); ?></textarea>
    </div>

    <div class="form-group">
    <label for="exampleInputEmail1">Description</label>
    <textarea class="textarea"   name="description" placeholder="Enter Description"
    style="width: 100%; height: 108px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo e($product->description); ?></textarea>
    </div>


    <div class="form-group">
    <label for="exampleInputEmail1">Main Image</label>
    <input type="file" class="form-control"  id="exampleInputname" name="mainImage" placeholder="Enter Image" >
    </div>




    <!-- /.box-body -->
    
    <div class="box-footer">
    <button type="submit" class="btn btn-primary">Submit</button>
    </div>
    </form>
    </div>
    
    
    </div>
    
    </div>
    <!-- /.row -->
    </section>
    <!-- /.content -->
    </div>
    


    <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    
<?php /**PATH C:\xampp\htdocs\dm\resources\views/admin/edit-product.blade.php ENDPATH**/ ?>