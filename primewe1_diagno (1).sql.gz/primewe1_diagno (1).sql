-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: localhost    Database: primewe1_diagno
-- ------------------------------------------------------
-- Server version	5.7.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `currentdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`id`, `username`, `password`, `name`, `email`, `contact`, `currentdate`) VALUES (1,'admin@gmail.com','e10adc3949ba59abbe56e057f20f883e','Admin','panchal061090@gmail.com','8447809762','2019-09-18 08:12:22');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text,
  `slug` text,
  `content` text,
  `image` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
INSERT INTO `blogs` (`id`, `title`, `slug`, `content`, `image`, `updated_at`, `created_at`) VALUES (1,'BLOG IMAGE POST LAYOUTS','blog-image-post-layout1608101356','<p>\r\n\r\n</p><p>Aenean et tempor eros, vitae sollicitudin velit. Etiam varius enim nec quam tempor, sed efficitur ex ultrices. Phasellus pretium est vel dui vestibulum condimentum. Aenean nec suscipit nibh. Phasellus nec lacus id arcu facilisis elementum. Curabitur lobortis, elit ut elementum congue, erat ex bibendum odio, nec iaculis lacus sem non lorem. Duis suscipit metus ante, sed convallis quam posuere quis. Ut tincidunt eleifend odio, ac fringilla mi vehicula nec. Nunc vitae lacus eget lectus imperdiet tempus sed in dui. Nam molestie magna at risus consectetur, placerat suscipit justo dignissim. Sed vitae fringilla enim, nec ullamcorper arcu.</p><p>Aenean et tempor eros, vitae sollicitudin velit. Etiam varius enim nec quam tempor, sed efficitur ex ultrices. Phasellus pretium est vel dui vestibulum condimentum. Aenean nec suscipit nibh. Phasellus nec lacus id arcu facilisis elementum. Curabitur lobortis, elit ut elementum congue, erat ex bibendum odio, nec iaculis lacus sem non lorem. Duis suscipit metus ante, sed convallis quam posuere quis. Ut tincidunt eleifend odio, ac fringilla mi vehicula nec. Nunc vitae lacus eget lectus imperdiet tempus sed in dui. Nam molestie magna at risus consectetur, placerat suscipit justo dignissim. Sed vitae fringilla enim, nec ullamcorper arcu.</p>\r\n\r\n<br><p></p>','1608100401.jpeg','2020-12-16 06:23:18','2020-12-16 06:23:18'),(2,'Who We Are','who-we-are1609226875','<p></p><p>Diagnomitra\r\nis a leading health tech company that provides advanced healthcare solution in\r\npharmacy and healthcare services which results in a doctor’s patient experience\r\nmuch better and interactive by providing an online platform for\r\nteleconsultation that is a video and audio consultation.</p>\r\n\r\n<p>Diagnomitra\r\nenfolds all the section which includes all steps like doctor consultancy, tests\r\nbooking,  healthcare devices to medicine\r\ndispatch under one roof &nbsp;where one can\r\ndeal with their all health problems from their doorstep. It is like a\r\ncompanion which provides all the required facilities that keep you fit and\r\nhealthy at one stop. </p>\r\n\r\n<p>Diagnomitra\r\nare a high tech and premium quality based platform that presents an extensive\r\nrange of medical products that are convenient as per the government norms at\r\naffordable costs.</p>\r\n\r\n<p>Diagnomitra provides all laboratory services from NABL\r\nand  Ios certified laboratories that\r\nprovide accurate and verified reports timely. Sample collection from home by an\r\nexperienced and well behaved screened technician.</p>\r\n\r\n<p>Diagnomitra\r\nsaves your time and reduces your problems in your hard times. If you get ill\r\nthen someone is there for you to bring an experienced doctor, provides\r\nprescribed medicines &nbsp;at your doorsteps,\r\nbooks your tests and healthcare devices \r\nfrom Diagnomitra at affordable prices from the comfort of your home. You\r\nonly have to upload your prescribed medicines and get a confirmation call of\r\nyour bookings.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\nOne window where you will get the highest quality,\r\nthat you deserve. We choose the best for you. Your safety is our priority. We serve\r\nyou from the core of our hearts.&nbsp;<br><p></p>','1609226875.jpeg','2020-12-29 07:27:55','2020-12-29 07:27:55');
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_id` varchar(255) DEFAULT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `doctor_id` varchar(100) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mode` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `prescription` varchar(255) DEFAULT NULL,
  `fee` varchar(100) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `payment_status` varchar(255) NOT NULL DEFAULT 'Pending',
  `payment_type` varchar(100) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` (`id`, `booking_id`, `user_id`, `doctor_id`, `name`, `mobile`, `email`, `mode`, `date`, `time`, `prescription`, `fee`, `status`, `payment_status`, `payment_type`, `updated_at`, `created_at`) VALUES (14,'order_GKRySL4UZLhzih','17','15','Parveen Sharma','9818804224','abhishekaccuster31@gmail.com','Audio','2021-01-03','10:00 - 10:30',NULL,'600','0','Pending',NULL,'2021-01-02 13:11:44','2021-01-02 13:11:44'),(17,'order_GPz1k7G3nkF2dh','20','22','Abhishek Sharma','7532075184','abhishekaccuster31@gmail.com','In Clinic','2021-01-18','11:00 - 11:15 Am',NULL,'500','0','Pending',NULL,'2021-01-16 12:46:45','2021-01-16 12:46:45'),(18,'order_GQhFiLg0EqcieN','20','22','Abhishek Sharma','7532075184','abhishekaccuster31@gmail.com','In Clinic','2021-01-18','11:00 - 11:15 Am',NULL,'500','0','Pending',NULL,'2021-01-18 08:02:29','2021-01-18 08:02:29'),(19,'order_GQkK47C87ghZ0T','20','22','Abhishek Sharma','7532075184','abhishekaccuster31@gmail.com','In Clinic','2021-01-11','12:00 - 12:15 pm',NULL,'500','0','Pending',NULL,'2021-01-18 11:02:41','2021-01-18 11:02:41'),(20,'order_GRXfNgJW1s029v','21','22','Rupam Thakur','9910488978','rupamthakur353@gmail.com','Audio','2021-01-21','12:30 - 12:45 pm',NULL,'500','0','Pending',NULL,'2021-01-20 11:18:51','2021-01-20 11:18:51'),(21,'order_GSMY85cJTQ1YA2','22','22','yogesh verma','9891437264','care.ediagno@gmail.com','In Clinic','2021-01-23','11:00 - 11:15 Am',NULL,'500','0','Pending',NULL,'2021-01-22 13:05:22','2021-01-22 13:05:22'),(22,'order_GTSPKoBidaQm3o','24','22','Gaurav vashistha','7500628521','gaurav.vashistha1997@gmail.com','Video','2021-01-20','12:00 - 12:15 pm',NULL,'500','0','Pending',NULL,'2021-01-25 07:28:12','2021-01-25 07:28:12'),(23,'order_GTSf2gXhaUYveD','24','22','Gaurav vashistha','7500628521','gaurav.vashistha1997@gmail.com','In Clinic','2021-01-26','11:45 - 12:00 pm',NULL,'500','0','Pending',NULL,'2021-01-25 07:43:04','2021-01-25 07:43:04'),(24,'order_GWeLmaIFc8uDnE','26','23','Sumit kumar','8447809762','panchal061090@gmail.com','In Clinic','2021-02-11','10:00 - 12:00',NULL,'1000','0','Pending','Online','2021-02-02 09:06:08','2021-02-02 09:06:08'),(25,'order_GWeN3Yl8KhWzgA','26','23','Sumit kumar','8447809762','panchal061090@gmail.com','In Clinic','2021-02-12','10:00 - 12:00','1612256840.jpeg','1000','0','Pending','Offline','2021-02-02 09:07:20','2021-02-02 09:07:20'),(26,'order_GWf9uzVjWuoZbw','27','22','Abhishek Sharma','7532075184','abhishekaccuster31@gmail.com','Audio','2021-02-01','11:00 - 11:15 Am',NULL,'500','0','Pending','Offline','2021-02-02 09:53:36','2021-02-02 09:53:36'),(27,'order_GWfB1P21TzgFa7','27','22','Abhishek Sharma','7532075184','abhishekaccuster31@gmail.com','Video','2021-01-04','11:00 - 11:15 Am',NULL,'500','0','Pending','Online','2021-02-02 09:54:39','2021-02-02 09:54:39'),(28,'order_GWfBSjZGOTL9OR','27','22','Abhishek Sharma','7532075184','abhishekaccuster31@gmail.com','Audio','2021-01-04','11:00 - 11:15 Am',NULL,'500','0','Pending','Offline','2021-02-02 09:55:03','2021-02-02 09:55:03'),(29,'order_GWfE3Y5yWzOkNW','27','22','Abhishek Sharma','7532075184','abhishekaccuster31@gmail.com','Video','2021-02-01','11:00 - 11:15 Am',NULL,'500','0','Pending','Offline','2021-02-02 09:57:31','2021-02-02 09:57:31'),(30,'order_GXRq4frdz3ihoC','28','22','Abhishek sharma','7532075184','abhishekaccuster31@gmail.com','Audio','2020-12-03','11:45 - 12:00 pm',NULL,'500','0','Pending','Online','2021-02-04 09:30:47','2021-02-04 09:30:47'),(31,'order_GXoMaEUD2KaofR','28','22','Abhishek sharma','7532075184','abhishekaccuster31@gmail.com','In Clinic','2021-02-01','11:15 - 11:30 am',NULL,'500','0','Pending','Online','2021-02-05 07:32:50','2021-02-05 07:32:50'),(32,'order_GYga65pIRnxOkN','28','22','Abhishek sharma','7532075184','abhishekaccuster31@gmail.com','Video','2021-02-01','11:15 - 11:30 am',NULL,'500','0','Pending','Offline','2021-02-07 12:35:04','2021-02-07 12:35:04'),(33,'order_GYy8nzrAWWpMqC','28','22','Abhishek sharma','7532075184','abhishekaccuster31@gmail.com','In Clinic','2021-02-08','11:15 - 11:30 am',NULL,'500','0','Pending','Online','2021-02-08 05:45:43','2021-02-08 05:45:43');
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `status` enum('1','2','3','4') NOT NULL DEFAULT '1',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` (`id`, `code`, `amount`, `status`, `updated_at`, `created_at`) VALUES (3,'SUM123','200','1','2020-12-16 11:32:07','2020-12-16 11:32:07'),(4,'DIAG','50','1','2020-12-28 10:00:17','2020-12-28 10:00:17');
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctors`
--

DROP TABLE IF EXISTS `doctors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `specialists` text,
  `experience` text,
  `fee` varchar(100) DEFAULT '0',
  `address` text,
  `pincode` varchar(100) DEFAULT NULL,
  `timing` text,
  `qualifications` text,
  `memberships` text,
  `awards` text,
  `image` varchar(255) NOT NULL DEFAULT 'default.png',
  `discription` text,
  `professional_experience` text,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctors`
--

LOCK TABLES `doctors` WRITE;
/*!40000 ALTER TABLE `doctors` DISABLE KEYS */;
INSERT INTO `doctors` (`id`, `name`, `mobile`, `email`, `gender`, `password`, `slug`, `specialists`, `experience`, `fee`, `address`, `pincode`, `timing`, `qualifications`, `memberships`, `awards`, `image`, `discription`, `professional_experience`, `status`, `updated_at`, `created_at`) VALUES (15,'Dr. Sanjay Verma','1234567890','abhishekaccuster31@gmail.com','Male','Abhishek@123','dr-sanjay-verma1609223307','Diabetologist','23 Years','600','E-344 Basement, Greater Kailash-I, New Delhi, Delhi 110023','110048','10-5pm','MBBS, MD - Internal Medicine General Physician','DMC',NULL,'1609223428.jpeg','','Medical Director at Model Hospital owned by All India Blind Relief Society , , 2010 - 2011 Consultant Physician &amp; Diabetologist at at SitaramBhartia Institute of Science and Research, 2000 - 2001. Consultant Physician and Medical Superintendent at Spring Meadows Hospital , , 1997 - 2000 Presently Practicing as Consultant Physician &amp;Diab at Apollo Sugar Clinic , Apollo Spectra Hospital, Kailash Colony , Delhi Presently Practicing as Consultant Physician &amp;Diab at Crest Diabetes Centre , Delhi Chief Medical Consultant (CMC) at MMTC Ltd ,','0','2021-02-02 04:45:10','2020-12-29 06:28:27'),(17,'Dr. Pardeep Jain','9868728596',NULL,NULL,'9868728596','dr-pardeep-jain1609251819','Fertility','9 Yrs','200','New Seelumpur ,Delhi','110053','6-8 pm','MBBS, MD, FRMS, IRCS',NULL,NULL,'1609251819.jpeg',NULL,NULL,'1','2021-01-04 11:02:36','2020-12-29 14:23:39'),(21,'Dr. Mudasir Khan','8800798697',NULL,NULL,'8800798697','dr-mudasir-khan1609833770','General Physician','25 Years','500','( Sanjeevni Hospital ) Near DAV Public School, Pocket -5, New Delhi','110025','11:00 am - 2:30 pm','MBBS, MD ( Cardiff University)','DMC ( 60913)',NULL,'1609833770.jpeg','\r\n\r\nDr. Mudasir Rashid Khan has done her Post Graduation from Prestigious Cardiff University in UK.with her nearly 25 years of experience both in India, Gulf, and England, you can be assured of proper diagnosis and treatment, Her skills lies in balancing the art of cosmetology with the science of dermatology to give her patients the best results. Besides treating common skin problems like eczema, fungal infection, psoriasis, etc. she has special expertise in treating acne and acne scars beside that she has been doing hundreds of cosmetic treatments like botox, meso therapy, PRP fillers, thread lifts, and leaser both for hair removal and scar removal. &nbsp;\r\n\r\n','','1','2021-01-05 14:36:27','2021-01-05 08:02:50'),(22,'Dr. Gorika Bansal','9873835044',NULL,NULL,'9873835044','dr-gorika-bansal1610728768','General Physician','13 Years','500','K-37, Green Park Main, Block K, Green Park, New Delhi, Delhi','110016','11:00 am - 5:30 pm','MBBS, Diploma in Child Health (DCH), DNB - Paediatrics','DMC ( 04127)','5 Arm WHO Polio Study (World Health Organization) - 2009 Gold Medalist - DIploma in child health (DCH) - 2010','1610729044.jpeg','Dr. Gorika Bansal is a Newborn &amp; Child Specialist in Green Park, South Delhi. She practices at Dr. Gorika\'s Children\'s Medical Center(GCMC) in Green Park. But now, along with running her center, she is associated with Max Smart Super Speciality Hospital, Saket, Adiva and Sitaram Bhartiya Hospital. Her clinical expertise includes Newborn care counseling, Vaccination, Diet nutrition counseling, Growth &amp; developmental assessment, Childhood Infections, adolescent medicine, asthma &amp; allergies, etc.Dr. Gorika Bansal is one of the most sought after child vaccination doctors in Green Park, South Delhi. After completing her DNB she did her observership under renowned pediatric endocrinologist Dr. Vaman Khadilkar in Pune. She is counted amongst the leading child specialists in Green Park, South Delhi. Dr. Gorika Bansal completed MBBS from HNB, Garhwal University in 2007, followed by DCH where she was a gold medallist for academic excellence. After that, she completed her DNB (Paediatrics) from Tirath Ramshah Hospital, Delhi. Dr. Gorika Bansal sees babies right from birth to 18 years for everything from consultations to vaccinations to development monitoring, and she likes interacting with the parents to answer all those never ending queries.','2015 - 2015 Consultant Pediatrician at Max Hospital Saket2015 - 2016 Consultant Pediatrician at Sita Ram Bhartiya Institute Of Science And Research, Qutub Enclave','1','2021-01-15 16:44:27','2021-01-15 16:39:28'),(23,'Sumit','8447809762','panchal061090@gmail.com','Male','123456','sumit1612252334','General Physician','3 Years','1000','Ghaziabad','201003','10:00 AM','MCA','Yes','Yes','1612252491.png','Hi Testing','Hi Testinga','0','2021-02-02 03:48:11','2021-02-02 07:52:14'),(24,'krashanu garg','7532075184',NULL,NULL,'123456','krashanu-garg1612260949','Dietitian',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,'default.png',NULL,NULL,'0','2021-02-02 10:15:49','2021-02-02 10:15:49');
/*!40000 ALTER TABLE `doctors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `healthstores`
--

DROP TABLE IF EXISTS `healthstores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `healthstores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `oldprice` varchar(100) DEFAULT NULL,
  `newprice` varchar(100) DEFAULT NULL,
  `image` varchar(255) NOT NULL DEFAULT 'default.png',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `healthstores`
--

LOCK TABLES `healthstores` WRITE;
/*!40000 ALTER TABLE `healthstores` DISABLE KEYS */;
INSERT INTO `healthstores` (`id`, `name`, `slug`, `oldprice`, `newprice`, `image`, `updated_at`, `created_at`) VALUES (2,'Thermometer','thermometer1605697761','500','400','1605697761.png','2020-11-18 11:09:21','2020-11-18 11:09:21'),(3,'Thermometer 1','thermometer-11605697778','120','100','1605697778.png','2020-11-18 11:09:38','2020-11-18 11:09:38'),(4,'Thermometer 2','thermometer-21605697799','220','190','1605697799.png','2020-11-18 11:09:59','2020-11-18 11:09:59'),(5,'Thermometer 3','thermometer-31605697823','100','90','1605697823.png','2020-11-18 11:10:23','2020-11-18 11:10:23'),(6,'Thermometer 4','thermometer-41605697852','1200','1000','1605697852.png','2020-11-18 11:10:52','2020-11-18 11:10:52'),(9,'Thermometer 5','thermometer-51605697910','120','90','1605697910.png','2020-11-18 11:11:50','2020-11-18 11:11:50');
/*!40000 ALTER TABLE `healthstores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homepage`
--

DROP TABLE IF EXISTS `homepage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `homepage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homepage`
--

LOCK TABLES `homepage` WRITE;
/*!40000 ALTER TABLE `homepage` DISABLE KEYS */;
INSERT INTO `homepage` (`id`, `title`, `content`, `status`, `updated_at`, `created_at`) VALUES (1,'ELEVATE YOUR BRAND STORY ON SOCIAL MEDIA','Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.','1','2020-10-30 07:12:31','2020-10-30 07:12:31');
/*!40000 ALTER TABLE `homepage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `labtests`
--

DROP TABLE IF EXISTS `labtests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `labtests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `oldprice` varchar(100) DEFAULT NULL,
  `newprice` varchar(100) DEFAULT NULL,
  `discription` text,
  `image` varchar(255) NOT NULL DEFAULT 'default.png',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `labtests`
--

LOCK TABLES `labtests` WRITE;
/*!40000 ALTER TABLE `labtests` DISABLE KEYS */;
INSERT INTO `labtests` (`id`, `name`, `slug`, `oldprice`, `newprice`, `discription`, `image`, `updated_at`, `created_at`) VALUES (2,'Advance Diabetes Care','advance-diabetes-care1605693440','500','400','<p>\r\n\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now \r\n\r\n<br></p>','1605693440.png','2020-12-29 01:43:44','2020-11-18 09:57:20'),(3,'Basic Allergy','basic-allergy1605693462','120','100',NULL,'1605693462.png','2020-11-18 09:57:42','2020-11-18 09:57:42'),(4,'Basic Antenatal Care','basic-antenatal-care1605693486','1200','1000',NULL,'1605693486.png','2020-11-18 04:37:32','2020-11-18 09:58:06'),(5,'Bone Strength','bone-strength1605693514','500','470',NULL,'1605693514.png','2020-11-30 00:35:16','2020-11-18 09:58:34');
/*!40000 ALTER TABLE `labtests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (2,'2019_09_19_110306_create_category_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(100) DEFAULT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `billing_name` varchar(255) DEFAULT NULL,
  `billing_email` varchar(255) DEFAULT NULL,
  `billing_mobile` varchar(255) DEFAULT NULL,
  `billing_address` text,
  `billing_city` varchar(255) DEFAULT NULL,
  `billing_state` varchar(255) DEFAULT NULL,
  `billing_pincode` varchar(255) DEFAULT NULL,
  `billing_country` varchar(255) DEFAULT NULL,
  `shipping_name` varchar(255) DEFAULT NULL,
  `shipping_email` varchar(255) DEFAULT NULL,
  `shipping_mobile` varchar(255) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_pincode` varchar(100) DEFAULT NULL,
  `shipping_address` text,
  `shipping_country` varchar(100) DEFAULT NULL,
  `total_amount` varchar(255) DEFAULT NULL,
  `order_notes` text,
  `order_details` text,
  `payment_amount` varchar(255) DEFAULT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `bank` varchar(255) DEFAULT NULL,
  `razorpay_payment_id` varchar(255) DEFAULT NULL,
  `payment_status` varchar(255) DEFAULT NULL,
  `bank_transaction_id` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` (`id`, `user_id`, `order_id`, `billing_name`, `billing_email`, `billing_mobile`, `billing_address`, `billing_city`, `billing_state`, `billing_pincode`, `billing_country`, `shipping_name`, `shipping_email`, `shipping_mobile`, `shipping_city`, `shipping_state`, `shipping_pincode`, `shipping_address`, `shipping_country`, `total_amount`, `order_notes`, `order_details`, `payment_amount`, `payment_method`, `bank`, `razorpay_payment_id`, `payment_status`, `bank_transaction_id`, `updated_at`, `created_at`) VALUES (30,'16','order_GIOoFMCykwqltl','Anuj  Kumar','indian191989@gmail.com','7678367852','159/10D Vasundhar    201010 Ghaziabad UP ','Ghaziabad','UP','201010','India','Anuj  Kumar','indian191989@gmail.com','7678367852','Ghaziabad','UP','201010','159/10D Vasundhar    201010 Ghaziabad UP ','India','1000',NULL,'{\"5fe99af67450a\":{\"id\":\"5fe99af67450a\",\"name\":\"Pharmacy 2\",\"price\":1000,\"quantity\":\"1\",\"attributes\":{\"image\":\"http:\\/\\/saromc.com\\/diagno\\/public\\/front\\/pharmacy\\/1606716938.png\",\"oldprice\":\"1200\"},\"conditions\":[]}}',NULL,NULL,NULL,NULL,NULL,NULL,'2020-12-28 08:47:58','2020-12-28 08:47:58'),(31,'10','order_GIqarJElrlTnKM','Sumit','panchal061090@gmail.com','8447809762','Gangoh ','Gahziabad','UP','247341','Indonasia','Sumit','panchal061090@gmail.com','8447809762','Gahziabad','UP','247341','Gangoh ','Indonasia','6180',NULL,'{\"5feb19a45a60a\":{\"id\":\"5feb19a45a60a\",\"name\":\"Advance Diabetes Care\",\"price\":400,\"quantity\":\"4\",\"attributes\":{\"image\":\"http:\\/\\/saromc.com\\/diagno\\/public\\/front\\/labtest\\/1605693440.png\",\"oldprice\":\"500\"},\"conditions\":[]},\"5feb19b3085ce\":{\"id\":\"5feb19b3085ce\",\"name\":\"Pharmacy 3\",\"price\":400,\"quantity\":\"2\",\"attributes\":{\"image\":\"http:\\/\\/saromc.com\\/diagno\\/public\\/front\\/pharmacy\\/1606716963.png\",\"oldprice\":\"500\"},\"conditions\":[]},\"5feb19bca2e03\":{\"id\":\"5feb19bca2e03\",\"name\":\"Basic Allergy\",\"price\":100,\"quantity\":\"1\",\"attributes\":{\"image\":\"http:\\/\\/saromc.com\\/diagno\\/public\\/front\\/labtest\\/1605693462.png\",\"oldprice\":\"120\"},\"conditions\":[]},\"5feb19c417f21\":{\"id\":\"5feb19c417f21\",\"name\":\"Bone Strength\",\"price\":470,\"quantity\":\"5\",\"attributes\":{\"image\":\"http:\\/\\/saromc.com\\/diagno\\/public\\/front\\/labtest\\/1605693514.png\",\"oldprice\":\"500\"},\"conditions\":[]},\"5feb19d53f4ea\":{\"id\":\"5feb19d53f4ea\",\"name\":\"Health Store 4\",\"price\":190,\"quantity\":\"7\",\"attributes\":{\"image\":\"http:\\/\\/saromc.com\\/diagno\\/public\\/front\\/pharmacy\\/1606717112.png\",\"oldprice\":\"100\"},\"conditions\":[]}}',NULL,NULL,NULL,NULL,NULL,NULL,'2020-12-29 11:58:42','2020-12-29 11:58:42'),(33,'20','order_GUn2dGHJOwoQwk','Abhishek Sharma','abhishekaccuster31@gmail.com','7532075184','15, Satbari, chattarpur, New Delhi ','Delhi','New delhi','110074','India','Abhishek Sharma','abhishekaccuster31@gmail.com','7532075184','Delhi','New delhi','110074','15, Satbari, chattarpur, New Delhi ','India','400',NULL,'{\"6012e3a156cef\":{\"id\":\"6012e3a156cef\",\"name\":\"Advance Diabetes Care\",\"price\":400,\"quantity\":\"1\",\"attributes\":{\"image\":\"http:\\/\\/diagnomitra.com\\/public\\/front\\/labtest\\/1605693440.png\",\"oldprice\":\"500\"},\"conditions\":[]}}',NULL,NULL,NULL,NULL,NULL,NULL,'2021-01-28 16:18:16','2021-01-28 16:18:16');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pharmacies`
--

DROP TABLE IF EXISTS `pharmacies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pharmacies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` enum('1','2') NOT NULL DEFAULT '1',
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `oldprice` varchar(100) DEFAULT NULL,
  `newprice` varchar(100) DEFAULT NULL,
  `short_discription` text,
  `highlight` text,
  `image` varchar(255) NOT NULL DEFAULT 'default.png',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pharmacies`
--

LOCK TABLES `pharmacies` WRITE;
/*!40000 ALTER TABLE `pharmacies` DISABLE KEYS */;
INSERT INTO `pharmacies` (`id`, `category`, `name`, `slug`, `oldprice`, `newprice`, `short_discription`, `highlight`, `image`, `updated_at`, `created_at`) VALUES (12,'1','Crocin Advance','pharmacy-21606716938','350','300','<p>\r\n\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n\r\n<br></p>','<p>\r\n\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n\r\n<br></p>','1606716938.png','2020-12-31 04:57:04','2020-11-30 06:15:38'),(16,'2','Thrometer','health-store-11606717041','150','120','<p>\r\n\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n\r\n<br></p>','<p>\r\n\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n\r\n<br></p>','1606717041.png','2020-12-31 05:11:35','2020-11-30 06:17:21'),(17,'2','Health Store 2','health-store-21606717061','1200','1000','<p>\r\n\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n\r\n<br></p>','<p>\r\n\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n\r\n<br></p>','1606717061.png','2020-12-01 18:47:37','2020-11-30 06:17:41'),(18,'2','Health Store 3','health-store-31606717085','100','90','<p>\r\n\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n\r\n<br></p>','<p>\r\n\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n\r\n<br></p>','1606717085.png','2020-12-01 18:47:53','2020-11-30 06:18:05'),(19,'2','Omron HEM-7130L BP Monitor','health-store-41606717112','4000','3350','<p>\r\n\r\n</p><div><h2>Information about Omron HEM-7130L BP Monitor</h2></div><div><strong>Omron HEM-7130L BP Monitor</strong>&nbsp;is designed in a manner that enables the individual to measure and monitor his or her blood pressure level at any time.<br><br><strong>Uses:</strong><br>It is specifically designed with a large cuff to be placed on the upper arm in order to help monitor one\'s Blood Pressure at home.<br><br><strong>Product Specifications and Features:</strong><br><ul><li>Helps indicate the blood pressure level</li></ul><ul><li>Has 60 memory with date and time</li></ul><ul><li>Average of last 3 reading</li></ul><ul><li>It can detect irregular heartbeat and any body movement</li></ul><ul><li>Product Dimensions:12 x 12 x 16 cm ; 703 g</li></ul><ul><li>Number of batteries required: 4 A batteries</li></ul><ul><li>Item model number:HEM-7130-L_Omron</li></ul><ul><li>Large cuff 22 to 42cm</li></ul><ul><li>Can detect Hypertension</li></ul></div><br>\r\n\r\n<br><p></p>','<p>\r\n\r\n</p><div>Product Highlights</div><div><ul><li>Help measure the blood pressure</li></ul><ul><li>Detects irregular heartbeat</li></ul><ul><li>Detects body movement</li></ul><ul><li>Comfortable hand cuff to be placed on the upper arm</li></ul></div>\r\n\r\n<br><p></p>','1606717112.png','2020-12-31 05:06:41','2020-11-30 06:18:32'),(20,'2','Dr Morepen BG 03 GlucoOne Glucose Monitoring System with 50 Strip','health-store-51606717140','2349','1200','<p>\r\n\r\n</p><div><h2>Information about Dr Morepen BG 03 GlucoOne Glucose Monitoring System with 50 Strip</h2></div><div><b>Dr Morepen BG 03 GlucoOne Glucose Monitoring System with 50 Strip</b>&nbsp;is designed to monitor the blood glucose level of the body. It is made for home usage and gives accurate results in just five seconds. It comes with a large display screen and stores up to 300 test results.<br><br><b>Uses:</b><br>It is used to monitor blood glucose levels in the body.<br><br><b>Product Specifications and Features:</b><br><ul><li><b>Memory:</b>&nbsp;Stores 300 results with date and time</li></ul><ul><li><b>Easy-to-use:</b>&nbsp;It has an easy three-step operation. It has a hassle-free strip system and only requires 0.5µL of blood sample</li></ul><ul><li><b>Fast and accurate results:</b>&nbsp;The meter requires 5 seconds to measure and deliver blood glucose levels. It has an accurate and ergonomic model. It gives 7, 14, 21, 28, 60, 90 days averages to the user</li></ul><ul><li><b>Smart:</b>&nbsp;It has a large display as well as a sleek design. It has the advantage of Alternative site testing</li></ul><ul><li><b>Test Range:</b>&nbsp;20-600 mg/dL (1.1-33.3 mmol/L)</li></ul><ul><li>It includes Glucometer (with a battery) (1 unit), Lancing Device (1 unit), Lancets (10 units), Glucometer Pouch (1 unit)</li></ul><br><b>Directions For Use:</b><br>Use as per requirement or as directed by the physician.<br><br><b>Safety Information:</b><br><ul><li>Read the label carefully before use</li></ul><ul><li>Store in a cool dry place away from direct sunlight</li></ul><ul><li>Keep out of reach of the children</li></ul><ul><li>Avoid physical damage</li></ul></div>\r\n\r\n<br><p></p>','<p>\r\n\r\n</p><div>Product Highlights</div><div><ul><li>Helps to monitor the blood glucose level</li></ul><ul><li>Gives accurate and reliable results</li></ul><ul><li>Can store up to 300 test results</li></ul><ul><li>Comes with a large display</li></ul></div>\r\n\r\n<br><p></p>','1606717140.png','2020-12-31 05:10:17','2020-11-30 06:19:00'),(21,'2','Health Store 6','health-store-61606717194','120','90','<p>\r\n\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n\r\n<br></p>','<p>\r\n\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n\r\n<br></p>','1606717194.png','2020-12-01 18:47:51','2020-11-30 06:19:54');
/*!40000 ALTER TABLE `pharmacies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sellers`
--

DROP TABLE IF EXISTS `sellers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sellers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `address` text,
  `discription` text,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sellers`
--

LOCK TABLES `sellers` WRITE;
/*!40000 ALTER TABLE `sellers` DISABLE KEYS */;
INSERT INTO `sellers` (`id`, `name`, `mobile`, `email`, `state`, `city`, `address`, `discription`, `status`, `updated_at`, `created_at`) VALUES (4,'diagnomitra','7532075184','abhishekaccuster31@gmail.com','Delhi','New Delhi','340, chauhan mohlla','hgcxckjvbjxhbxf','1','2021-01-03 09:11:23','2021-01-03 09:11:23');
/*!40000 ALTER TABLE `sellers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `image` varchar(255) NOT NULL DEFAULT 'default.png',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` (`id`, `name`, `slug`, `image`, `updated_at`, `created_at`) VALUES (6,'Doctor Consultation','doctor-consultation1605683576','1605683576.png','2020-11-18 07:12:56','2020-11-18 07:12:56'),(7,'Lab Test','lab-test1605683592','1605683592.png','2020-11-18 07:13:12','2020-11-18 07:13:12'),(8,'E-Pharmacy','e-pharmacy1605683654','1605683654.png','2020-11-18 07:14:15','2020-11-18 07:14:15'),(9,'Health Store','health-store1605683669','1605683669.png','2020-11-18 01:44:49','2020-11-18 07:14:29');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sliders`
--

DROP TABLE IF EXISTS `sliders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sliders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sliderImage` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sliders`
--

LOCK TABLES `sliders` WRITE;
/*!40000 ALTER TABLE `sliders` DISABLE KEYS */;
INSERT INTO `sliders` (`id`, `sliderImage`, `status`, `updated_at`, `created_at`) VALUES (13,'1605698135.png','1','2020-11-18 11:15:35','2020-11-18 11:15:35');
/*!40000 ALTER TABLE `sliders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slots`
--

DROP TABLE IF EXISTS `slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slot` varchar(255) DEFAULT NULL,
  `doctor` varchar(100) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slots`
--

LOCK TABLES `slots` WRITE;
/*!40000 ALTER TABLE `slots` DISABLE KEYS */;
INSERT INTO `slots` (`id`, `slot`, `doctor`, `updated_at`, `created_at`) VALUES (3,'10:00 AM','9','2020-12-19 07:58:36','2020-12-19 07:58:36'),(4,'12:00 PM','9','2020-12-19 07:58:40','2020-12-19 07:58:40'),(5,'1:00 PM','9','2020-12-19 08:00:03','2020-12-19 08:00:03'),(6,'9-1pm','10','2020-12-19 12:17:04','2020-12-19 12:17:04'),(7,'10:00 AM','14','2020-12-28 11:50:04','2020-12-28 11:50:04'),(8,'12:00 PM','14','2020-12-28 11:50:08','2020-12-28 11:50:08'),(9,'10:00 - 10:30','15','2020-12-29 06:58:16','2020-12-29 06:58:16'),(10,'10:30 - 11:00','15','2020-12-29 06:58:29','2020-12-29 06:58:29'),(11,'11:00 - 11:30 Am','15','2020-12-29 06:58:52','2020-12-29 06:58:52'),(12,'11:00 - 11:15 Am','22','2021-01-15 16:54:57','2021-01-15 16:54:57'),(13,'11:15 - 11:30 am','22','2021-01-15 16:55:21','2021-01-15 16:55:21'),(14,'11:30 - 11:45 am','22','2021-01-15 16:55:42','2021-01-15 16:55:42'),(15,'11:45 - 12:00 pm','22','2021-01-15 16:56:03','2021-01-15 16:56:03'),(16,'12:00 - 12:15 pm','22','2021-01-15 16:56:25','2021-01-15 16:56:25'),(17,'12:15 - 12:30 pm','22','2021-01-15 16:56:48','2021-01-15 16:56:48'),(18,'12:30 - 12:45 pm','22','2021-01-15 16:57:10','2021-01-15 16:57:10'),(19,'12:45 - 1:00 pm','22','2021-01-15 16:57:25','2021-01-15 16:57:25'),(20,'10:00 - 12:00','23','2021-02-02 07:55:39','2021-02-02 07:55:39');
/*!40000 ALTER TABLE `slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `specialists`
--

DROP TABLE IF EXISTS `specialists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `specialists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `details` text,
  `image` varchar(255) NOT NULL DEFAULT 'default.png',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `specialists`
--

LOCK TABLES `specialists` WRITE;
/*!40000 ALTER TABLE `specialists` DISABLE KEYS */;
INSERT INTO `specialists` (`id`, `name`, `slug`, `details`, `image`, `updated_at`, `created_at`) VALUES (1,'Dietitian','dietitian1605685833','PCOD, Weight Loss, Weight Gain, Diabetes, High BP','1605685833.png','2020-11-18 02:42:57','2020-11-18 07:50:33'),(2,'General Physician','general-physician1605685876','Fever, Stomach Issues, Vomiting, ACough, Headache/Migraine','1605685876.png','2020-11-18 07:51:17','2020-11-18 07:51:17'),(3,'Gastroenterologist','gastroenterologist1605685911','Constipation, Stomach/Abdominal Pains, Vomiting, Acidity/Gas, Diarrhea','1605685911.png','2020-11-18 07:51:51','2020-11-18 07:51:51'),(4,'Fertility','fertility1605685948','PCOD, Weight Loss, Weight Gain, Diabetes, High BP','1605685948.png','2020-11-30 00:34:56','2020-11-18 07:52:28');
/*!40000 ALTER TABLE `specialists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store_enquiry`
--

DROP TABLE IF EXISTS `store_enquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `store_enquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` text,
  `contact` varchar(255) DEFAULT NULL,
  `alternate_contact` varchar(255) DEFAULT NULL,
  `prescription` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store_enquiry`
--

LOCK TABLES `store_enquiry` WRITE;
/*!40000 ALTER TABLE `store_enquiry` DISABLE KEYS */;
INSERT INTO `store_enquiry` (`id`, `store_id`, `name`, `email`, `address`, `contact`, `alternate_contact`, `prescription`, `updated_at`, `created_at`) VALUES (3,4,'Abhishek Sharma','abhishekaccuster31@gmail.com','30 Satbari Village','7532075184','7532075184',NULL,'2021-02-02 05:57:51','2021-02-02 05:57:51'),(4,4,'Gaurav vashistha','gaurav.vashistha1997@gmail.com','Bhagupur, Uttar Pradesh 283202, India','7500628521','6398124836','1612245828.jpeg','2021-02-02 06:03:49','2021-02-02 06:03:49'),(5,7,'Abhishek Sharma','abhishekaccuster31@gmail.com','Satbari','7532075184','+919990013747','1612609793.png','2021-02-06 11:09:53','2021-02-06 11:09:53'),(6,8,'Abhishek Sharma','abhishekaccuster31@gmail.com','Hsnabd','7532075184','+919990013747','1612700172.jpeg','2021-02-07 12:16:13','2021-02-07 12:16:13');
/*!40000 ALTER TABLE `store_enquiry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stores`
--

DROP TABLE IF EXISTS `stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `address` text,
  `pincode` varchar(100) DEFAULT NULL,
  `image` varchar(255) NOT NULL DEFAULT 'default.png',
  `discription` text,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stores`
--

LOCK TABLES `stores` WRITE;
/*!40000 ALTER TABLE `stores` DISABLE KEYS */;
INSERT INTO `stores` (`id`, `name`, `mobile`, `email`, `password`, `slug`, `address`, `pincode`, `image`, `discription`, `status`, `updated_at`, `created_at`) VALUES (3,'Deepak','7065159061',NULL,'12345','deepak1611408138',NULL,NULL,'default.png',NULL,'0','2021-01-23 13:22:18','2021-01-23 13:22:18'),(4,'Krishanu','9068492187','diagnomitralabs@gmail.com','Krishanu','krishanu1612245032','15satbari chattarpur','110074','1612245218.jpeg','shdgagdhasgdhakd','1','2021-02-02 05:54:48','2021-02-02 05:50:32'),(5,'Sumit Kumar','8447809762','panchal061090@gmail.com','123456','sumit1612253122','Gangoh','201009','1612253213.png','Hi Noida','0','2021-02-02 02:56:12','2021-02-02 08:05:22'),(6,'krashanu Garg','7532075184',NULL,'123456','krashanu-garg1612261042',NULL,NULL,'default.png',NULL,'0','2021-02-02 10:17:22','2021-02-02 10:17:22'),(7,'Yogesh Verma','9891437264','abhishekaccuster31@gmail.com','123456','yogesh-verma1612609381','satbari','110074','default.png','amsdhjdhjdsfhjksf','1','2021-02-06 05:37:42','2021-02-06 11:03:01'),(8,'Shivam Bansal','7982401443',NULL,'HESTABIT2018','shivam-bansal1612699223',NULL,NULL,'default.png',NULL,'1','2021-02-07 06:41:49','2021-02-07 12:00:23');
/*!40000 ALTER TABLE `stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testimonials`
--

DROP TABLE IF EXISTS `testimonials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `content` text,
  `image` varchar(100) NOT NULL DEFAULT 'user.png',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testimonials`
--

LOCK TABLES `testimonials` WRITE;
/*!40000 ALTER TABLE `testimonials` DISABLE KEYS */;
INSERT INTO `testimonials` (`id`, `name`, `content`, `image`, `updated_at`, `created_at`) VALUES (4,'Sumit','\r\n\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n\r\n','user.png','2020-12-16 07:04:42','2020-12-16 07:04:42'),(5,'Anuj','\r\n\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n\r\n','user.png','2020-12-16 07:04:54','2020-12-16 07:04:54'),(6,'krashanu Garg','Diagnomitra helps me to provide quality healthcare services.','user.png','2021-02-02 06:36:33','2021-02-02 06:36:33');
/*!40000 ALTER TABLE `testimonials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `address` text,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `shipping_name` varchar(255) DEFAULT NULL,
  `shipping_email` varchar(255) DEFAULT NULL,
  `shipping_mobile` varchar(255) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_pincode` varchar(100) DEFAULT NULL,
  `shipping_address` text,
  `shipping_country` varchar(100) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `password`, `mobile`, `gender`, `address`, `city`, `state`, `pincode`, `country`, `shipping_name`, `shipping_email`, `shipping_mobile`, `shipping_city`, `shipping_state`, `shipping_pincode`, `shipping_address`, `shipping_country`, `updated_at`, `created_at`) VALUES (21,'Rupam Thakur','rupamthakur353@gmail.com','Rupam','9910488978',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-01-20 11:17:59','2021-01-20 11:17:59'),(22,'yogesh verma','care.ediagno@gmail.com','qwerty','9891437264',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-01-22 13:04:26','2021-01-22 13:04:26'),(23,'yogesh verma','care.ediagno@gmail.com','qwerty','9891437264',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-01-22 13:04:30','2021-01-22 13:04:30'),(24,'Gaurav vashistha','gaurav.vashistha1997@gmail.com','vashistha@1019','7500628521',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-01-25 07:26:19','2021-01-25 07:26:19'),(26,'Sumit kumar','panchal061090@gmail.com','123456','8447809762','Male','noida','Gurugram','UP','247341','UK','Sumit Panchal','panchal061090@gmail.com','8447809762','Noida','Uttar Pradesh','201009','Noida','India','2021-02-02 07:36:44','2021-02-02 07:36:44'),(28,'Abhishek sharma','abhishekaccuster31@gmail.com','123456','7532075184',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-02-02 10:12:48','2021-02-02 10:12:48');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'primewe1_diagno'
--

--
-- Dumping routines for database 'primewe1_diagno'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-09  9:53:12
